from flask import Flask, request, jsonify
from vosk import Model, KaldiRecognizer
from flask_cors import CORS
import os
import json
import wave
import tempfile
import shutil

app = Flask(__name__)
CORS(app)

MODEL_PATH = os.path.join(os.getenv("USERPROFILE", ""), ".cache", "vosk", "vosk-model-small-en-us-0.15")
MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
MAX_AUDIO_SIZE = 50 * 1024 * 1024  # 50MB limit

def ensure_model():
    """Download and extract Vosk model if not present."""
    conf_path = os.path.join(MODEL_PATH, "conf")
    if os.path.exists(conf_path):
        return True
    
    try:
        import urllib.request
        import zipfile
        
        os.makedirs(MODEL_PATH, exist_ok=True)
        zip_path = os.path.join(tempfile.gettempdir(), "vosk-model.zip")
        
        app.logger.info("Downloading Vosk model from %s", MODEL_URL)
        urllib.request.urlretrieve(MODEL_URL, zip_path)
        app.logger.info("Extracting Vosk model...")
        
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            zip_ref.extractall(MODEL_PATH)
        
        extracted_name = os.listdir(MODEL_PATH)[0] if os.listdir(MODEL_PATH) else None
        if extracted_name and extracted_name != "vosk-model-small-en-us-0.15":
            old_dir = os.path.join(MODEL_PATH, extracted_name)
            if os.path.isdir(old_dir):
                for item in os.listdir(old_dir):
                    src = os.path.join(old_dir, item)
                    dst = os.path.join(MODEL_PATH, item)
                    shutil.move(src, dst)
                os.rmdir(old_dir)
        
        if os.path.exists(zip_path):
            os.remove(zip_path)
        
        return os.path.exists(conf_path)
    except Exception as e:
        app.logger.error("Failed to download Vosk model: %s", str(e))
        return False

model = None

def init_vosk():
    global model
    if not ensure_model():
        app.logger.error("Vosk model not found and could not be downloaded")
        return False
    
    try:
        model = Model(MODEL_PATH)
        app.logger.info("Vosk model loaded successfully from %s", MODEL_PATH)
        return True
    except Exception as e:
        app.logger.error("Failed to load Vosk model: %s", str(e))
        return False

def transcribe_audio_stream(wav_file):
    """Transcribe audio from a wave file using streaming."""
    global model
    if not model:
        return None, "Vosk model not loaded"
    
    try:
        wf = wave.open(wav_file, "rb")
        if wf.getnchannels() != 1:
            wf.close()
            return None, "Audio must be mono"
        if wf.getsampwidth() != 2:
            wf.close()
            return None, "Audio must be 16-bit PCM"
        
        samplerate = wf.getframerate()
        
        # Create a new recognizer for each request with the correct sample rate
        local_recognizer = KaldiRecognizer(model, samplerate)
        
        text_parts = []
        final_text = ""
        
        while True:
            data = wf.readframes(4000)
            if len(data) == 0:
                break
            if local_recognizer.AcceptWaveform(data):
                result = json.loads(local_recognizer.Result())
                if result.get("text"):
                    text_parts.append(result["text"])
        
        result = json.loads(local_recognizer.FinalResult())
        final_text = result.get("text", "")
        
        if text_parts:
            final_text = " ".join(text_parts + [final_text]).strip()
        
        wf.close()
        return final_text, None
        
    except Exception as e:
        app.logger.error("Transcription error: %s", str(e))
        return None, str(e)

@app.route("/api/transcribe/vosk", methods=["POST"])
def transcribe():
    """Accept audio file and return transcription via Vosk."""
    global model
    if not model:
        return jsonify({"error": "Vosk model not loaded. Please check model files.", "success": False}), 500
    
    if "audio" not in request.files:
        return jsonify({"error": "No audio file provided", "success": False}), 400
    
    audio_file = request.files["audio"]
    
    # Check file size
    audio_file.seek(0, os.SEEK_END)
    size = audio_file.tell()
    audio_file.seek(0)
    
    if size > MAX_AUDIO_SIZE:
        return jsonify({"error": f"Audio file too large. Maximum size is {MAX_AUDIO_SIZE // (1024*1024)}MB", "success": False}), 413
    
    try:
        # Save to temp file for processing
        wav_buffer = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        audio_file.save(wav_buffer.name)
        wav_buffer.close()
        
        text, error = transcribe_audio_stream(wav_buffer.name)
        
        # Clean up
        try:
            os.unlink(wav_buffer.name)
        except:
            pass
        
        if error:
            return jsonify({"error": error, "success": False}), 400
        
        return jsonify({
            "text": text,
            "success": True
        })
        
    except Exception as e:
        app.logger.error("Transcription error: %s", str(e))
        return jsonify({"error": str(e), "success": False}), 500

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "vosk_loaded": model is not None})

if __name__ == "__main__":
    port = int(os.environ.get("VOSK_PORT", 5000))
    init_vosk()
    app.run(host="0.0.0.0", port=port, debug=False)
