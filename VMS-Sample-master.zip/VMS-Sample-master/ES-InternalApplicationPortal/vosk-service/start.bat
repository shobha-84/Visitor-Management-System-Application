@echo off
echo ========================================
echo   Vosk Speech-to-Text Microservice
echo ========================================
echo.

REM Check if Python is available
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python not found. Please install Python 3.8+
    pause
    exit /b 1
)

REM Install dependencies if requirements.txt exists
if exist requirements.txt (
    echo Installing Python packages...
    python -m pip install -r requirements.txt
    echo.
)

REM Create model cache directory
set VOSK_CACHE=%USERPROFILE%\.cache\vosk
if not exist "%VOSK_CACHE%" mkdir "%VOSK_CACHE%"

REM Start the Flask service
echo Starting Vosk service on port 5000...
echo Press Ctrl+C to stop
echo.

python app.py

pause
