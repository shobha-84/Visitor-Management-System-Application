# VMS - Visitor Management System Feature Documentation

## Executive Summary

The Visitor Management System (VMS) is a comprehensive solution for managing visitor lifecycle from invitation creation to check-out completion. Built with modern web technologies, it provides role-based access control, real-time updates, AI-assisted form filling, and mobile-responsive interfaces.

---

## Feature Catalog

### 1. Invitation Lifecycle Management

| Feature | Description | User Roles |
|---------|-------------|------------|
| **Create Invitation** | Create new visitor invitations with visitor details, visit schedule, purpose, and additional visitors | All authenticated users |
| **Edit Invitation** | Modify invitation details before check-in | Creator, Host, Admin |
| **Delete Invitation** | Remove draft/submitted invitations | Creator, Admin |
| **View Details** | Comprehensive invitation details modal with notes, rejection/cancellation reasons | All roles (based on permissions) |
| **Reschedule Meeting** | Reschedule past-due or upcoming meetings | Host, Admin |
| **Cancel Invitation** | Cancel with mandatory reason | Creator, Host, Admin |
| **Complete Meeting** | Mark meeting as completed with attendance status | Host, Security |

### 2. Role-Based Access Control

| Role | Permissions |
|------|-------------|
| **Admin** | Full system access, all invitations, user management, all tabs |
| **Security** | Check-in/out, Security Checkpoint, My Invitations (today's + recurring), no approval |
| **Facilitator** | Approve/reject invitations, Facilitator View, My Invitations |
| **Approver** | Approve/reject invitations, My Invitations |
| **Host/Employee** | Create invitations, My Invitations (created/hosted), Host Invitations |

### 3. My Invitations - Security Role Enhancement

#### Default View (Recurring: Unchecked)
- **Data:** Today's non-recurring invitations only
- **UI:** Recurring checkbox on right, date pickers hidden
- **Filters:** Status only

#### Recurring View (Recurring: Checked)
- **Data:** All recurring invitations (`visitor_type === "Recurring"`)
- **UI:** Date pickers visible (blank), phone search next to checkbox
- **Filters:** Date range + Phone search + Status

#### Filter Behavior
| Filter | Recurring: Off | Recurring: On |
|--------|----------------|---------------|
| Date Pickers | Hidden | Visible (blank) |
| Phone Search | Hidden | Visible |
| Date Filter | N/A | By `visitStartDate` |
| Phone Search | N/A | By `visitor_phone` |
| Clear Button | Resets to blank dates | Resets to blank dates |

### 4. Security Checkpoint

#### Core Features
- **Real-time Check-in/Out** with photo capture
- **Recurring Visitor Management** with phone-based grouping
- **Visitor History** by phone number
- **Mobile-responsive** card-based UI

#### Recurring Visitor Workflow
| State | Behavior |
|-------|----------|
| **Recurring Off** | Shows non-recurring visitors, date pickers hidden |
| **Recurring On** | Shows recurring visitors, date pickers visible (blank), phone search visible |
| **Clear** | Resets date pickers to blank |

#### Phone Search
- Filters recurring visitors by `visitor_phone`
- Available only when Recurring is checked
- Real-time filtering as user types

### 5. Approval Workflow

#### States
```
Draft → Submitted → [Approved/Rejected] → [Checked In] → [Checked Out] → Completed
                              ↓
                          Cancelled
```

#### Approver Actions
- **Approve:** Sets status to `approved`, notifies host
- **Reject:** Sets status to `rejected`, requires rejection reason
- **Bulk Operations:** Select multiple for batch approve/reject

#### Notifications
- Email/Toast notifications for status changes
- Real-time updates via Supabase Realtime

### 6. AI Assist Features

#### Voice Transcription (Vosk)
- **Recording:** Browser MediaRecorder (WebM)
- **Conversion:** WebM → WAV (client-side)
- **Transcription:** Python Vosk service via ASP.NET proxy
- **Features:** Retry logic, fallback handling, progress indicators

#### AI Form Filling (Ollama)
- **Input:** Natural language chat
- **Processing:** Local LLM with dynamic system prompt
- **Output:** Structured invitation data
- **Apply:** One-click form population with validation

### 7. Additional Visitors Management

#### VisitorManagerDialog
- **Max:** 10 additional visitors
- **Fields:** Name, Email, Phone, Company, Designation
- **Validation:** Required fields, email format, phone format
- **Operations:** Add, Edit, Delete, Reorder

#### In Form
- Inline management within InvitationForm
- Real-time validation
- Summary in invitation cards

### 8. Visitor Photos

#### Capture
- **Webcam:** Direct browser capture (getUserMedia)
- **Upload:** File selection fallback
- **Mobile:** Optimized for mobile browsers

#### Storage
- **Supabase Storage:** Secure, signed URLs
- **Recurring:** Photo history per visitor phone

#### Display
- Thumbnail in invitation cards
- Full-size in detail view
- Photo history in Security Checkpoint

### 9. Invitation Filters (Shared Component)

#### Standard Filters
| Filter | Type | Behavior |
|--------|------|----------|
| Start Date | Date Picker | Filters by `visitStartDate` |
| End Date | Date Picker | Filters by `visitStartDate` |
| Status | Dropdown | Filters by current status |
| Clear | Button | Resets all to default |

#### Security-Specific Behavior
| Condition | Date Pickers | Phone Search |
|-----------|--------------|--------------|
| Non-security role | Always visible | Hidden |
| Security, Recurring: Off | Hidden | Hidden |
| Security, Recurring: On | Visible (blank) | Visible |

#### Clear Button
- **All Roles:** Resets `fromDate`, `toDate` to `undefined`, `status` to `'all'`
- **No Default Dates:** User must select dates

### 10. Invitation Details View

#### Sections
1. **Visitor Information** - Name, Email, Phone, Company, Designation
2. **Visit Details** - Dates, Times, Type (Recurring/Non-Recurring)
3. **Host Information** - Name, Email
4. **Purpose & Requirements** - Visit purpose, additional requirements
5. **Notes** - Remarks, Requirements, Rejection Reason, Cancellation Reason

#### Conditional Display
- Rejection Reason: Only for rejected invitations
- Cancellation Reason: Only for cancelled invitations
- Meeting Status: Only for checked-out without completion

---

## Technical Features

### Real-time Updates
- **Supabase Realtime** for live invitation updates
- **Auto-refresh** on tab switch
- **Badge counts** for pending items

### Mobile Responsiveness
- **Responsive grids** (1-col mobile, 2-col desktop)
- **Touch-friendly** inputs and buttons
- **Webcam API** for mobile photo capture
- **Responsive tables** with horizontal scroll

### Data Validation
- **Client-side:** Required fields, formats, max lengths
- **Server-side:** Duplicate detection, business rules
- **Phone:** Format validation (Indian mobile format)
- **Email:** RFC compliant validation

### Error Handling
- **Toast notifications** for user feedback
- **Retry logic** for network requests
- **Graceful degradation** for offline scenarios

---

## Integration Points

### External Services
| Service | Purpose | Protocol |
|---------|---------|----------|
| **Vosk** | Speech-to-text | HTTP (port 5000) |
| **Ollama** | AI form filling | HTTP (port 11434) |
| **Supabase** | Auth, DB, Realtime, Storage | HTTPS/WebSocket |
| **SQL Server** | Primary database | TCP (ADO.NET) |

### Internal APIs
- **RESTful** design with consistent error responses
- **DTO pattern** for request/response validation
- **EF Core** for database operations

---

## User Experience Highlights

### Security Role Dashboard
- **Tabbed interface:** My Invitations / New Invitation
- **Quick stats:** Pending, Approved, Today's count
- **Quick actions:** Check-in, View, Edit from cards

### Facilitator Dashboard
- **Pending approvals** front and center
- **Quick approve/reject** with modal
- **Bulk operations** for efficiency

### Admin Dashboard
- **All tabs:** My Invitations, Host Invitations, All Invitations
- **System metrics:** Total invitations, active visitors
- **User management:** Role assignment

---

## Compliance & Security

### Data Protection
- **No PII in logs**
- **Encrypted storage** for photos
- **JWT tokens** with short expiry
- **Role-based API authorization**

### Audit Trail
- **Created/Updated timestamps**
- **Status change history**
- **Cancellation/Rejection reasons**

---

## Feature Matrix by Role

| Feature | Admin | Security | Facilitator | Approver | Host |
|---------|-------|----------|-------------|----------|------|
| Create Invitation | ✓ | ✓ | ✓ | ✓ | ✓ |
| My Invitations | ✓ | ✓ (enhanced) | ✓ | ✓ | ✓ |
| Host Invitations | ✓ | ✗ | ✗ | ✗ | ✓ |
| All Invitations | ✓ | ✗ | ✗ | ✗ | ✗ |
| Security Checkpoint | ✓ | ✓ | ✗ | ✗ | ✗ |
| Approve/Reject | ✓ | ✗ | ✓ | ✓ | ✗ |
| Check-in/Out | ✓ | ✓ | ✗ | ✗ | ✗ |
| AI Assist | ✓ | ✓ | ✓ | ✓ | ✓ |
| Photo Capture | ✓ | ✓ | ✗ | ✗ | ✗ |
| Reports/Analytics | ✓ | ✗ | ✗ | ✗ | ✗ |

---

## Recent Enhancements (Oct 2026)

| Date | Feature | Impact |
|------|---------|--------|
| Oct 6 | Vosk Voice Transcription | Voice-to-text for invitation creation |
| Oct 6 | AI Form Filling (Ollama) | Natural language to structured data |
| Oct 8 | Security Recurring Filter | Today's non-recurring vs all recurring |
| Oct 9 | Phone Search | Filter recurring visitors by phone |
| Oct 9 | Clear Button Fix | Resets dates to blank (not current month) |
| Oct 9 | Duplicate Checkbox Removal | Single Recurring checkbox per view |
| Oct 9 | Date Blank on Recurring Check | User selects dates explicitly |

---

## Future Roadmap

### Q4 2026
- [ ] Email/SMS notifications
- [ ] PDF report generation
- [ ] Visitor analytics dashboard

### Q1 2027
- [ ] Multi-language support (i18n)
- [ ] Advanced search with saved filters
- [ ] Bulk invitation import (CSV/Excel)

### Q2 2027
- [ ] Mobile app (React Native/PWA)
- [ ] Offline mode with background sync
- [ ] Advanced AI: Smart scheduling, duplicate detection

---

*Document Version: 1.0 | Last Updated: 2026-10-10*