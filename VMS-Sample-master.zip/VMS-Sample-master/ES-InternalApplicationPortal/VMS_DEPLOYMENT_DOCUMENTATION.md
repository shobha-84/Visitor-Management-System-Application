# VMS - Visitor Management System Deployment Documentation

## Overview

This document provides comprehensive deployment instructions for the Visitor Management System (VMS) including frontend, backend, database, and external services.

---

## System Requirements

### Minimum Hardware
| Component | Development | Production |
|-----------|-------------|------------|
| CPU | 2 cores | 4+ cores |
| RAM | 8 GB | 16+ GB |
| Storage | 20 GB | 50+ GB |
| Network | 1 Gbps | 1 Gbps+ |

### Software Prerequisites
| Software | Version | Purpose |
|----------|---------|---------|
| Node.js | 18+ | Frontend build/runtime |
| .NET SDK | 8.0+ | Backend compilation |
| Python | 3.10+ | Vosk speech service |
| SQL Server | 2019+ | Primary database |
| Ollama | Latest | AI form filling (optional) |
| Git | 2.30+ | Version control |

---

## Architecture Overview

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│  Load       │────▶│  Frontend   │────▶│  Backend    │
│  Balancer   │     │  (Nginx/    │     │  (ASP.NET   │
│  (Optional) │     │   IIS)      │     │   Core)     │
└─────────────┘     └─────────────┘     └─────────────┘
                           │                   │
                           ▼                   ▼
                    ┌─────────────┐     ┌─────────────┐
                    │  Supabase   │     │  SQL Server │
                    │  (Auth/RT)  │     │  (Primary)  │
                    └─────────────┘     └─────────────┘
                           │                   │
                           ▼                   ▼
                    ┌─────────────┐     ┌─────────────┐
                    │  Vosk       │     │  Ollama     │
                    │  (Port 5000)│     │  (Port 11434)│
                    └─────────────┘     └─────────────┘
```

---

## Environment Configuration

### Frontend Environment Variables (`.env`)

```env
# API Configuration
VITE_API_URL=/ExcelSoftVMSPortal
# VITE_API_URL=https://api.yourdomain.com/ExcelSoftVMSPortal  # Production

# Supabase Configuration
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=your-anon-key
VITE_SUPABASE_PROJECT_ID=your-project-id

# Feature Flags
VITE_ENABLE_AI_ASSIST=true
VITE_ENABLE_VOICE=true
```

### Backend Configuration (`appsettings.json`)

```json
{
  "ConnectionStrings": {
    "DefaultConnection": "Server=YOUR_SQL_SERVER;Database=VMS;User Id=sa;Password=YOUR_PASSWORD;TrustServerCertificate=true;"
  },
  "VoskService": {
    "Url": "http://localhost:5000"
  },
  "Ollama": {
    "Url": "http://localhost:11434",
    "Model": "llama3.1:8b"
  },
  "Supabase": {
    "Url": "https://your-project.supabase.co",
    "Key": "your-service-role-key"
  },
  "Jwt": {
    "Issuer": "VMS",
    "Audience": "VMS-Users",
    "Key": "YOUR_JWT_SECRET_KEY_MIN_32_CHARS"
  },
  "AllowedHosts": "*",
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  }
}
```

### Production Environment Variables

```bash
# Backend (set as environment variables or use Azure Key Vault / AWS Secrets Manager)
ASPNETCORE_ENVIRONMENT=Production
ConnectionStrings__DefaultConnection="Server=prod-sql;Database=VMS;User Id=app_user;Password=${DB_PASSWORD};"
VoskService__Url=http://vosk-service:5000
Ollama__Url=http://ollama-service:11434
Supabase__Url=https://your-project.supabase.co
Supabase__Key=${SUPABASE_SERVICE_KEY}
Jwt__Key=${JWT_SECRET_KEY}
```

---

## Database Deployment

### 1. Create Database

```sql
-- Run as sysadmin
CREATE DATABASE VMS
COLLATE SQL_Latin1_General_CP1_CI_AS;

CREATE LOGIN vms_user WITH PASSWORD = 'StrongPassword123!';
CREATE USER vms_user FOR LOGIN vms_user;
ALTER ROLE db_owner ADD MEMBER vms_user;
```

### 2. Run Migrations

```bash
cd ExcelsoftInternalPortal/InternalPortal.Infrastructure
dotnet ef database update --project . --startup-project ../InternalPortal
```

### 3. Seed Initial Data

```sql
-- Run VisitorCreate.sql for schema
-- Then run seed data
INSERT INTO Roles (Name, Description) VALUES 
('Admin', 'System Administrator'),
('employee_security', 'Security Personnel'),
('employee_facilitator', 'Facilitator'),
('employee_approver', 'Approver'),
('employee', 'Regular Employee');
```

### 4. Configure Supabase

1. Create Supabase project
2. Enable Realtime for `visitor_invitations` table
3. Configure Storage bucket for visitor photos
4. Set Row Level Security policies
4. Add redirect URLs in Auth settings

---

## Frontend Deployment

### Build for Production

```bash
cd es-gateway-hub
npm ci
npm run build
```

### Output
- Output directory: `dist/`
- Contains: `index.html`, `assets/` (JS, CSS, images)

### Nginx Configuration

```nginx
# /etc/nginx/sites-available/vms
server {
    listen 80;
    server_name vms.yourdomain.com;
    root /var/www/vms/dist;
    index index.html;

    # SPA routing
    location / {
        try_files $uri $uri/ /index.html;
    }

    # API proxy
    location /ExcelSoftVMSPortal/ {
        proxy_pass http://localhost:5194/;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # Static assets caching
    location /assets/ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }

    # Gzip compression
    gzip on;
    gzip_types text/plain text/css application/json application/javascript text/xml application/xml application/xml+rss text/javascript;
}
```

### IIS Configuration (Windows)

```xml
<!-- web.config in dist/ folder -->
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <rule name="React Routes" stopProcessing="true">
          <match url=".*" />
          <conditions logicalGrouping="MatchAll">
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
          </conditions>
          <action type="Rewrite" url="/index.html" />
        </rule>
      </rules>
    </rewrite>
    <staticContent>
      <remove fileExtension=".woff2" />
      <mimeMap fileExtension=".woff2" mimeType="font/woff2" />
    </staticContent>
  </system.webServer>
</configuration>
```

---

## Backend Deployment

### Publish Application

```bash
cd ExcelsoftInternalPortal/InternalPortal
dotnet publish -c Release -o /opt/vms/backend
```

### Systemd Service (Linux)

```ini
# /etc/systemd/system/vms-backend.service
[Unit]
Description=VMS Backend API
After=network.target

[Service]
Type=notify
WorkingDirectory=/opt/vms/backend
ExecStart=/usr/bin/dotnet /opt/vms/backend/InternalPortal.API.dll
Restart=always
RestartSec=10
KillSignal=SIGINT
SyslogIdentifier=vms-backend
User=vms
Environment=ASPNETCORE_ENVIRONMENT=Production
Environment=ASPNETCORE_URLS=http://0.0.0.0:5194

[Install]
WantedBy=multi-user.target
```

### Windows Service

```powershell
# Install as Windows Service
New-Service -Name "VMS-Backend" -BinaryPathName "C:\vms\backend\InternalPortal.API.exe" -Description "VMS Backend API" -StartupType Automatic
Start-Service VMS-Backend
```

---

## External Services Deployment

### 1. Vosk Speech Recognition Service

#### Docker (Recommended)
```dockerfile
# Dockerfile.vosk
FROM python:3.10-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY app.py .
EXPOSE 5000
CMD ["python", "app.py"]
```

```bash
docker build -t vms-vosk -f Dockerfile.vosk .
docker run -d -p 5000:5000 --name vms-vosk vms-vosk
```

#### Requirements
```
vosk==0.3.45
flask==2.3.3
flask-cors==4.0.0
gunicorn==21.2.0
```

#### Model
Download Vosk model: https://alphacephei.com/vosk/models
```bash
wget https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip
unzip vosk-model-small-en-us-0.15.zip -d /app/model
```

### 2. Ollama (AI Form Filling)

```bash
# Install
curl -fsSL https://ollama.ai/install.sh | sh

# Pull model
ollama pull llama3.1:8b

# Run as service
ollama serve
```

#### GPU Support (Optional)
```bash
# For NVIDIA GPU
ollama pull llama3.1:8b
# Uses GPU automatically if available
```

### 3. Supabase Setup

1. Create project at https://supabase.com
2. **Authentication:**
   - Enable Email/Password provider
   - Configure JWT expiry (recommended: 1 hour)
   - Set redirect URLs
2. **Database:**
   - Enable Realtime for `visitor_invitations`
   - Run migrations via EF Core
3. **Storage:**
   - Create bucket `visitor-photos`
   - Set public access or signed URLs
4. **Edge Functions** (optional): For serverless processing

---

## SSL/TLS Configuration

### Let's Encrypt (Nginx)
```bash
sudo certbot --nginx -d vms.yourdomain.com
```

### Custom Certificate
```nginx
server {
    listen 443 ssl http2;
    server_name vms.yourdomain.com;
    
    ssl_certificate /etc/ssl/certs/vms.crt;
    ssl_certificate_key /etc/ssl/private/vms.key;
    
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers HIGH:!aNULL:!MD5;
    
    # ... rest of config
}
```

### Backend HTTPS
```json
// appsettings.Production.json
{
  "Kestrel": {
    "Endpoints": {
      "Https": {
        "Url": "https://0.0.0.0:5195",
        "Certificate": {
          "Path": "/etc/ssl/certs/vms.pfx",
          "Password": "${CERT_PASSWORD}"
        }
      }
    }
  }
}
```

---

## Monitoring & Logging

### Backend Logging
```json
// appsettings.Production.json
{
  "Serilog": {
    "Using": ["Serilog.Sinks.Console", "Serilog.Sinks.File"],
    "MinimumLevel": "Information",
    "WriteTo": [
      { "Name": "Console" },
      { 
        "Name": "File", 
        "Args": { 
          "path": "/var/log/vms/backend-.log",
          "rollingInterval": "Day",
          "retainedFileCountLimit": 30
        }
      }
    ]
  }
}
```

### Frontend Error Tracking
```typescript
// Sentry integration (optional)
import * as Sentry from "@sentry/react";

Sentry.init({
  dsn: "YOUR_SENTRY_DSN",
  environment: "production",
  tracesSampleRate: 0.1
});
```

### Health Checks
```csharp
// Backend health endpoint
app.MapHealthChecks("/health");
app.MapHealthChecks("/health/ready", new HealthCheckOptions {
    Predicate = check => check.Tags.Contains("ready")
});
```

### Prometheus Metrics (Optional)
```csharp
// Add to Program.cs
builder.Services.AddPrometheusMetrics();
app.UseMetricServer();
app.UseHttpMetrics();
```

---

## Backup & Recovery

### Database Backup
```bash
# Daily backup script
#!/bin/bash
BACKUP_DIR="/backups/vms"
DATE=$(date +%Y%m%d_%H%M%S)
sqlcmd -S localhost -U sa -P "$DB_PASSWORD" \
  -Q "BACKUP DATABASE VMS TO DISK='$BACKUP_DIR/vms_$DATE.bak' WITH COMPRESSION"
find $BACKUP_DIR -name "vms_*.bak" -mtime +30 -delete
```

### Supabase Backup
- Automatic daily backups (Supabase Pro+)
- Point-in-time recovery (7 days on free tier)

### File Storage Backup
```bash
# Sync visitor photos to S3/GCS
aws s3 sync /var/www/vms/uploads s3://vms-backups/photos/ --delete
```

### Recovery Procedure
1. Restore database from latest backup
2. Deploy application code
3. Run migrations if needed
4. Verify health endpoints
5. Test critical user flows

---

## CI/CD Pipeline

### GitHub Actions Example

```yaml
# .github/workflows/deploy.yml
name: Deploy VMS

on:
  push:
    branches: [main, release/*]

jobs:
  frontend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: '20', cache: 'npm' }
      - run: npm ci && npm run build
      - uses: actions/upload-artifact@v4
        with: { name: frontend-dist, path: dist/ }

  backend:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-dotnet@v4
        with: { dotnet-version: '8.0.x' }
      - run: dotnet restore && dotnet build -c Release
      - run: dotnet publish -c Release -o publish
      - uses: actions/upload-artifact@v4
        with: { name: backend-publish, path: publish/ }

  deploy:
    needs: [frontend, backend]
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/download-artifact@v4
        with: { name: frontend-dist, path: dist/ }
      - uses: actions/download-artifact@v4
        with: { name: backend-publish, path: publish/ }
      - name: Deploy to server
        uses: appleboy/ssh-action@v1
        with:
          host: ${{ secrets.SERVER_HOST }}
          username: ${{ secrets.SERVER_USER }}
          key: ${{ secrets.SERVER_SSH_KEY }}
          script: |
            sudo systemctl stop vms-backend
            rsync -av --delete publish/ /opt/vms/backend/
            rsync -av --delete dist/ /var/www/vms/dist/
            sudo systemctl start vms-backend
            sudo nginx -s reload
```

---

## Security Hardening

### Network
- [ ] Firewall: Only ports 80, 443, 5194 (internal), 5000 (internal), 11434 (internal)
- [ ] WAF rules for API endpoints
- [ ] Rate limiting on auth endpoints

### Application
- [ ] HTTPS everywhere
- [ ] Secure headers (CSP, HSTS, X-Frame-Options)
- [ ] CORS restricted to frontend domain
- [ ] JWT with short expiry + refresh tokens
- [ ] Input validation on all endpoints
- [ ] SQL injection prevention (EF Core parameters)

### Database
- [ ] Least privilege database user
- [ ] Encrypted connections (TLS)
- [ ] Regular security patches
- [ ] Audit logging for sensitive operations

### Secrets Management
- [ ] No secrets in code/config files
- [ ] Use Azure Key Vault / AWS Secrets Manager / HashiCorp Vault
- [ ] Rotate keys quarterly
- [ ] Separate secrets per environment

---

## Performance Optimization

### Frontend
- [ ] Enable gzip/brotli compression
- [ ] Configure cache headers for static assets
- [ ] Code splitting with dynamic imports
- [ ] Lazy load heavy components
- [ ] Optimize images (WebP, proper sizing)

### Backend
- [ ] Connection pooling (EF Core default)
- [ ] Query optimization (include/theninclude)
- [ ] Caching for reference data
- [ ] Async/await throughout
- [ ] Pagination for list endpoints

### Database
- [ ] Proper indexes on filter columns
- [ ] Partition large tables by date
- [ ] Update statistics regularly
- [ ] Monitor slow queries

---

## Rollback Procedure

### Quick Rollback (< 5 min)
```bash
# 1. Stop services
sudo systemctl stop vms-backend

# 2. Restore previous build
rsync -av --delete /opt/vms/backend.backup/ /opt/vms/backend/

# 3. Restart
sudo systemctl start vms-backend
sudo nginx -s reload
```

### Database Rollback
```bash
# 1. Stop application
sudo systemctl stop vms-backend

# 2. Restore database
sqlcmd -S localhost -U sa -P "$DB_PASSWORD" \
  -Q "RESTORE DATABASE VMS FROM DISK='/backups/vms/vms_20261009_120000.bak' WITH REPLACE"

# 3. Restart
sudo systemctl start vms-backend
```

---

## Troubleshooting

### Common Issues

| Issue | Cause | Solution |
|-------|-------|----------|
| API 502 | Backend not running | Check systemd service, logs |
| CORS error | Wrong origin | Check backend CORS config |
| Auth failed | JWT expired | Check Supabase config, token refresh |
| Vosk timeout | Large audio | Increase proxy timeout |
| Photos not loading | Storage policy | Check Supabase bucket policies |
| Real-time not working | Realtime disabled | Enable in Supabase dashboard |

### Log Locations
| Service | Location |
|---------|----------|
| Backend | `/var/log/vms/backend-*.log` |
| Nginx | `/var/log/nginx/access.log`, `error.log` |
| Vosk | `docker logs vms-vosk` |
| Systemd | `journalctl -u vms-backend -f` |

---

## Scaling Considerations

### Horizontal Scaling
- **Frontend:** Static files served by CDN (CloudFront, Cloudflare)
- **Backend:** Multiple instances behind load balancer
- **Database:** Read replicas for reporting queries
- **Vosk/Ollama:** Separate GPU instances per service

### Session Affinity
- Not required (stateless JWT auth)
- Supabase Realtime handles connection management

---

## Maintenance Windows

| Task | Frequency | Window |
|------|-----------|--------|
| Security patches | Monthly | Sunday 2-4 AM |
| Database maintenance | Weekly | Sunday 3-4 AM |
| Log rotation | Daily | Automatic |
| Backup verification | Weekly | Monday 9 AM |
| Dependency updates | Monthly | Sprint planning |

---

## Contact & Support

| Role | Contact | Escalation |
|------|---------|------------|
| DevOps | devops@company.com | PagerDuty |
| Backend Team | backend@company.com | Slack #vms-backend |
| Frontend Team | frontend@company.com | Slack #vms-frontend |
| DBA | dba@company.com | Phone (critical) |

---

## Appendix: Port Reference

| Service | Port | Protocol | Access |
|---------|------|----------|--------|
| Frontend (Nginx) | 80/443 | HTTP/HTTPS | Public |
| Backend API | 5194 | HTTP | Internal |
| Backend HTTPS | 5195 | HTTPS | Internal |
| Vosk | 5000 | HTTP | Internal |
| Ollama | 11434 | HTTP | Internal |
| SQL Server | 1433 | TCP | Internal |
| Supabase | 443 | HTTPS | Public |

---

*Deployment Guide Version: 1.0 | Last Updated: 2026-10-10*