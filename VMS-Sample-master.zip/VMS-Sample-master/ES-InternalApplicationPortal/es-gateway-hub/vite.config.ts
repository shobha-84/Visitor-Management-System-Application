import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  base: "/ESVMSPortalApp/", 
  server: {
    host: "::",
    port: 8080,
    hmr: {
      overlay: false,
    },
    // Dev server runs on :8080; IIS API runs on :80 — proxy API calls to backend
    proxy: {
        "/ExcelSoftVMSPortal": {
            target: "http://localhost:5194",
            changeOrigin: true,
            secure: false,
            rewrite: (path) => path.replace(/^\/ExcelSoftVMSPortal/, ""),
        },
        "/ollama": {
        target: "http://localhost:11434",
        changeOrigin: true,
        secure: false,
        rewrite: (path) => path.replace(/^\/ollama/, ""),
      },
    },
  },
  plugins: [react(), mode === "development" && componentTagger()].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
    dedupe: ["react", "react-dom", "react/jsx-runtime", "react/jsx-dev-runtime"],
  },
}));