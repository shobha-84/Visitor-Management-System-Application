
-- Create ticket priority and status enums
CREATE TYPE public.ticket_priority AS ENUM ('low', 'medium', 'high', 'critical');
CREATE TYPE public.ticket_status AS ENUM ('open', 'in_progress', 'resolved', 'closed');
CREATE TYPE public.ticket_category AS ENUM ('it_hardware', 'it_software', 'it_network', 'facilities', 'hr', 'admin', 'other');

-- Create helpdesk_tickets table
CREATE TABLE public.helpdesk_tickets (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  ticket_number TEXT NOT NULL UNIQUE,
  created_by UUID NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  category public.ticket_category NOT NULL DEFAULT 'other',
  priority public.ticket_priority NOT NULL DEFAULT 'medium',
  status public.ticket_status NOT NULL DEFAULT 'open',
  assigned_to UUID,
  resolved_at TIMESTAMP WITH TIME ZONE,
  resolved_by UUID,
  resolution_notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.helpdesk_tickets ENABLE ROW LEVEL SECURITY;

-- Users can view their own tickets
CREATE POLICY "Users can view own tickets"
ON public.helpdesk_tickets FOR SELECT TO authenticated
USING (created_by = auth.uid());

-- Users can create tickets
CREATE POLICY "Users can create tickets"
ON public.helpdesk_tickets FOR INSERT TO authenticated
WITH CHECK (created_by = auth.uid());

-- IT managers and system admins can view all tickets
CREATE POLICY "Support staff can view all tickets"
ON public.helpdesk_tickets FOR SELECT TO authenticated
USING (
  has_role(auth.uid(), 'it_manager'::app_role) OR
  has_role(auth.uid(), 'employee_system_admin'::app_role) OR
  has_role(auth.uid(), 'employee_system'::app_role)
);

-- Support staff can update tickets
CREATE POLICY "Support staff can update tickets"
ON public.helpdesk_tickets FOR UPDATE TO authenticated
USING (
  created_by = auth.uid() OR
  has_role(auth.uid(), 'it_manager'::app_role) OR
  has_role(auth.uid(), 'employee_system_admin'::app_role) OR
  has_role(auth.uid(), 'employee_system'::app_role)
);

-- Function to generate ticket number
CREATE OR REPLACE FUNCTION public.generate_ticket_number()
RETURNS TRIGGER AS $$
BEGIN
  NEW.ticket_number := 'TKT-' || LPAD(nextval('helpdesk_ticket_seq')::text, 5, '0');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE SEQUENCE IF NOT EXISTS public.helpdesk_ticket_seq START WITH 1;

CREATE TRIGGER set_ticket_number
  BEFORE INSERT ON public.helpdesk_tickets
  FOR EACH ROW
  EXECUTE FUNCTION public.generate_ticket_number();
