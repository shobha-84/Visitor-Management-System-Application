CREATE POLICY "Users can delete own draft invitations"
ON public.visitor_invitations
FOR DELETE
TO authenticated
USING (auth.uid() = created_by AND status = 'draft'::invitation_status);