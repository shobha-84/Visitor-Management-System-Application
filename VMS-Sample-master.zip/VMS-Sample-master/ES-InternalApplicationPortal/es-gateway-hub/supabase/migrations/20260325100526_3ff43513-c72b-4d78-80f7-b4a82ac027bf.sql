
DROP POLICY IF EXISTS "Approvers can update pending invitations" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Users can update own draft invitations" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Facilitators can update notes" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Security can update for checkin checkout" ON public.visitor_invitations;

CREATE POLICY "Authenticated users can update invitations"
ON public.visitor_invitations
FOR UPDATE TO authenticated
USING (true)
WITH CHECK (true);
