
-- Drop existing approver update policy
DROP POLICY IF EXISTS "Approvers can update pending invitations" ON public.visitor_invitations;

-- Recreate with fix: allow approvers to approve/reject pending invitations
-- even when they are the creator (self-approval scenario)
CREATE POLICY "Approvers can update pending invitations"
ON public.visitor_invitations
FOR UPDATE TO authenticated
USING (
  (has_role(auth.uid(), 'employee_approver_non_technical') OR has_role(auth.uid(), 'employee_approver_technical'))
  AND status = 'pending'::invitation_status
)
WITH CHECK (
  (has_role(auth.uid(), 'employee_approver_non_technical') OR has_role(auth.uid(), 'employee_approver_technical'))
  AND (
    (status = 'approved'::invitation_status AND approved_by = auth.uid() AND approved_at IS NOT NULL)
    OR
    (status = 'rejected'::invitation_status AND rejected_by = auth.uid() AND rejected_at IS NOT NULL AND rejection_reason IS NOT NULL)
  )
);
