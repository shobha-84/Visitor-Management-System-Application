
-- Create invitation status enum
CREATE TYPE public.invitation_status AS ENUM ('draft', 'pending', 'approved', 'rejected', 'checked_in', 'checked_out');

-- Create visitor_invitations table
CREATE TABLE public.visitor_invitations (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  visitor_name TEXT NOT NULL,
  visitor_company TEXT,
  visitor_email TEXT,
  visitor_phone TEXT,
  visit_start_date DATE NOT NULL,
  visit_end_date DATE NOT NULL,
  visit_start_time TIME NOT NULL,
  visit_end_time TIME NOT NULL,
  purpose TEXT NOT NULL,
  department TEXT NOT NULL,
  additional_requirements TEXT,
  status invitation_status NOT NULL DEFAULT 'draft',
  approved_by UUID REFERENCES auth.users(id),
  approved_at TIMESTAMPTZ,
  rejected_by UUID REFERENCES auth.users(id),
  rejected_at TIMESTAMPTZ,
  rejection_reason TEXT,
  checked_in_by UUID REFERENCES auth.users(id),
  checked_in_at TIMESTAMPTZ,
  checked_out_by UUID REFERENCES auth.users(id),
  checked_out_at TIMESTAMPTZ,
  visitor_photo_url TEXT,
  facilitator_notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.visitor_invitations ENABLE ROW LEVEL SECURITY;

-- Trigger for updated_at
CREATE TRIGGER update_visitor_invitations_updated_at
  BEFORE UPDATE ON public.visitor_invitations
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Policy: Employees can view their own invitations
CREATE POLICY "Users can view own invitations"
  ON public.visitor_invitations FOR SELECT TO authenticated
  USING (auth.uid() = created_by);

-- Policy: Employees can insert invitations
CREATE POLICY "Users can create invitations"
  ON public.visitor_invitations FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);

-- Policy: Employees can update their own draft/rejected invitations
CREATE POLICY "Users can update own draft invitations"
  ON public.visitor_invitations FOR UPDATE TO authenticated
  USING (auth.uid() = created_by AND status IN ('draft', 'rejected'));

-- Policy: Approvers can view pending invitations
CREATE POLICY "Approvers can view pending invitations"
  ON public.visitor_invitations FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'employee_approver_non_technical') AND status = 'pending');

-- Policy: Approvers can update pending invitations (approve/reject)
CREATE POLICY "Approvers can update pending invitations"
  ON public.visitor_invitations FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'employee_approver_non_technical') AND status = 'pending');

-- Policy: Security can view approved/checked_in invitations
CREATE POLICY "Security can view approved invitations"
  ON public.visitor_invitations FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'employee_security') AND status IN ('approved', 'checked_in'));

-- Policy: Security can update approved/checked_in invitations (check-in/out)
CREATE POLICY "Security can update for checkin checkout"
  ON public.visitor_invitations FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'employee_security') AND status IN ('approved', 'checked_in'));

-- Policy: Facilitators can view approved invitations
CREATE POLICY "Facilitators can view approved invitations"
  ON public.visitor_invitations FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'employee_facilitator') AND status IN ('approved', 'checked_in', 'checked_out'));

-- Policy: Facilitators can update facilitator_notes on approved invitations
CREATE POLICY "Facilitators can update notes"
  ON public.visitor_invitations FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'employee_facilitator') AND status IN ('approved', 'checked_in', 'checked_out'));

-- Create storage bucket for visitor photos
INSERT INTO storage.buckets (id, name, public) VALUES ('visitor-photos', 'visitor-photos', true);

-- Storage policy: Security can upload visitor photos
CREATE POLICY "Security can upload visitor photos"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'visitor-photos' AND public.has_role(auth.uid(), 'employee_security'));

-- Storage policy: Anyone authenticated can view visitor photos
CREATE POLICY "Authenticated users can view visitor photos"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'visitor-photos');
