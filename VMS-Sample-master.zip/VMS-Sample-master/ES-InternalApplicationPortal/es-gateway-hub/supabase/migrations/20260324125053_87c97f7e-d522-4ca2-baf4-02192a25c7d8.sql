
-- Allow service role to manage user_roles (edge function uses service role key)
-- Add delete policy for user_roles managed by system admin via edge function
CREATE POLICY "Service role can manage roles"
ON public.user_roles
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);
