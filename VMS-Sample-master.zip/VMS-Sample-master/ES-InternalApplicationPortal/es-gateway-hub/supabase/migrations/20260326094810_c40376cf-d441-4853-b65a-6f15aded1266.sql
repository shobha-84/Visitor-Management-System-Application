DROP POLICY IF EXISTS "Managers and execs can view all requests" ON store_requests;
CREATE POLICY "Managers and execs can view all requests" ON store_requests
FOR SELECT TO authenticated
USING (
  has_role(auth.uid(), 'manager_technical') OR
  has_role(auth.uid(), 'manager_non_technical') OR
  has_role(auth.uid(), 'manager_store') OR
  has_role(auth.uid(), 'manager_hr') OR
  has_role(auth.uid(), 'director') OR
  has_role(auth.uid(), 'coo') OR
  has_role(auth.uid(), 'ceo') OR
  has_role(auth.uid(), 'employee_system_admin') OR
  has_role(auth.uid(), 'ops_manager') OR
  has_role(auth.uid(), 'it_manager') OR
  has_role(auth.uid(), 'finance') OR
  has_role(auth.uid(), 'purchase_hr')
);

DROP POLICY IF EXISTS "Approvers can update requests" ON store_requests;
CREATE POLICY "Approvers can update requests" ON store_requests
FOR UPDATE TO authenticated
USING (
  created_by = auth.uid() OR
  has_role(auth.uid(), 'manager_technical') OR
  has_role(auth.uid(), 'manager_non_technical') OR
  has_role(auth.uid(), 'manager_store') OR
  has_role(auth.uid(), 'manager_hr') OR
  has_role(auth.uid(), 'director') OR
  has_role(auth.uid(), 'coo') OR
  has_role(auth.uid(), 'ceo') OR
  has_role(auth.uid(), 'employee_system_admin') OR
  has_role(auth.uid(), 'ops_manager') OR
  has_role(auth.uid(), 'it_manager') OR
  has_role(auth.uid(), 'finance') OR
  has_role(auth.uid(), 'purchase_hr')
);