INSERT INTO storage.buckets (id, name, public) VALUES ('helpdesk-attachments', 'helpdesk-attachments', true);

CREATE POLICY "Authenticated users can upload attachments"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'helpdesk-attachments');

CREATE POLICY "Anyone can view attachments"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'helpdesk-attachments');