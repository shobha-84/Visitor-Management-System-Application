
-- Create enum for request categories
CREATE TYPE public.store_request_category AS ENUM ('product', 'software_service', 'people');

-- Create enum for request status
CREATE TYPE public.store_request_status AS ENUM (
  'draft',
  'pending_ops_manager',
  'pending_it_manager', 
  'pending_coo',
  'pending_finance',
  'pending_hr',
  'pending_purchase',
  'finance_authorized',
  'approved',
  'rejected',
  'po_released'
);

-- Create store requests table
CREATE TABLE public.store_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  created_by UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  category store_request_category NOT NULL,
  is_it_related BOOLEAN NOT NULL DEFAULT false,
  estimated_cost NUMERIC(12,2),
  quantity INTEGER DEFAULT 1,
  urgency TEXT DEFAULT 'normal' CHECK (urgency IN ('low', 'normal', 'high', 'critical')),
  status store_request_status NOT NULL DEFAULT 'draft',
  current_approver_role TEXT,
  rejection_reason TEXT,
  department TEXT,
  vendor_details TEXT,
  notes TEXT,
  
  -- Approval tracking
  ops_manager_approved_by UUID,
  ops_manager_approved_at TIMESTAMPTZ,
  it_manager_approved_by UUID,
  it_manager_approved_at TIMESTAMPTZ,
  coo_approved_by UUID,
  coo_approved_at TIMESTAMPTZ,
  finance_authorized_by UUID,
  finance_authorized_at TIMESTAMPTZ,
  hr_approved_by UUID,
  hr_approved_at TIMESTAMPTZ,
  po_released_by UUID,
  po_released_at TIMESTAMPTZ,
  
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.store_requests ENABLE ROW LEVEL SECURITY;

-- Policy: users can view their own requests
CREATE POLICY "Users can view own requests"
  ON public.store_requests FOR SELECT
  TO authenticated
  USING (created_by = auth.uid());

-- Policy: managers, directors, COO, CEO can view all requests
CREATE POLICY "Managers and execs can view all requests"
  ON public.store_requests FOR SELECT
  TO authenticated
  USING (
    public.has_role(auth.uid(), 'manager_technical') OR
    public.has_role(auth.uid(), 'manager_non_technical') OR
    public.has_role(auth.uid(), 'manager_store') OR
    public.has_role(auth.uid(), 'manager_hr') OR
    public.has_role(auth.uid(), 'director') OR
    public.has_role(auth.uid(), 'coo') OR
    public.has_role(auth.uid(), 'ceo') OR
    public.has_role(auth.uid(), 'employee_system_admin')
  );

-- Policy: authenticated users can create requests
CREATE POLICY "Authenticated users can create requests"
  ON public.store_requests FOR INSERT
  TO authenticated
  WITH CHECK (created_by = auth.uid());

-- Policy: approvers can update requests (for approval actions)
CREATE POLICY "Approvers can update requests"
  ON public.store_requests FOR UPDATE
  TO authenticated
  USING (
    created_by = auth.uid() OR
    public.has_role(auth.uid(), 'manager_technical') OR
    public.has_role(auth.uid(), 'manager_non_technical') OR
    public.has_role(auth.uid(), 'manager_store') OR
    public.has_role(auth.uid(), 'manager_hr') OR
    public.has_role(auth.uid(), 'director') OR
    public.has_role(auth.uid(), 'coo') OR
    public.has_role(auth.uid(), 'ceo') OR
    public.has_role(auth.uid(), 'employee_system_admin')
  );

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.store_requests;
