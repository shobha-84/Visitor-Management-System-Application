
-- Add new enum values
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'purchase';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'hr';
