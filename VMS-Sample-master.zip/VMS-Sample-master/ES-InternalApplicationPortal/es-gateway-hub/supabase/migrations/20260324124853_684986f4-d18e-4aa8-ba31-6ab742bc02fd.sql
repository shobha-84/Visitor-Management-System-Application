
-- Add new roles to the enum
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'employee_system';
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'employee_system_admin';
