ALTER TYPE store_request_status ADD VALUE IF NOT EXISTS 'pending_hr_po_release';
ALTER TYPE store_request_status ADD VALUE IF NOT EXISTS 'pending_ops_info';