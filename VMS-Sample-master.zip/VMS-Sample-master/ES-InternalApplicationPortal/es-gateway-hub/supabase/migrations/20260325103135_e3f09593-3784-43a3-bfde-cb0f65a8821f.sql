-- Fix visitor_invitations RLS so status transitions remain visible after UPDATE
-- and tighten WITH CHECK clauses to avoid permissive true policies.

DROP POLICY IF EXISTS "Approvers can update pending invitations" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Approvers can view pending invitations" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Users can update own draft invitations" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Security can update for checkin checkout" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Security can view approved invitations" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Facilitators can update notes" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Facilitators can view approved invitations" ON public.visitor_invitations;

CREATE POLICY "Approvers can view actionable invitations"
ON public.visitor_invitations
FOR SELECT TO authenticated
USING (
  (has_role(auth.uid(), 'employee_approver_non_technical'::app_role)
   OR has_role(auth.uid(), 'employee_approver_technical'::app_role))
  AND (
    status = 'pending'::invitation_status
    OR approved_by = auth.uid()
    OR rejected_by = auth.uid()
  )
);

CREATE POLICY "Approvers can update pending invitations"
ON public.visitor_invitations
FOR UPDATE TO authenticated
USING (
  (has_role(auth.uid(), 'employee_approver_non_technical'::app_role)
   OR has_role(auth.uid(), 'employee_approver_technical'::app_role))
  AND status = 'pending'::invitation_status
)
WITH CHECK (
  (has_role(auth.uid(), 'employee_approver_non_technical'::app_role)
   OR has_role(auth.uid(), 'employee_approver_technical'::app_role))
  AND (
    (status = 'approved'::invitation_status
      AND approved_by = auth.uid()
      AND approved_at IS NOT NULL
      AND rejected_by IS NULL
      AND rejected_at IS NULL)
    OR
    (status = 'rejected'::invitation_status
      AND rejected_by = auth.uid()
      AND rejected_at IS NOT NULL
      AND rejection_reason IS NOT NULL
      AND approved_by IS NULL
      AND approved_at IS NULL)
  )
);

CREATE POLICY "Users can update own draft invitations"
ON public.visitor_invitations
FOR UPDATE TO authenticated
USING (
  auth.uid() = created_by
  AND status IN ('draft'::invitation_status, 'rejected'::invitation_status)
)
WITH CHECK (
  auth.uid() = created_by
  AND status IN ('draft'::invitation_status, 'pending'::invitation_status)
);

CREATE POLICY "Security can view workflow invitations"
ON public.visitor_invitations
FOR SELECT TO authenticated
USING (
  has_role(auth.uid(), 'employee_security'::app_role)
  AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status)
);

CREATE POLICY "Security can update for checkin checkout"
ON public.visitor_invitations
FOR UPDATE TO authenticated
USING (
  has_role(auth.uid(), 'employee_security'::app_role)
  AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status)
)
WITH CHECK (
  has_role(auth.uid(), 'employee_security'::app_role)
  AND (
    status = 'approved'::invitation_status
    OR (status = 'checked_in'::invitation_status AND checked_in_by = auth.uid() AND checked_in_at IS NOT NULL)
    OR (status = 'checked_out'::invitation_status AND checked_out_by = auth.uid() AND checked_out_at IS NOT NULL)
  )
);

CREATE POLICY "Facilitators can view approved invitations"
ON public.visitor_invitations
FOR SELECT TO authenticated
USING (
  has_role(auth.uid(), 'employee_facilitator'::app_role)
  AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status)
);

CREATE POLICY "Facilitators can update notes"
ON public.visitor_invitations
FOR UPDATE TO authenticated
USING (
  has_role(auth.uid(), 'employee_facilitator'::app_role)
  AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status)
)
WITH CHECK (
  has_role(auth.uid(), 'employee_facilitator'::app_role)
  AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status)
);
