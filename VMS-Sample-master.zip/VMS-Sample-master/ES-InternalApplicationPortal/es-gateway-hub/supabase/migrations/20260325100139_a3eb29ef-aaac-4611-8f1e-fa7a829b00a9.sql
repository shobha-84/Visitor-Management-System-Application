
DROP POLICY IF EXISTS "Approvers can update pending invitations" ON public.visitor_invitations;
CREATE POLICY "Approvers can update pending invitations"
ON public.visitor_invitations
FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'employee_approver_non_technical'::app_role) AND status = 'pending'::invitation_status)
WITH CHECK (true);
