
-- Drop ALL existing UPDATE policies on visitor_invitations
DROP POLICY IF EXISTS "Approvers can update pending invitations" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Users can update own draft invitations" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Security can update for checkin checkout" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Facilitators can update notes" ON public.visitor_invitations;
DROP POLICY IF EXISTS "Authenticated users can update invitations" ON public.visitor_invitations;

-- Approvers: can read pending rows and change them to approved/rejected
CREATE POLICY "Approvers can update pending invitations"
ON public.visitor_invitations FOR UPDATE TO authenticated
USING (
  (has_role(auth.uid(), 'employee_approver_non_technical'::app_role) OR has_role(auth.uid(), 'employee_approver_technical'::app_role))
  AND status = 'pending'::invitation_status
)
WITH CHECK (true);

-- Owners: can update their own draft/rejected invitations
CREATE POLICY "Users can update own draft invitations"
ON public.visitor_invitations FOR UPDATE TO authenticated
USING (auth.uid() = created_by AND status IN ('draft'::invitation_status, 'rejected'::invitation_status))
WITH CHECK (true);

-- Security: can update approved/checked_in rows
CREATE POLICY "Security can update for checkin checkout"
ON public.visitor_invitations FOR UPDATE TO authenticated
USING (
  has_role(auth.uid(), 'employee_security'::app_role)
  AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status)
)
WITH CHECK (true);

-- Facilitators: can update notes on active invitations
CREATE POLICY "Facilitators can update notes"
ON public.visitor_invitations FOR UPDATE TO authenticated
USING (
  has_role(auth.uid(), 'employee_facilitator'::app_role)
  AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status)
)
WITH CHECK (true);
