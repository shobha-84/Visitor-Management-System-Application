
-- Drop and recreate approver update policy with proper WITH CHECK
DROP POLICY IF EXISTS "Approvers can update pending invitations" ON public.visitor_invitations;
CREATE POLICY "Approvers can update pending invitations"
ON public.visitor_invitations
FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'employee_approver_non_technical'::app_role) AND status = 'pending'::invitation_status)
WITH CHECK (has_role(auth.uid(), 'employee_approver_non_technical'::app_role) AND status IN ('approved'::invitation_status, 'rejected'::invitation_status));

-- Fix security update policy too
DROP POLICY IF EXISTS "Security can update for checkin checkout" ON public.visitor_invitations;
CREATE POLICY "Security can update for checkin checkout"
ON public.visitor_invitations
FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'employee_security'::app_role) AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status))
WITH CHECK (has_role(auth.uid(), 'employee_security'::app_role) AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status));

-- Fix facilitator update policy too
DROP POLICY IF EXISTS "Facilitators can update notes" ON public.visitor_invitations;
CREATE POLICY "Facilitators can update notes"
ON public.visitor_invitations
FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'employee_facilitator'::app_role) AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status))
WITH CHECK (has_role(auth.uid(), 'employee_facilitator'::app_role) AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status));
