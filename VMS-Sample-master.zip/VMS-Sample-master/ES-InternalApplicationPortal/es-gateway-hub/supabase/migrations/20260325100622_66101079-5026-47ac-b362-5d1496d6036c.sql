
-- Restore proper UPDATE policies
DROP POLICY IF EXISTS "Authenticated users can update invitations" ON public.visitor_invitations;

CREATE POLICY "Approvers can update pending invitations"
ON public.visitor_invitations FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'employee_approver_non_technical'::app_role) AND status = 'pending'::invitation_status)
WITH CHECK (has_role(auth.uid(), 'employee_approver_non_technical'::app_role) AND status IN ('approved'::invitation_status, 'rejected'::invitation_status));

CREATE POLICY "Users can update own draft invitations"
ON public.visitor_invitations FOR UPDATE TO authenticated
USING (auth.uid() = created_by AND status IN ('draft'::invitation_status, 'rejected'::invitation_status))
WITH CHECK (auth.uid() = created_by AND status IN ('draft'::invitation_status, 'pending'::invitation_status));

CREATE POLICY "Security can update for checkin checkout"
ON public.visitor_invitations FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'employee_security'::app_role) AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status))
WITH CHECK (has_role(auth.uid(), 'employee_security'::app_role) AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status));

CREATE POLICY "Facilitators can update notes"
ON public.visitor_invitations FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'employee_facilitator'::app_role) AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status))
WITH CHECK (has_role(auth.uid(), 'employee_facilitator'::app_role) AND status IN ('approved'::invitation_status, 'checked_in'::invitation_status, 'checked_out'::invitation_status));
