import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.1";

// Helper for admin auth API calls via REST
async function adminAuthRequest(supabaseUrl: string, serviceKey: string, method: string, path: string, body?: any) {
  const res = await fetch(`${supabaseUrl}/auth/v1/admin/${path}`, {
    method,
    headers: {
      "Authorization": `Bearer ${serviceKey}`,
      "apikey": serviceKey,
      "Content-Type": "application/json",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json();
  if (!res.ok) return { data: null, error: data };
  return { data, error: null };
}

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Verify calling user is system_admin
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // Use service role client to verify the user's JWT (bypasses session check)
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);
    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: userError } = await adminClient.auth.getUser(token);
    if (userError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Check if user has employee_system_admin role
    // Check if user has employee_system_admin role (adminClient already created above)
    const { data: roleData } = await adminClient
      .from("user_roles")
      .select("role")
      .eq("user_id", user.id)
      .eq("role", "employee_system_admin")
      .single();

    if (!roleData) {
      return new Response(JSON.stringify({ error: "Forbidden: System Admin role required" }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { action, ...payload } = await req.json();

    switch (action) {
      case "list_users": {
        const { data: profiles } = await adminClient
          .from("profiles")
          .select("user_id, full_name, employee_id, department, location, created_at");
        
        // Get all roles
        const { data: allRoles } = await adminClient
          .from("user_roles")
          .select("user_id, role");

        // Get user emails from auth
        const { data: authListData } = await adminAuthRequest(supabaseUrl, supabaseServiceKey, "GET", "users?per_page=1000");
        const authUsers = authListData?.users ?? authListData ?? [];

        const userMap = new Map<string, any>();
        authUsers?.forEach((u: any) => {
          userMap.set(u.id, {
            id: u.id,
            email: u.email,
            email_confirmed: !!u.email_confirmed_at,
            disabled: u.banned_until ? new Date(u.banned_until) > new Date() : false,
            created_at: u.created_at,
            full_name: null,
            employee_id: null,
            department: null,
            location: null,
            roles: [] as string[],
          });
        });

        profiles?.forEach((p: any) => {
          const existing = userMap.get(p.user_id);
          if (existing) {
            existing.full_name = p.full_name;
            existing.employee_id = p.employee_id;
            existing.department = p.department;
            existing.location = p.location;
          }
        });

        allRoles?.forEach((r: any) => {
          const existing = userMap.get(r.user_id);
          if (existing) existing.roles.push(r.role);
        });

        return new Response(JSON.stringify({ users: Array.from(userMap.values()) }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "create_user": {
        const { email, password, full_name, employee_id, department, location, roles } = payload;
        if (!email || !password) {
          return new Response(JSON.stringify({ error: "Email and password required" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const { data: newUserData, error: createError } = await adminAuthRequest(supabaseUrl, supabaseServiceKey, "POST", "users", {
          email,
          password,
          email_confirm: true,
          user_metadata: { full_name: full_name || "" },
        });
        const newUser = { user: newUserData };

        if (createError) {
          return new Response(JSON.stringify({ error: createError.msg || createError.message || JSON.stringify(createError) }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // Update profile with extra fields if provided
        const profileUpdate: any = {};
        if (employee_id) profileUpdate.employee_id = employee_id;
        if (department) profileUpdate.department = department;
        if (location) profileUpdate.location = location;
        if (Object.keys(profileUpdate).length > 0) {
          await adminClient
            .from("profiles")
            .update(profileUpdate)
            .eq("user_id", newUser.user.id);
        }

        // Assign roles
        if (roles && roles.length > 0) {
          const roleInserts = roles.map((role: string) => ({
            user_id: newUser.user.id,
            role,
          }));
          await adminClient.from("user_roles").insert(roleInserts);
        }

        return new Response(JSON.stringify({
          success: true,
          user: { id: newUser.user.id, email },
          credentials: { email, password },
        }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "update_user": {
        const { user_id, full_name, employee_id, department, location, roles: newRoles, disabled } = payload;
        if (!user_id) {
          return new Response(JSON.stringify({ error: "user_id required" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        // Update email if provided
        if (payload.email) {
          const { error: emailError } = await adminAuthRequest(supabaseUrl, supabaseServiceKey, "PUT", `users/${user_id}`, {
            email: payload.email,
          });
          if (emailError) {
            return new Response(JSON.stringify({ error: emailError.msg || emailError.message || JSON.stringify(emailError) }), {
              status: 400,
              headers: { ...corsHeaders, "Content-Type": "application/json" },
            });
          }
        }

        // Update profile
        if (full_name !== undefined || employee_id !== undefined || department !== undefined || location !== undefined) {
          const updateData: any = {};
          if (full_name !== undefined) updateData.full_name = full_name;
          if (employee_id !== undefined) updateData.employee_id = employee_id;
          if (department !== undefined) updateData.department = department;
          if (location !== undefined) updateData.location = location;
          await adminClient.from("profiles").update(updateData).eq("user_id", user_id);
        }

        // Update disabled status
        if (disabled !== undefined) {
          if (disabled) {
           await adminAuthRequest(supabaseUrl, supabaseServiceKey, "PUT", `users/${user_id}`, {
              ban_duration: "876000h",
            });
          } else {
            await adminAuthRequest(supabaseUrl, supabaseServiceKey, "PUT", `users/${user_id}`, {
              ban_duration: "none",
            });
          }
        }

        // Update roles if provided
        if (newRoles !== undefined) {
          await adminClient.from("user_roles").delete().eq("user_id", user_id);
          if (newRoles.length > 0) {
            const roleInserts = newRoles.map((role: string) => ({
              user_id,
              role,
            }));
            await adminClient.from("user_roles").insert(roleInserts);
          }
        }

        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      case "reset_password": {
        const { user_id, new_password } = payload;
        if (!user_id || !new_password) {
          return new Response(JSON.stringify({ error: "user_id and new_password required" }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        const { error: resetError } = await adminAuthRequest(supabaseUrl, supabaseServiceKey, "PUT", `users/${user_id}`, {
          password: new_password,
        });

        if (resetError) {
          return new Response(JSON.stringify({ error: resetError.msg || resetError.message || JSON.stringify(resetError) }), {
            status: 400,
            headers: { ...corsHeaders, "Content-Type": "application/json" },
          });
        }

        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }

      default:
        return new Response(JSON.stringify({ error: "Unknown action" }), {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
    }
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
