

## Plan: Create `src/api/http.ts`

Create a utility module that exports an `apiFetch` wrapper around the native `fetch` API. This will resolve the build error caused by the missing module.

### File to create

**`src/api/http.ts`** — A thin wrapper that:
- Accepts a URL path and standard `RequestInit` options
- Sets `Content-Type: application/json` by default
- Includes the Supabase auth token (from the current session) in the `Authorization` header
- Throws an error with the response message if the request fails
- Returns the parsed JSON response

This is the only change needed to fix the build error.

