# Deploy es-gateway-hub build output to IIS (ESVMSPortalApp)
# Usage: .\deploy-iis.ps1 -TargetPath "C:\inetpub\wwwroot\ESVMSPortalApp"

param(
    [string]$TargetPath = "D:\Publishedfrontend"
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

Write-Host "Building frontend..." -ForegroundColor Cyan
Push-Location $ProjectRoot
yarn build
if ($LASTEXITCODE -ne 0) { Pop-Location; exit 1 }
Pop-Location

$Source = Join-Path $ProjectRoot "dist"
if (-not (Test-Path $Source)) {
    Write-Error "Build output not found at $Source"
}

Write-Host "Deploying to $TargetPath ..." -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $TargetPath | Out-Null
Copy-Item -Path "$Source\*" -Destination $TargetPath -Recurse -Force

Write-Host "Verifying bundle does not contain https://localhost ..." -ForegroundColor Cyan
$bad = Select-String -Path "$TargetPath\assets\*.js" -Pattern "https://localhost" -SimpleMatch
if ($bad) {
    Write-Warning "Found https://localhost in deployed JS!"
    Get-ChildItem "$TargetPath\assets\*.js" | Where-Object { $_.Name -ne (Select-String -Path "$TargetPath\index.html" -Pattern 'assets/(index-[^"]+\.js)' | ForEach-Object { $_.Matches.Groups[1].Value }) } | Remove-Item -Force -ErrorAction SilentlyContinue
}

Write-Host "Done. Hard-refresh browser (Ctrl+Shift+R) and retry Submit." -ForegroundColor Green
