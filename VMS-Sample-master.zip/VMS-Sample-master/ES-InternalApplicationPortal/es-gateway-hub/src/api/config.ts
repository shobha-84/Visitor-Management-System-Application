// This should be enable when we work in local environment (with Vite proxy)
const DEFAULT_API_BASE = "/ExcelSoftVMSPortal";
// This should be enabled when we work in testing or prod environment
// const DEFAULT_API_BASE = "/ExcelSoftVMSPortal";

/**
 * Returns a path-only API base so requests always use the same protocol
 * as the page (http on IIS port 80). Absolute https:// URLs break POST on HTTP-hosted sites.
 */
export function getApiBase(): string {
  const raw = (import.meta.env.VITE_API_URL || DEFAULT_API_BASE).trim();

  if (raw.startsWith("http://") || raw.startsWith("https://")) {
    try {
      return new URL(raw).pathname.replace(/\/$/, "") || DEFAULT_API_BASE;
    } catch {
      return DEFAULT_API_BASE;
    }
  }

  const path = raw.startsWith("/") ? raw : `/${raw}`;
  return path.replace(/\/$/, "") || DEFAULT_API_BASE;
}
