import axios from "axios";
import { getApiBase } from "./config";

const API_BASE_URL = getApiBase();

export async function uploadVisitorPhoto(
  invitationId: string,
  file: File,
  token: string
) {
  const formData = new FormData();

  // ✅ "photo" MUST match controller parameter name
  formData.append("photo", file);

  return axios.post(
    `${API_BASE_URL}/api/visitor-invitations/${invitationId}/photo`,
    formData,
    {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "multipart/form-data",
      },
    }
  );
}

// ADD OR REMOVE VISITORS
export const addAdditionalVisitor = async (id, payload, token) => {
  await fetch(`${API_BASE_URL}/api/visitor-invitations/${id}/additional-visitors`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify(payload)
  });
};

export const removeAdditionalVisitor = async (id, token) => {
  await fetch(`${API_BASE_URL}/api/visitor-invitations/additional-visitors/${id}`, {
    method: "DELETE",
    headers: { Authorization: `Bearer ${token}` }
  });
};
