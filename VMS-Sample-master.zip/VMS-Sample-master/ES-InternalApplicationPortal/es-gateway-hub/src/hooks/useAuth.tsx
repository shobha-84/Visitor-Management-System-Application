// import { useState, useEffect, createContext, useContext, ReactNode } from 'react';
// import { supabase } from '@/integrations/supabase/client';
// import type { User, Session } from '@supabase/supabase-js';
// import type { Database } from '@/integrations/supabase/types';

// type AppRole = Database['public']['Enums']['app_role'];

// interface AuthContextType {
//   user: User | null;
//   session: Session | null;
//   roles: AppRole[];
//   profile: { full_name: string | null; employee_id: string | null; designation: string | null; department: string | null; location: string | null; contact_number: string | null } | null;
//   loading: boolean;
//   signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
//   signUp: (email: string, password: string, fullName: string) => Promise<{ error: Error | null }>;
//   signOut: () => Promise<void>;
// }

// const AuthContext = createContext<AuthContextType | undefined>(undefined);

// export function AuthProvider({ children }: { children: ReactNode }) {
//   const [user, setUser] = useState<User | null>(null);
//   const [session, setSession] = useState<Session | null>(null);
//   const [roles, setRoles] = useState<AppRole[]>([]);
//   const [profile, setProfile] = useState<{ full_name: string | null; employee_id: string | null; designation: string | null; department: string | null; location: string | null; contact_number: string | null } | null>(null);
//   const [loading, setLoading] = useState(true);

//   const fetchUserData = async (userId: string) => {
//     const [rolesRes, profileRes] = await Promise.all([
//       supabase.from('user_roles').select('role').eq('user_id', userId),
//       supabase.from('profiles').select('full_name, employee_id, designation, department, location, contact_number').eq('user_id', userId).single(),
//     ]);
//     if (rolesRes.data) setRoles(rolesRes.data.map(r => r.role));
//     if (profileRes.data) setProfile(profileRes.data);
//   };

//   useEffect(() => {
//     const { data: { subscription } } = supabase.auth.onAuthStateChange(
//       async (_event, session) => {
//         setSession(session);
//         setUser(session?.user ?? null);
//         if (session?.user) {
//           setTimeout(() => fetchUserData(session.user.id), 0);
//         } else {
//           setRoles([]);
//           setProfile(null);
//         }
//         setLoading(false);
//       }
//     );

//     supabase.auth.getSession().then(({ data: { session } }) => {
//       setSession(session);
//       setUser(session?.user ?? null);
//       if (session?.user) fetchUserData(session.user.id);
//       setLoading(false);
//     });

//     return () => subscription.unsubscribe();
//   }, []);

//   const signIn = async (email: string, password: string) => {
//     const { error } = await supabase.auth.signInWithPassword({ email, password });
//     return { error: error as Error | null };
//   };

//   const signUp = async (email: string, password: string, fullName: string) => {
//     const { error } = await supabase.auth.signUp({
//       email,
//       password,
//       options: {
//         data: { full_name: fullName },
//         emailRedirectTo: window.location.origin,
//       },
//     });
//     return { error: error as Error | null };
//   };

//   const signOut = async () => {
//     await supabase.auth.signOut();
//   };

//   return (
//     <AuthContext.Provider value={{ user, session, roles, profile, loading, signIn, signUp, signOut }}>
//       {children}
//     </AuthContext.Provider>
//   );
// }

// export function useAuth() {
//   const context = useContext(AuthContext);
//   if (!context) throw new Error('useAuth must be used within an AuthProvider');
//   return context;
// }


import { useState, useEffect, createContext, useContext, ReactNode } from 'react';

const API_BASE = import.meta.env.VITE_API_URL;

type UserType = {
  token: string;
  email: string;
  username: string;
  role: string;
};

interface AuthContextType {
  user: UserType | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (email: string, password: string, fullName: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserType | null>(null);
  const [loading, setLoading] = useState(true);

  // ✅ Load user from localStorage on refresh
  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  // ✅ LOGIN (API)
  const signIn = async (email: string, password: string) => {
    try {
      const response = await fetch(`${API_BASE}/api/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ email, password })
      });

      if (!response.ok) {
        throw new Error("Invalid credentials");
      }

      const data = await response.json();

      // ✅ Save token + user
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data));

      setUser(data);

      return { error: null };
    } catch (err: any) {
      return { error: err };
    }
  };

  // ✅ REGISTER (API)
  const signUp = async (email: string, password: string, fullName: string) => {
    try {
      const response = await fetch(`${API_BASE}/api/auth/register`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          email,
          password,
          fullName
        })
      });
      if (!response.ok) {
        throw new Error("Registration failed");
      }

      return { error: null };
    } catch (err: any) {
      return { error: err };
    }
  };

  // ✅ LOGOUT
  const signOut = async () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        signIn,
        signUp,
        signOut
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

// ✅ Custom hook
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within AuthProvider');
  return context;
}