import type { Database } from '@/integrations/supabase/types';
import { Shield, Wrench, FileText, Zap, Droplets, Car, CheckSquare, Users, Building2, BarChart3, Package, UserCog, Eye, Crown, Star, GraduationCap, Briefcase, Monitor, ServerCog, UserPlus, Headphones } from 'lucide-react';

type AppRole = Database['public']['Enums']['app_role'];

export interface AppInfo {
  id: string;
  name: string;
  description: string;
  icon: typeof Shield;
  color: string;
}

export const ROLE_LABELS: Record<AppRole, string> = {
  trainee: 'Trainee',
  employee_technical: 'Employee / Technical',
  employee_non_technical: 'Employee / Non‑Technical',
  employee_security: 'Employee / Security',
  employee_electricity: 'Employee / Electricity',
  employee_water: 'Employee / Water',
  employee_driver: 'Employee / Driver',
  employee_approver_technical: 'Employee / Approver / Technical',
  employee_approver_non_technical: 'Employee / Approver / Non‑Technical',
  employee_facilitator: 'Employee / Facilitator',
  manager_technical: 'Manager / Technical',
  manager_non_technical: 'Manager / Non‑Technical',
  manager_store: 'Manager / Store',
  manager_hr: 'Manager / HR',
  director: 'Director',
  coo: 'COO',
  ceo: 'CEO',
  employee_system: 'Employee / System',
  employee_system_admin: 'Employee / System‑Admin',
  ops_manager: 'Ops Manager',
  it_manager: 'IT Manager',
  finance: 'Finance',
  purchase_hr: 'Purchase / HR',
  purchase: 'Purchase',
  hr: 'HR',
  house_keeping: 'House Keeping',
};

const HELPDESK_APP: AppInfo = {
  id: 'helpdesk',
  name: 'Helpdesk',
  description: 'Submit and track support requests',
  icon: Headphones,
  color: 'bg-orange-500',
};

const STORE_MGMT_APP: AppInfo = {
  id: 'store-management',
  name: 'Store Management System',
  description: 'Manage store operations, procurement requests and purchase orders',
  icon: Package,
  color: 'bg-amber-600',
};

const INVITE_VISITOR_APP: AppInfo = {
  id: 'invite-visitor',
  name: 'Visitor Management System',
  description: 'Send visitor invitations and manage guest access',
  icon: UserPlus,
  color: 'bg-sky-500',
};

export const ROLE_APPS: Record<AppRole, AppInfo[]> = {
  trainee: [
    { id: 'training-portal', name: 'Training Portal', description: 'Access training materials and courses', icon: GraduationCap, color: 'bg-amber-500' },
    { id: 'knowledge-base', name: 'Knowledge Base', description: 'Company documentation and guides', icon: FileText, color: 'bg-blue-500' },
  ],
  employee_technical: [
    { id: 'tech-dashboard', name: 'Tech Dashboard', description: 'Technical project management', icon: Wrench, color: 'bg-indigo-500' },
    { id: 'code-review', name: 'Code Review', description: 'Review and manage code changes', icon: Eye, color: 'bg-violet-500' },
    { id: 'knowledge-base', name: 'Knowledge Base', description: 'Company documentation and guides', icon: FileText, color: 'bg-blue-500' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  employee_non_technical: [
    { id: 'task-manager', name: 'Task Manager', description: 'Manage daily tasks and assignments', icon: CheckSquare, color: 'bg-green-500' },
    { id: 'knowledge-base', name: 'Knowledge Base', description: 'Company documentation and guides', icon: FileText, color: 'bg-blue-500' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  employee_security: [
    { id: 'security-console', name: 'Security Console', description: 'Monitor and manage security operations', icon: Shield, color: 'bg-red-500' },
    { id: 'incident-tracker', name: 'Incident Tracker', description: 'Track and report security incidents', icon: FileText, color: 'bg-orange-500' },
    INVITE_VISITOR_APP,
  ],
  employee_electricity: [
    { id: 'electrical-systems', name: 'Electrical Systems', description: 'Monitor and manage electrical infrastructure', icon: Zap, color: 'bg-yellow-500' },
    { id: 'maintenance-log', name: 'Maintenance Log', description: 'Log and track maintenance activities', icon: Wrench, color: 'bg-gray-500' },
    INVITE_VISITOR_APP,
    HELPDESK_APP,
  ],
  employee_water: [
    { id: 'water-systems', name: 'Water Systems', description: 'Monitor water management systems', icon: Droplets, color: 'bg-cyan-500' },
    { id: 'maintenance-log', name: 'Maintenance Log', description: 'Log and track maintenance activities', icon: Wrench, color: 'bg-gray-500' },
    INVITE_VISITOR_APP,
    HELPDESK_APP,
  ],
  employee_driver: [
    { id: 'fleet-manager', name: 'Fleet Manager', description: 'Vehicle tracking and scheduling', icon: Car, color: 'bg-emerald-500' },
    { id: 'route-planner', name: 'Route Planner', description: 'Plan and optimize routes', icon: Building2, color: 'bg-teal-500' },
    INVITE_VISITOR_APP,
    HELPDESK_APP,
  ],
  employee_approver_technical: [
    { id: 'tech-approvals', name: 'Technical Approvals', description: 'Review and approve technical requests', icon: CheckSquare, color: 'bg-indigo-500' },
    { id: 'tech-dashboard', name: 'Tech Dashboard', description: 'Technical project management', icon: Wrench, color: 'bg-violet-500' },
    INVITE_VISITOR_APP,
    HELPDESK_APP,
  ],
  employee_approver_non_technical: [
    { id: 'general-approvals', name: 'General Approvals', description: 'Review and approve general requests', icon: CheckSquare, color: 'bg-green-500' },
    { id: 'task-manager', name: 'Task Manager', description: 'Manage daily tasks and assignments', icon: FileText, color: 'bg-blue-500' },
    INVITE_VISITOR_APP,
    HELPDESK_APP,
  ],
  employee_facilitator: [
    { id: 'facility-mgmt', name: 'Facility Management', description: 'Manage facility operations and bookings', icon: Building2, color: 'bg-purple-500' },
    { id: 'event-scheduler', name: 'Event Scheduler', description: 'Schedule and manage events', icon: Users, color: 'bg-pink-500' },
    INVITE_VISITOR_APP,
    HELPDESK_APP,
  ],
  manager_technical: [
    { id: 'team-dashboard', name: 'Team Dashboard', description: 'Oversee technical team performance', icon: BarChart3, color: 'bg-indigo-600' },
    { id: 'tech-approvals', name: 'Technical Approvals', description: 'Review and approve technical requests', icon: CheckSquare, color: 'bg-violet-500' },
    { id: 'resource-planner', name: 'Resource Planner', description: 'Allocate team resources', icon: Users, color: 'bg-blue-600' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  manager_non_technical: [
    { id: 'team-dashboard', name: 'Team Dashboard', description: 'Oversee team performance', icon: BarChart3, color: 'bg-green-600' },
    { id: 'general-approvals', name: 'General Approvals', description: 'Review and approve requests', icon: CheckSquare, color: 'bg-emerald-500' },
    { id: 'resource-planner', name: 'Resource Planner', description: 'Allocate team resources', icon: Users, color: 'bg-teal-600' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  manager_store: [
    { id: 'inventory', name: 'Inventory Management', description: 'Track and manage inventory', icon: Package, color: 'bg-amber-600' },
    { id: 'procurement', name: 'Procurement', description: 'Manage purchase orders and vendors', icon: Briefcase, color: 'bg-orange-600' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  manager_hr: [
    { id: 'hr-portal', name: 'HR Portal', description: 'Employee management and records', icon: UserCog, color: 'bg-rose-500' },
    { id: 'payroll', name: 'Payroll System', description: 'Manage employee compensation', icon: BarChart3, color: 'bg-pink-600' },
    { id: 'recruitment', name: 'Recruitment', description: 'Manage job postings and candidates', icon: Users, color: 'bg-purple-600' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  director: [
    { id: 'exec-dashboard', name: 'Executive Dashboard', description: 'Company-wide performance metrics', icon: BarChart3, color: 'bg-slate-700' },
    { id: 'team-dashboard', name: 'Team Dashboard', description: 'Oversee all teams', icon: Users, color: 'bg-blue-700' },
    { id: 'budget-tracker', name: 'Budget Tracker', description: 'Monitor department budgets', icon: Briefcase, color: 'bg-emerald-700' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  coo: [
    { id: 'exec-dashboard', name: 'Executive Dashboard', description: 'Company-wide performance metrics', icon: BarChart3, color: 'bg-slate-800' },
    { id: 'operations-hub', name: 'Operations Hub', description: 'Oversee all operational activities', icon: Building2, color: 'bg-indigo-800' },
    { id: 'analytics', name: 'Advanced Analytics', description: 'Deep-dive into company data', icon: Star, color: 'bg-violet-800' },
    { id: 'procurement', name: 'Procurement', description: 'Manage purchase orders and vendors', icon: Briefcase, color: 'bg-orange-600' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  ceo: [
    { id: 'exec-dashboard', name: 'Executive Dashboard', description: 'Company-wide performance metrics', icon: BarChart3, color: 'bg-slate-900' },
    { id: 'strategy-center', name: 'Strategy Center', description: 'Strategic planning and objectives', icon: Crown, color: 'bg-amber-700' },
    { id: 'analytics', name: 'Advanced Analytics', description: 'Deep-dive into company data', icon: Star, color: 'bg-violet-800' },
    { id: 'operations-hub', name: 'Operations Hub', description: 'Full operational oversight', icon: Building2, color: 'bg-indigo-800' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  employee_system: [
    { id: 'system-monitor', name: 'System Monitor', description: 'Monitor system health and performance', icon: Monitor, color: 'bg-slate-600' },
    { id: 'knowledge-base', name: 'Knowledge Base', description: 'Company documentation and guides', icon: FileText, color: 'bg-blue-500' },
    INVITE_VISITOR_APP,
    HELPDESK_APP,
  ],
  employee_system_admin: [
    { id: 'user-management', name: 'User Management', description: 'Create, edit, and manage user accounts and roles', icon: UserCog, color: 'bg-rose-600' },
    { id: 'system-monitor', name: 'System Monitor', description: 'Monitor system health and performance', icon: Monitor, color: 'bg-slate-600' },
    { id: 'knowledge-base', name: 'Knowledge Base', description: 'Company documentation and guides', icon: FileText, color: 'bg-blue-500' },
    INVITE_VISITOR_APP,
    HELPDESK_APP,
  ],
  ops_manager: [
    { id: 'team-dashboard', name: 'Team Dashboard', description: 'Oversee operational team performance', icon: BarChart3, color: 'bg-green-600' },
    { id: 'general-approvals', name: 'Operational Approvals', description: 'Review and approve operational requests', icon: CheckSquare, color: 'bg-emerald-500' },
    { id: 'procurement', name: 'Procurement', description: 'Manage purchase orders and vendors', icon: Briefcase, color: 'bg-orange-600' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  it_manager: [
    { id: 'tech-dashboard', name: 'Tech Dashboard', description: 'IT project and infrastructure management', icon: ServerCog, color: 'bg-indigo-600' },
    { id: 'tech-approvals', name: 'IT Approvals', description: 'Review and approve IT-related requests', icon: CheckSquare, color: 'bg-violet-500' },
    { id: 'procurement', name: 'Procurement', description: 'Manage purchase orders and vendors', icon: Briefcase, color: 'bg-orange-600' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  finance: [
    { id: 'budget-tracker', name: 'Budget Tracker', description: 'Monitor and manage budgets', icon: BarChart3, color: 'bg-emerald-700' },
    { id: 'finance-approvals', name: 'Finance Authorization', description: 'Authorize financial requests and payments', icon: CheckSquare, color: 'bg-teal-600' },
    { id: 'procurement', name: 'Procurement', description: 'Manage purchase orders and vendors', icon: Briefcase, color: 'bg-orange-600' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  purchase_hr: [
    { id: 'procurement', name: 'Procurement', description: 'Manage purchase orders and vendors', icon: Briefcase, color: 'bg-orange-600' },
    { id: 'hr-portal', name: 'HR Portal', description: 'Employee management and records', icon: UserCog, color: 'bg-rose-500' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  purchase: [
    { id: 'procurement', name: 'Procurement', description: 'Manage purchase orders and vendors', icon: Briefcase, color: 'bg-orange-600' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  hr: [
    { id: 'hr-portal', name: 'HR Portal', description: 'Employee management and records', icon: UserCog, color: 'bg-rose-500' },
    INVITE_VISITOR_APP,
    STORE_MGMT_APP,
    HELPDESK_APP,
  ],
  house_keeping: [
    { id: 'facility-mgmt', name: 'Facility Management', description: 'Manage facility operations and housekeeping tasks', icon: Building2, color: 'bg-purple-500' },
    INVITE_VISITOR_APP,
    HELPDESK_APP,
  ],
};
