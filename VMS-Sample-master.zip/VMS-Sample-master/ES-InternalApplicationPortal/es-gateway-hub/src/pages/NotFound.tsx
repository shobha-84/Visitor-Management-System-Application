import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <div className="flex min-h-screen items-start bg-gray-100 px-10 pt-20">
      <div className="w-full max-w-7xl mx-auto flex flex-col-reverse md:flex-row items-center justify-between">

        {/* LEFT CONTENT */}
        <div className="md:w-1/2 space-y-6 text-center md:text-left">

          {/* Logo */}
          <div className="mb-8 text-3xl font-bold text-gray-800">
            Internal Application Portal
          </div>

          {/* Title */}
          <div className="mb-10 font-light text-gray-600 max-h-svh md:mb-20">
            <h1 className="text-4xl md:text-5xl font-semibold tracking-wide text-sky-600 leading-tight">
              OOPS... PAGE NOT FOUND
            </h1>
          </div>

          {/* Description */}
          <p className="text-gray-600 text-lg">
            Maybe you mistyped the URL or the page has been removed.
          </p>

          {/* Go Back */}
          <a
            href="/"
            className="inline-flex items-center gap-2 text-sky-500 text-lg hover:text-sky-600 transition"
          >
            <KeyboardBackspaceIcon />
            Go Back
          </a>
        </div>

        {/* RIGHT IMAGE */}
        <div className="md:w-1/2 flex justify-center">
          <img
            src={`${import.meta.env.BASE_URL}sitechecker-404-page.png`}
            alt="404 illustration"
            className="w-[420px] max-w-full"
          />
        </div>

      </div>
    </div>

  );
};

export default NotFound;
