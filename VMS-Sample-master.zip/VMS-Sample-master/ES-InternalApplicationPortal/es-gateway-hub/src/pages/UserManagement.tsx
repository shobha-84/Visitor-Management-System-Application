import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { ROLE_LABELS } from '@/lib/roleConfig';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import {
  ArrowLeft, Plus, Search, UserCog, Shield, Copy, Eye, EyeOff,
  Loader2, Ban, CheckCircle, Key, Save, X, Users,
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import type { Database } from '@/integrations/supabase/types';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
type AppRole = Database['public']['Enums']['app_role'];

const ALL_ROLES = Object.keys(ROLE_LABELS) as AppRole[];

interface ManagedUser {
  id: string;
  email: string;
  full_name: string | null;
  employee_id: string | null;
  department: string | null;
  location: string | null;
  contact_number: string | null;
  roles: AppRole[];
  disabled: boolean;
  created_at: string;
}

const invoke = async (action: string, payload: Record<string, unknown> = {}) => {
  const { data, error } = await supabase.functions.invoke('admin-user-management', {
    body: { action, ...payload },
  });
  if (error) throw new Error(error.message);
  if (data?.error) throw new Error(data.error);
  return data;
};

const UserManagement = () => {
  const { roles } = useAuth();
  const navigate = useNavigate();
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [showCreate, setShowCreate] = useState(false);
  const [editingUser, setEditingUser] = useState<ManagedUser | null>(null);
  const [createdCreds, setCreatedCreds] = useState<{ email: string; password: string } | null>(null);

  const isAdmin = roles.includes('employee_system_admin');

  const fetchUsers = useCallback(async () => {
    try {
      setLoading(true);
      const data = await invoke('list_users');
      setUsers(data.users || []);
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (isAdmin) fetchUsers();
  }, [isAdmin, fetchUsers]);

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <Shield className="w-16 h-16 text-destructive mx-auto" />
          <h1 className="text-2xl font-bold text-foreground">Access Denied</h1>
          <p className="text-muted-foreground">You need the System Admin role to access this page.</p>
          <Button onClick={() => navigate('/')}>Go Back</Button>
        </div>
      </div>
    );
  }

  const filtered = users.filter(u => {
    const matchesSearch =
      (u.email?.toLowerCase().includes(search.toLowerCase())) ||
      (u.full_name?.toLowerCase().includes(search.toLowerCase())) ||
      (u.employee_id?.toLowerCase().includes(search.toLowerCase()));
    const matchesRole = roleFilter === 'all' || u.roles.includes(roleFilter as AppRole);
    return matchesSearch && matchesRole;
  });

  return (
    <div className="min-h-screen bg-mesh">
      <header className="border-b border-white/20 glass-header" style={{ background: 'linear-gradient(135deg, rgba(23, 54, 120, 0.85), rgba(21, 150, 193, 0.85))' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-12 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => navigate('/')} className="text-white hover:bg-white/10">
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <UserCog className="w-5 h-5 text-white" />
            <span className="text-lg font-bold text-white">User Management</span>
          </div>
          <Button onClick={() => { setShowCreate(true); setEditingUser(null); }} className="bg-white/20 text-white hover:bg-white/30">
            <Plus className="w-4 h-4 mr-2" /> Create User
          </Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Search & Role Filter */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="relative max-w-md flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, email, or employee ID..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={roleFilter} onValueChange={setRoleFilter}>
            <SelectTrigger className="w-[220px] h-10 text-sm">
              <SelectValue placeholder="All roles" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All roles</SelectItem>
              {ALL_ROLES.map(role => (
                <SelectItem key={role} value={role}>{ROLE_LABELS[role]}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          {(roleFilter !== 'all') && (
            <Button variant="ghost" size="sm" className="h-10 px-2 text-muted-foreground" onClick={() => setRoleFilter('all')}>
              <X className="w-3.5 h-3.5 mr-1" /> Clear
            </Button>
          )}
        </div>

        {/* Credentials Modal */}
        {createdCreds && (
          <CredentialsModal creds={createdCreds} onClose={() => setCreatedCreds(null)} />
        )}

        {/* Create/Edit Modal */}
        {(showCreate || editingUser) && (
          <UserFormModal
            user={editingUser}
            onClose={() => { setShowCreate(false); setEditingUser(null); }}
            onSaved={(creds) => {
              fetchUsers();
              setShowCreate(false);
              setEditingUser(null);
              if (creds) setCreatedCreds(creds);
            }}
          />
        )}

        {/* Users Table */}
        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="glass rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border bg-muted/50">
                     <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">User</th>
                     <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase hidden md:table-cell">Employee ID</th>
                     <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase hidden md:table-cell">Department</th>
                     <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase hidden md:table-cell">Location</th>
                     <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase hidden lg:table-cell">Roles/Designation</th>
                     <th className="text-left px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Status</th>
                     <th className="text-right px-4 py-3 text-xs font-semibold text-muted-foreground uppercase">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(u => (
                    <tr key={u.id} className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors">
                      <td className="px-4 py-3">
                        <p className="font-medium text-foreground text-sm">{u.full_name || '—'}</p>
                        <p className="text-xs text-muted-foreground">{u.email}</p>
                      </td>
                       <td className="px-4 py-3 text-sm text-muted-foreground hidden md:table-cell">{u.employee_id || '—'}</td>
                       <td className="px-4 py-3 text-sm text-muted-foreground hidden md:table-cell">{u.department || '—'}</td>
                       <td className="px-4 py-3 text-sm text-muted-foreground hidden md:table-cell">{u.location || '—'}</td>
                       <td className="px-4 py-3 hidden lg:table-cell">
                        <div className="flex flex-wrap gap-1">
                          {u.roles.length > 0 ? u.roles.map(r => (
                            <span key={r} className="text-xs px-2 py-0.5 bg-primary/10 text-primary rounded-full">
                              {ROLE_LABELS[r] || r}
                            </span>
                          )) : <span className="text-xs text-muted-foreground">No roles</span>}
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        {u.disabled ? (
                          <span className="inline-flex items-center gap-1 text-xs text-destructive">
                            <Ban className="w-3 h-3" /> Disabled
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-xs text-emerald-600">
                            <CheckCircle className="w-3 h-3" /> Active
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-right">
                        <Button variant="ghost" size="sm" onClick={() => { setEditingUser(u); setShowCreate(false); }}>
                          Edit
                        </Button>
                      </td>
                    </tr>
                  ))}
                  {filtered.length === 0 && (
                    <tr>
                      <td colSpan={7} className="px-4 py-12 text-center text-muted-foreground">
                        <Users className="w-8 h-8 mx-auto mb-2 opacity-40" />
                        No users found
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

/* ─── Create / Edit User Modal ─── */
function UserFormModal({
  user,
  onClose,
  onSaved,
}: {
  user: ManagedUser | null;
  onClose: () => void;
  onSaved: (creds?: { email: string; password: string }) => void;
}) {
  const isEdit = !!user;
  const [email, setEmail] = useState(user?.email || '');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState(() => (user?.full_name?.split(' ')[0]) || '');
  const [lastName, setLastName] = useState(() => (user?.full_name?.split(' ').slice(1).join(' ')) || '');
  const [employeeId, setEmployeeId] = useState(user?.employee_id || '');
  const [department, setDepartment] = useState(user?.department || '');
  const [location, setLocation] = useState(user?.location || '');
  const [contactNumber, setContactNumber] = useState(user?.contact_number || '');
  const [selectedRoles, setSelectedRoles] = useState<AppRole[]>(user?.roles || []);
  const [disabled, setDisabled] = useState(user?.disabled || false);
  const [saving, setSaving] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const generatePassword = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%';
    let pw = '';
    for (let i = 0; i < 12; i++) pw += chars[Math.floor(Math.random() * chars.length)];
    setPassword(pw);
    setShowPassword(true);
  };

  const toggleRole = (role: AppRole) => {
    setSelectedRoles(prev =>
      prev.includes(role) ? prev.filter(r => r !== role) : [...prev, role]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      if (!isEdit) {
        if (!email || !password) {
          toast.error('Email and password are required');
          setSaving(false);
          return;
        }
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
          toast.error('Please enter a valid email address');
          setSaving(false);
          return;
        }
        if (password.length < 6) {
          toast.error('Password must be at least 6 characters');
          setSaving(false);
          return;
        }
      }

      if (isEdit) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
          toast.error('Please enter a valid email address');
          setSaving(false);
          return;
        }
        const payload: any = {
          user_id: user.id,
          email,
          full_name: `${firstName} ${lastName}`.trim(),
          employee_id: employeeId,
          department,
          location,
          contact_number: contactNumber,
          roles: selectedRoles,
          disabled,
        };
        await invoke('update_user', payload);
        if (password) {
          await invoke('reset_password', { user_id: user.id, new_password: password });
        }
        toast.success('User updated successfully');
        onSaved();
      } else {
        const data = await invoke('create_user', {
          email,
          password,
          full_name: `${firstName} ${lastName}`.trim(),
          employee_id: employeeId,
          department,
          location,
          contact_number: contactNumber,
          roles: selectedRoles,
        });
        toast.success('User created successfully');
        onSaved(data.credentials);
      }
    } catch (err: any) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 backdrop-blur-sm p-4">
      <div className="bg-card border border-border rounded-xl shadow-lg w-full max-w-5xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-border">
          <h2 className="text-lg font-bold text-foreground">{isEdit ? 'Edit User' : 'Create New User'}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}><X className="w-4 h-4" /></Button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Email</Label>
              <Input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="user@excelsoft.com" required />
            </div>
            <div className="space-y-2">
              <Label>{isEdit ? 'New Password (optional)' : 'Password'}</Label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    placeholder={isEdit ? 'Leave blank to keep' : 'Enter password'}
                    required={!isEdit}
                    minLength={6}
                  />
                  <button type="button" className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" onClick={() => setShowPassword(!showPassword)}>
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <Button type="button" variant="outline" size="icon" onClick={generatePassword} title="Generate password">
                  <Key className="w-4 h-4" />
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label>First Name</Label>
              <Input value={firstName} onChange={e => setFirstName(e.target.value)} placeholder="John" />
            </div>
            <div className="space-y-2">
              <Label>Last Name</Label>
              <Input value={lastName} onChange={e => setLastName(e.target.value)} placeholder="Doe" />
            </div>
            <div className="space-y-2">
              <Label>Employee ID</Label>
              <Input value={employeeId} onChange={e => setEmployeeId(e.target.value)} placeholder="EMP-001" />
            </div>
            <div className="space-y-2">
              <Label>Department</Label>
              <Select value={department} onValueChange={setDepartment}>
                <SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger>
                <SelectContent>
                  {['Engineering', 'Product', 'Quality Assurance', 'DevOps', 'IT Infrastructure', 'Data Science', 'UI/UX Design', 'Project Management', 'Human Resources', 'Finance & Accounts', 'Administration', 'Sales & Marketing', 'Customer Support', 'Legal & Compliance', 'Research & Development'].map(d => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Mobile Number</Label>
              <Input type="tel" value={contactNumber} onChange={e => setContactNumber(e.target.value)} placeholder="+91 98765 43210" />
            </div>
            <div className="space-y-2">
              <Label>Location</Label>
              <Select value={location} onValueChange={setLocation}>
                <SelectTrigger><SelectValue placeholder="Select location" /></SelectTrigger>
                <SelectContent>
                  {['Mysore', 'Bangalore', 'Hyderabad', 'Noida', 'Singapore', 'USA', 'UK'].map(l => (
                    <SelectItem key={l} value={l}>{l}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {isEdit && (
            <div className="flex items-center gap-3">
              <Label>Account Status:</Label>
              <Button
                type="button"
                variant={disabled ? 'destructive' : 'outline'}
                size="sm"
                onClick={() => setDisabled(!disabled)}
              >
                {disabled ? <><Ban className="w-3 h-3 mr-1" /> Disabled</> : <><CheckCircle className="w-3 h-3 mr-1" /> Active</>}
              </Button>
            </div>
          )}

          <div className="space-y-2">
            <Label>Assign Roles/Designation</Label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-48 overflow-y-auto border border-border rounded-lg p-3">
              {ALL_ROLES.map(role => (
                <label key={role} className="flex items-center gap-2 text-sm cursor-pointer hover:bg-muted/50 rounded px-2 py-1.5 transition-colors">
                  <input
                    type="checkbox"
                    checked={selectedRoles.includes(role)}
                    onChange={() => toggleRole(role)}
                    className="rounded border-input text-primary focus:ring-primary"
                  />
                  <span className="text-foreground truncate">{ROLE_LABELS[role]}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={saving}>
              {saving ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Save className="w-4 h-4 mr-2" />}
              {isEdit ? 'Save Changes' : 'Create User'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ─── Credentials Sharing Modal ─── */
function CredentialsModal({ creds, onClose }: { creds: { email: string; password: string }; onClose: () => void }) {
  const [showPw, setShowPw] = useState(false);

  const copyAll = () => {
    navigator.clipboard.writeText(`Email: ${creds.email}\nPassword: ${creds.password}`);
    toast.success('Credentials copied to clipboard');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/40 backdrop-blur-sm p-4">
      <div className="bg-card border border-border rounded-xl shadow-lg w-full max-w-md">
        <div className="p-6 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
              <Key className="w-5 h-5 text-primary" />
            </div>
            <div>
              <h3 className="font-bold text-foreground">User Created Successfully</h3>
              <p className="text-xs text-muted-foreground">Share these credentials securely with the user</p>
            </div>
          </div>

          <div className="bg-muted rounded-lg p-4 space-y-3">
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase">Email</p>
              <p className="text-sm font-mono text-foreground">{creds.email}</p>
            </div>
            <div>
              <p className="text-xs font-medium text-muted-foreground uppercase">Password</p>
              <div className="flex items-center gap-2">
                <p className="text-sm font-mono text-foreground">{showPw ? creds.password : '••••••••••••'}</p>
                <button type="button" onClick={() => setShowPw(!showPw)} className="text-muted-foreground hover:text-foreground">
                  {showPw ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          <div className="flex gap-3">
            <Button className="flex-1" onClick={copyAll}>
              <Copy className="w-4 h-4 mr-2" /> Copy Credentials
            </Button>
            <Button variant="outline" onClick={onClose}>Done</Button>
          </div>

          <p className="text-xs text-destructive text-center">
            ⚠ This is the only time the password will be shown. Share it securely.
          </p>
        </div>
      </div>
    </div>
  );
}

export default UserManagement;
