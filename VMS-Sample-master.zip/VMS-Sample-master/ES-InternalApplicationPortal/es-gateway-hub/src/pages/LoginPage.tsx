import { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Mail, Lock, User, Loader2, ArrowRight } from 'lucide-react';
import excelsoftLogo from '@/assets/excelsoft-logo.svg';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

const LoginPage = () => {
  const { signIn, signUp } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (isLogin) {
      const { error } = await signIn(email, password);
      if (error) setError(error.message);
    } else {
      if (!fullName.trim()) {
        toast.error('Please enter your full name');
        setLoading(false);
        return;
      }
      const { error } = await signUp(email, password, fullName);
      if (error) toast.error(error.message);
      else toast.success('Account created! Please check your email to confirm.');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen flex bg-brand-light">
      {/* Left Panel - Branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-brand-navy flex-col justify-between p-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-brand-navy via-brand-deep to-primary/30" />
        <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-primary/10 blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-72 h-72 rounded-full bg-brand-glow/10 blur-3xl translate-y-1/2 -translate-x-1/2" />
        
        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-2">
            <img src={excelsoftLogo} alt="Excelsoft" style={{ width: '200px', height: 'auto' }} />
          </div>
          <p className="text-primary-foreground/60 text-sm">Internal Application Portal</p>
        </div>

        <div className="relative z-10 space-y-8">
          <h2 className="text-4xl font-bold text-primary-foreground leading-tight">
            One login.<br />
            All your tools.
          </h2>
          <p className="text-primary-foreground/70 text-lg max-w-md">
            Access every internal application you need based on your role — from a single, secure entry point.
          </p>
          <div className="flex items-center gap-6 text-primary-foreground/50 text-sm">
            <span>1,100+ employees</span>
            <span className="w-1 h-1 rounded-full bg-primary-foreground/30" />
            <span>19 role types</span>
            <span className="w-1 h-1 rounded-full bg-primary-foreground/30" />
            <span>Secure access</span>
          </div>
        </div>

        <div className="relative z-10 text-primary-foreground/40 text-xs">
          © {new Date().getFullYear()} Excelsoft. All rights reserved.
        </div>
      </div>

      {/* Right Panel - Login Form */}
      <div className="flex-1 flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md space-y-8">
          {/* Mobile logo */}
          <div className="lg:hidden flex items-center gap-3 mb-6">
            <img src={excelsoftLogo} alt="Excelsoft" className="h-8 [filter:brightness(0)]" />
          </div>

          <div>
            <h2 className="text-3xl font-bold text-foreground">
              {isLogin ? 'Welcome back' : 'Create account'}
            </h2>
            <p className="mt-2 text-muted-foreground">
              {isLogin
                ? 'Sign in to access your applications'
                : 'Register to get started with Excelsoft'}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {!isLogin && (
              <div className="space-y-2">
                <Label htmlFor="fullName" className="text-foreground font-medium">Full Name</Label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="fullName"
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Enter your full name"
                    className="pl-10 h-12 bg-card border-border"
                    maxLength={100}
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email" className="text-foreground font-medium">Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@excelsoft.com"
                  className="pl-10 h-12 bg-card border-border"
                  required
                  maxLength={255}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-foreground font-medium">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="pl-10 h-12 bg-card border-border"
                  required
                  minLength={6}
                  maxLength={128}
                />
              </div>
            </div>

            <Button type="submit" className="w-full h-12 text-base font-semibold" disabled={loading}>
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  {isLogin ? 'Sign In' : 'Create Account'}
                  <ArrowRight className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>
            {isLogin && error && (
              <p className="text-sm text-red-500 text-left">{error}</p>
            )}
          </form>

          <div className="text-center">
            <button
              type="button"
              onClick={() => setIsLogin(!isLogin)}
              className="text-sm text-primary hover:text-primary/80 font-medium transition-colors"
            >
            {!isLogin && 'Already have an account? Sign in'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
