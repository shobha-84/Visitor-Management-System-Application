import { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import esLogo from "@/assets/excelsoft-logo-white.svg";
import { apiFetch } from "@/api/http";
import { InvitationForm } from "@/components/visitor/InvitationForm";
import { MyInvitations } from "@/components/visitor/MyInvitations";
import { ApprovalQueue } from "@/components/visitor/ApprovalQueue";
import { SecurityCheckpoint } from "@/components/visitor/SecurityCheckpoint";
import { FacilitatorView } from "@/components/visitor/FacilitatorView";
import { AIInvitationChat } from "@/components/visitor/AIInvitationChat";
import { ExtractedInvitation } from "@/services/aiService";
import { LogOut } from "lucide-react";
import { Sparkles } from "lucide-react";
import { toast } from "sonner";


interface TabCounts {
  myInvitations: number;
  pendingApprovals: number;
  facilitator: number;
}

// ✅ ROLE TYPE
type AppRole =
  | "manager_technical"
  | "employee_system_admin"
  | "manager_store"
  | "employee_approver_non_technical"
  | "employee_security"
  | "employee_facilitator";


const VisitorManagement = () => {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("my-invitations");
  const [editData, setEditData] = useState<any>(null);
  const [counts, setCounts] = useState<TabCounts>({ myInvitations: 0, pendingApprovals: 0, facilitator: 0 });
  const [approvalData, setApprovalData] = useState<any>(null);
  const [securityTab, setSecurityTab] = useState("my");
  const [aiFormData, setAiFormData] = useState<ExtractedInvitation | null>(null);
  const [listRefreshKey, setListRefreshKey] = useState(0);
  
  const [showLogout, setShowLogout] = useState(false);
  const roles: AppRole[] = (() => {
    if (!user?.role) return [];

    switch (user.role) {
      case "Security":
        return ["employee_security"];

      case "Admin":
        return [
          "manager_technical",
          "employee_system_admin",
          "manager_store",
          "employee_approver_non_technical"
        ];

      case "Employee":
        return [
          "manager_technical",
          "employee_system_admin",
          "manager_store"
        ];

      case "Facilitator":
        return ["employee_facilitator"];

      default:
        return [];
    }
  })();

  
    useEffect(() => {
      if (showLogout) {
        const timer = setTimeout(() => setShowLogout(false), 3000);
        return () => clearTimeout(timer);
      }
    }, [showLogout]);

  const profile = (() => {
    if (!user?.role) return null;

    switch (user.role) {
      case "Security":
        return {
          full_name: "Security",
          employee_id: "100",
          designation: "Security Staff",
          department: "Security",
          location: "Mysore",
          contact_number: null
        };

      case "Admin":
        return {
          full_name: "Admin",
          employee_id: "0000001077",
          designation: "Employee",
          department: "Engineering",
          location: "Mysore",
          contact_number: null
        };

      default:
        return {
          full_name: user.username,
          employee_id: "N/A",
          designation: null,
          department: null,
          location: null,
          contact_number: null
        };
    }
  })();


  const fetchCounts = useCallback(async () => {
    if (!user) return;
    try {
      const [myRes, pendingRes, facRes] = await Promise.all([
        apiFetch("/api/visitor-invitations/count?mine=true"),
        apiFetch("/api/visitor-invitations/count?status=pending"),
        apiFetch("/api/visitor-invitations/count?status=approved,checked_in,checked_out"),
      ]);

      setCounts({
        myInvitations: Number(myRes?.count ?? myRes ?? 0),
        pendingApprovals: Number(pendingRes?.count ?? pendingRes ?? 0),
        facilitator: Number(facRes?.count ?? facRes ?? 0),
      });
    } catch {
      setCounts({ myInvitations: 0, pendingApprovals: 0, facilitator: 0 });
    }
  }, [user]);

  useEffect(() => {
    fetchCounts();
  }, [fetchCounts]);

  useEffect(() => {
    if (!loading && !user) {
      navigate("/", { replace: true });
    }
  }, [user, loading, navigate]);

  const isAdmin = user?.role === "Admin";

  useEffect(() => {
    if (!isAdmin && activeTab === "all-invitations") {
      setActiveTab("my-invitations");
    }
  }, [isAdmin, activeTab]);

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const isApprover = roles.includes("employee_approver_non_technical");
  const isSecurity = roles.includes("employee_security");
  const isFacilitator = roles.includes("employee_facilitator");
  
  const handleViewApproval = async (id: string) => {
    try {
      const fullInvitation = await apiFetch(
        `/api/visitor-invitations/${id}`
      );

      setApprovalData(fullInvitation);
      setActiveTab("approval-view");
    } catch (err: any) {
      toast.error(err.message || "Failed to load visitor details");
    }
  };
  // Security only sees checkpoint view
  if (isSecurity && !isApprover && !isFacilitator) {
    return (
      //  const [activeTab, setActiveTab] = useState("my");

      <div className="min-h-screen bg-mesh">
        <Header profile={profile} user={user} signOut={signOut} navigate={navigate} />

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">

          {/* Top Header Row */}
          <div className="flex items-center justify-between mb-6">

            {/* Left Side */}
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="w-4 h-4" />
              </Button>

              <h1 className="text-2xl font-bold text-foreground">
                Visitor Management System
              </h1>
            </div>

            {/* ✅ Right Side Tabs */}
            <div className="flex flex-wrap gap-2 bg-gray-100 dark:bg-gray-800 p-1 rounded-lg">

              <button
                onClick={() => setSecurityTab("my")}
                className={`px-3 sm:px-4 py-2 rounded-md text-sm font-medium transition whitespace-nowrap ${activeTab === "my"
                  ? "bg-white shadow text-black"
                  : "text-gray-500"
                  }`}
              >
                My Invitations
              </button>

              <button
                onClick={() => setSecurityTab("new")}
                className={`px-3 sm:px-4 py-2 rounded-md text-sm font-medium transition whitespace-nowrap ${activeTab === "new"
                  ? "bg-white shadow text-black"
                  : "text-gray-500"
                  }`}
              >
                Cold Call Invitation
              </button>
            </div>

          </div>

          {/* ✅ Content Switching */}

          {/* My Invitations */}
          {securityTab === "my" && (
            <div className="space-y-4">
              <SecurityCheckpoint
                onEdit={(inv) => {
                  setEditData(inv);
                  setSecurityTab("new");
                }}
              />
            </div>
          )}

          {/* New Invitation */}
          {securityTab === "new" && (
            <div className="bg-white dark:bg-gray-900 shadow-md rounded-xl p-6">
              <InvitationForm
                key={editData?.id || "new"}
                editData={editData}
                mode={editData ? "edit" : "create"}
                restrictToDateOnly={true}
                onSuccess={() => {
                  setEditData(null);
                  setSecurityTab("my"); // ✅ go back after submit
                  fetchCounts();
                }}
              />
            </div>
          )}
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-mesh">
      <Header profile={profile} user={user} signOut={signOut} navigate={navigate} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <h1 className="text-2xl font-bold text-foreground">Visitor Management System</h1>
            </div>
            <TabsList className="flex-wrap h-auto gap-1">
              <TabsTrigger value="my-invitations" className="gap-1.5">
                My Invitations
                {/* {counts.myInvitations > 0 && (
                  <Badge variant="secondary" className="ml-1 h-5 min-w-[20px] px-1.5 text-xs">
                    {counts.myInvitations}
                  </Badge>
                )} */}
              </TabsTrigger>
              <TabsTrigger value="create" onClick={() => setEditData(null)}>New Invitation</TabsTrigger>
              <TabsTrigger value="ai" onClick={() => { setEditData(null); setAiFormData(null); }}>
                <Sparkles className="w-3 h-3 mr-1" /> AI Assist
              </TabsTrigger>
              {isAdmin && (
                <TabsTrigger value="all-invitations">All Invitations</TabsTrigger>
              )}
              {/* {isApprover && (
                <TabsTrigger value="approvals" className="gap-1.5">
                  Approvals
                  {counts.pendingApprovals > 0 && (
                    <Badge className="ml-1 h-5 min-w-[20px] px-1.5 text-xs bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                      {counts.pendingApprovals}
                    </Badge>
                  )}
                </TabsTrigger>
              )} */}
              <TabsTrigger value="my-hostinvitations" className="gap-1.5">
                My Host
                {/* {counts.myInvitations > 0 && (
                  <Badge variant="secondary" className="ml-1 h-5 min-w-[20px] px-1.5 text-xs">
                    {counts.myInvitations}
                  </Badge>
                )} */}
              </TabsTrigger>
              {isFacilitator && (
                <TabsTrigger value="facilitator" className="gap-1.5">
                  Facilitator
                  {counts.facilitator > 0 && (
                    <Badge variant="secondary" className="ml-1 h-5 min-w-[20px] px-1.5 text-xs">
                      {counts.facilitator}
                    </Badge>
                  )}
                </TabsTrigger>
              )}
            </TabsList>
          </div>
          <TabsContent value="my-invitations">
            <MyInvitations
              filterType="mine"
              refreshKey={listRefreshKey}
              onEdit={(inv) => {
                setEditData(inv);
                setActiveTab("create");
              }}
            />
          </TabsContent>
          <TabsContent value="my-hostinvitations">
            <MyInvitations
              filterType="host"
              refreshKey={listRefreshKey}
              onEdit={(inv) => {
                setEditData(inv);
                setActiveTab("create");
              }}
            />
          </TabsContent>

          {isAdmin && (
            <TabsContent value="all-invitations">
              <MyInvitations
                filterType="all"
                refreshKey={listRefreshKey}
                onEdit={(inv) => {
                  setEditData(inv);
                  setActiveTab("create");
                }}
              />
            </TabsContent>
          )}

          <TabsContent value="create">
            <InvitationForm
              key={editData?.id || "new"}
              editData={editData}
              mode={editData ? "edit" : "create"}
              aiData={aiFormData}
              onSuccess={() => {
                setEditData(null);
                setListRefreshKey(prev => prev + 1);
                setActiveTab("my-invitations");
                fetchCounts();
              }}
            />
          </TabsContent>

          <TabsContent value="ai">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-full">
              <div className="h-[600px]">
                <AIInvitationChat onApply={(data) => { setAiFormData(data); setActiveTab("ai"); }} />
              </div>
              <div>
                <InvitationForm
                  mode="create"
                  aiData={aiFormData}
                  onSuccess={() => {
                    setAiFormData(null);
                    setListRefreshKey(prev => prev + 1);
                    setActiveTab("my-invitations");
                    fetchCounts();
                  }}
                />
              </div>
            </div>
          </TabsContent>

          {/* {isApprover && (
  <TabsContent value="approvals">
    <ApprovalQueue
      onView={(inv) => handleViewApproval(inv.id)}
    />
  </TabsContent>
)} */}

          {/* {isApprover && (
  <TabsContent value="approval-view">
    {approvalData && (
      <InvitationForm
        key={approvalData.id}
        editData={approvalData}
        mode="approve"
        onSuccess={() => {
          setApprovalData(null);
          setActiveTab("approvals");
          fetchCounts();
        }}
      />
    )}
  </TabsContent>
)} */}

          {isFacilitator && (
            <TabsContent value="facilitator">
              <FacilitatorView />
            </TabsContent>
          )}

          {isFacilitator && (
            <TabsContent value="facilitator">
              <FacilitatorView />
            </TabsContent>
          )}

        </Tabs>
      </main>
    </div>
  );
};

function Header({ profile, user, signOut, navigate }: any) {
    const [open, setOpen] = useState(false);

  const handleLogout = async () => {
    setOpen(false);
    await signOut();
    navigate("/", { replace: true });
  };

  return (
    <header
      className="border-b border-white/20 glass-header"
      style={{ background: "linear-gradient(135deg, rgba(23, 54, 120, 0.85), rgba(21, 150, 193, 0.85))" }}
    >
      <div className="flex h-12 w-full items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-3">
          <img src={esLogo} alt="Excelsoft" className="h-8" />
        </div>
        <div className="ml-auto flex shrink-0 items-center gap-4">
          <div className="text-right hidden sm:block">
            <p className="text-sm font-medium text-white">{profile?.full_name || user?.email}</p>
            <p className="text-sm text-white">{user?.email}</p>
          </div>
          <div className="relative">

            {/* PROFILE ICON */}
            <Button
              variant="ghost"
              className="text-white hover:bg-white/10 p-2"
              onClick={() => setOpen(!open)}
            >
              <User className="w-6 h-6" />
            </Button>

            {/* DROPDOWN */}
            {open && (
              <div className="absolute right-0 mt-2 w-40 bg-white rounded-lg shadow-lg border z-50">
                <button
                  onClick={handleLogout}
                  className="w-full flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
                >
                  <LogOut className="w-4 h-4 text-blue-600" />
                  Logout
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}

export default VisitorManagement;

