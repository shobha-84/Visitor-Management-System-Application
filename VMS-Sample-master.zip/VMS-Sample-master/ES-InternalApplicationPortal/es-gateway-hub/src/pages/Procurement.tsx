import { useState, useEffect, useMemo } from 'react';
// import { useState, useEffect, useCallback, useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
// import { supabase } from '@/integrations/supabase/client';
import { ArrowLeft, LogOut, Package, Monitor, Users, FileText, Clock, CheckCircle2, XCircle, TrendingUp, ShoppingCart, AlertTriangle, ChevronRight, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import esLogo from '@/assets/excelsoft-logo-white.svg';
import { StoreRequestForm } from '@/components/store/StoreRequestForm';
import { MyStoreRequests } from '@/components/store/MyStoreRequests';
import { StoreApprovalQueue } from '@/components/store/StoreApprovalQueue';
import { ApprovalHierarchy } from '@/components/procurement/ApprovalHierarchy';
import { apiFetch } from '@/api/http';


const Procurement = () => {
  const { user, roles, profile, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');
  const [stats, setStats] = useState({ total: 0, pending: 0, approved: 0, rejected: 0, draft: 0 });

  const isApprover = useMemo(() => {
    const email = user?.email?.toLowerCase() || '';
    const approverEmails = [
      'tejaswi@excelsoftcorp.com',
      'srinivas@excelsoftcorp.com',
      'mahesh.jambardi@excelsoftcorp.com',
      'esfinance@excelsoftcorp.com',
      'biju.r@excelsoftcorp.com',
    ];
    return approverEmails.includes(email) || roles.some(r =>
      ['manager_technical', 'manager_non_technical', 'manager_store', 'manager_hr', 'director', 'coo', 'ceo', 'employee_system_admin', 'ops_manager', 'it_manager', 'finance', 'purchase_hr', 'purchase', 'hr'].includes(r)
    );
  }, [user, roles]);
  
  //

const fetchStats = async () => {
  try {
    const data = await apiFetch("/api/StoreRequests");

    const s = { total: data.length, pending: 0, approved: 0, rejected: 0, draft: 0 };

    data.forEach((r: any) => {
      if (r.status === 'draft') s.draft++;
      else if (r.status === 'rejected') s.rejected++;
      else if (r.status === 'po_released') s.approved++;
      else s.pending++;
    });

    setStats(s);
  } catch {}
};

//

useEffect(() => {
  fetchStats();
}, []);


  useEffect(() => {
    if (!loading && !user) navigate('/', { replace: true });
  }, [user, loading, navigate]);

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  const statCards = [
    { label: 'Total Requests', value: stats.total, icon: FileText, color: 'text-primary', bg: 'bg-primary/10' },
    { label: 'In Progress', value: stats.pending, icon: Clock, color: 'text-amber-600', bg: 'bg-amber-50' },
    { label: 'Completed (PO)', value: stats.approved, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Rejected', value: stats.rejected, icon: XCircle, color: 'text-destructive', bg: 'bg-red-50' },
  ];

  return (
    <div className="min-h-screen bg-mesh">
      {/* Header */}
      <header className="border-b border-white/20 glass-header" style={{ background: 'linear-gradient(135deg, rgba(23, 54, 120, 0.85), rgba(21, 150, 193, 0.85))' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-12 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={esLogo} alt="Excelsoft" className="h-8" />
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-white">{profile?.full_name || user?.email}</p>
              <p className="text-xs text-white/70">{user?.email}</p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => { signOut(); navigate('/', { replace: true }); }} title="Sign out" className="text-white hover:bg-white/10">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          {/* Breadcrumb & Title + Tabs */}
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-8">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-foreground">Procurement</h1>
                <p className="text-sm text-muted-foreground">Manage procurement requests, approvals, and purchase orders</p>
              </div>
            </div>
            <TabsList className="flex-wrap h-auto gap-1">
            <TabsTrigger value="overview" className="gap-1.5">
              <TrendingUp className="w-3.5 h-3.5" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="new-request" className="gap-1.5">
              <ShoppingCart className="w-3.5 h-3.5" />
              New Request
            </TabsTrigger>
            <TabsTrigger value="my-requests" className="gap-1.5">
              My Requests
              {stats.total > 0 && (
                <Badge variant="secondary" className="ml-1 h-5 min-w-[20px] px-1.5 text-xs">{stats.total}</Badge>
              )}
            </TabsTrigger>
            {isApprover && (
              <TabsTrigger value="approvals" className="gap-1.5">
                Approvals
                {stats.pending > 0 && (
                  <Badge className="ml-1 h-5 min-w-[20px] px-1.5 text-xs bg-amber-100 text-amber-800 hover:bg-amber-100">{stats.pending}</Badge>
                )}
              </TabsTrigger>
            )}
            <TabsTrigger value="workflow" className="gap-1.5">
              Approval Hierarchy
            </TabsTrigger>
          </TabsList>
          </div>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="space-y-8">
              {/* Stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {statCards.map(s => {
                  const Icon = s.icon;
                  return (
                    <Card key={s.label} className="relative overflow-hidden">
                      <CardContent className="p-5">
                        <div className="flex items-center gap-3">
                          <div className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center shrink-0`}>
                            <Icon className={`w-5 h-5 ${s.color}`} />
                          </div>
                          <div>
                            <p className="text-2xl font-bold text-foreground">{s.value}</p>
                            <p className="text-xs text-muted-foreground">{s.label}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Quick Actions */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                {[
                  { label: 'Product Request', desc: 'Physical products, equipment, or supplies', icon: Package, tab: 'new-request', color: 'bg-primary/10 text-primary' },
                  { label: 'Software / Service', desc: 'Software licenses, SaaS, or services', icon: Monitor, tab: 'new-request', color: 'bg-indigo-50 text-indigo-600' },
                  { label: 'People Request', desc: 'Staffing, outsourcing, or contractor requests', icon: Users, tab: 'new-request', color: 'bg-purple-50 text-purple-600' },
                ].map(a => {
                  const Icon = a.icon;
                  return (
                    <button
                      key={a.label}
                      onClick={() => setActiveTab(a.tab)}
                      className="group flex items-center gap-4 p-5 rounded-xl glass hover:border-primary/40 hover:shadow-md transition-all text-left"
                    >
                      <div className={`w-12 h-12 rounded-xl ${a.color} flex items-center justify-center shrink-0`}>
                        <Icon className="w-6 h-6" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-foreground text-sm group-hover:text-primary transition-colors">{a.label}</h3>
                        <p className="text-xs text-muted-foreground mt-0.5">{a.desc}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </button>
                  );
                })}
              </div>

              {/* Approval Workflow Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Approval Workflow</CardTitle>
                  <CardDescription>All procurement requests follow a structured approval hierarchy based on category</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Product / Software Flow */}
                    <div className="space-y-3">
                      <h4 className="text-sm font-semibold text-foreground flex items-center gap-2">
                        <Package className="w-4 h-4 text-primary" />
                        Product (IT) / Software Service
                      </h4>
                      <WorkflowSteps steps={['Ops Manager', 'IT Manager', 'COO', 'Finance Auth', 'Purchase – PO']} />
                    </div>
                    <div className="space-y-3">
                      <h4 className="text-sm font-semibold text-foreground flex items-center gap-2">
                        <Package className="w-4 h-4 text-muted-foreground" />
                        Product (Non-IT) / People (Non-IT)
                      </h4>
                      <WorkflowSteps steps={['Ops Manager', 'Finance Auth', 'Purchase – PO']} />
                    </div>
                    <div className="space-y-3 md:col-span-2">
                      <h4 className="text-sm font-semibold text-foreground flex items-center gap-2">
                        <Users className="w-4 h-4 text-purple-600" />
                        People (IT Development)
                      </h4>
                      <WorkflowSteps steps={['COO', 'HR – Outsource', 'Finance Auth', 'HR – Release PO', 'Ops Manager – Info']} />
                    </div>
                  </div>
                  <div className="mt-4 pt-4 border-t border-border">
                    <Button variant="outline" size="sm" onClick={() => setActiveTab('workflow')} className="gap-1.5">
                      View Full Approval Hierarchy
                      <ArrowRight className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Rejection Rules */}
              <div className="flex items-start gap-3 p-4 rounded-xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800">
                <AlertTriangle className="w-5 h-5 text-amber-600 mt-0.5 shrink-0" />
                <div>
                  <h4 className="text-sm font-semibold text-amber-900 dark:text-amber-200">Rejection Policy</h4>
                  <p className="text-xs text-amber-800 dark:text-amber-300 mt-1">
                    Requests can be rejected for: <strong>no budget</strong>, <strong>no prior approval</strong>, or if deemed <strong>illegal</strong>. Finance authorizes only — never approves or rejects. All rejections require a reason.
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* New Request Tab */}
          <TabsContent value="new-request">
            <StoreRequestForm onSuccess={() => { setActiveTab('my-requests'); fetchStats(); }} />
          </TabsContent>

          {/* My Requests Tab */}
          <TabsContent value="my-requests">
            <MyStoreRequests />
          </TabsContent>

          {/* Approvals Tab */}
          {isApprover && (
            <TabsContent value="approvals">
              <StoreApprovalQueue />
            </TabsContent>
          )}

          {/* Workflow Tab */}
          <TabsContent value="workflow">
            <ApprovalHierarchy />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

function WorkflowSteps({ steps }: { steps: string[] }) {
  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <span className="text-xs font-medium bg-primary/10 text-primary px-2.5 py-1 rounded-full">Requester</span>
      {steps.map((step, i) => (
        <div key={i} className="flex items-center gap-1.5">
          <ArrowRight className="w-3 h-3 text-muted-foreground shrink-0" />
          <span className="text-xs bg-secondary text-secondary-foreground px-2.5 py-1 rounded-full whitespace-nowrap">{step}</span>
        </div>
      ))}
    </div>
  );
}

export default Procurement;