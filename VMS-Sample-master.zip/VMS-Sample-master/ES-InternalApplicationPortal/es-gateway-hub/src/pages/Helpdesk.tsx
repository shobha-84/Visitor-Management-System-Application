import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import esLogo from '@/assets/excelsoft-logo-white.svg';
import { supabase } from '@/integrations/supabase/client';
import { TicketForm } from '@/components/helpdesk/TicketForm';
import { MyTickets } from '@/components/helpdesk/MyTickets';
import { SupportQueue } from '@/components/helpdesk/SupportQueue';

const Helpdesk = () => {
  const { user, roles, profile, loading, signOut } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('my-tickets');
  const [counts, setCounts] = useState({ myTickets: 0, open: 0 });

  const isSupportStaff = roles.some(r =>
    ['it_manager', 'employee_system_admin', 'employee_system'].includes(r)
  );

  const fetchCounts = useCallback(async () => {
    if (!user) return;
    const myRes = await supabase.from('helpdesk_tickets' as any).select('id', { count: 'exact', head: true }).eq('created_by', user.id);
    let openCount = 0;
    if (isSupportStaff) {
      const openRes = await supabase.from('helpdesk_tickets' as any).select('id', { count: 'exact', head: true }).in('status', ['open', 'in_progress']);
      openCount = (openRes as any).count ?? 0;
    }
    setCounts({
      myTickets: (myRes as any).count ?? 0,
      open: openCount,
    });
  }, [user, isSupportStaff]);

  useEffect(() => { fetchCounts(); }, [fetchCounts]);

  useEffect(() => {
    if (!loading && !user) navigate('/', { replace: true });
  }, [user, loading, navigate]);

  if (loading || !user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-mesh">
      <header className="border-b border-white/20 glass-header" style={{ background: 'linear-gradient(135deg, rgba(23, 54, 120, 0.85), rgba(21, 150, 193, 0.85))' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-12 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img src={esLogo} alt="Excelsoft" className="h-8" />
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-white">{profile?.full_name || user?.email}</p>
              <p className="text-xs text-white/70">{user?.email}</p>
            </div>
            <Button variant="ghost" size="icon" onClick={() => { signOut(); navigate('/', { replace: true }); }} title="Sign out" className="text-white hover:bg-white/10">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 mb-6">
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" onClick={() => navigate('/')}>
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <h1 className="text-2xl font-bold text-foreground">Helpdesk</h1>
            </div>
            <TabsList className="flex-wrap h-auto gap-1">
              <TabsTrigger value="my-tickets" className="gap-1.5">
                My Tickets
                {counts.myTickets > 0 && (
                  <Badge variant="secondary" className="ml-1 h-5 min-w-[20px] px-1.5 text-xs">
                    {counts.myTickets}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="new-ticket">New Ticket</TabsTrigger>
              {isSupportStaff && (
                <TabsTrigger value="support-queue" className="gap-1.5">
                  Support Queue
                  {counts.open > 0 && (
                    <Badge className="ml-1 h-5 min-w-[20px] px-1.5 text-xs bg-yellow-100 text-yellow-800 hover:bg-yellow-100">
                      {counts.open}
                    </Badge>
                  )}
                </TabsTrigger>
              )}
            </TabsList>
          </div>

          <TabsContent value="my-tickets">
            <MyTickets />
          </TabsContent>
          <TabsContent value="new-ticket">
            <TicketForm onSuccess={() => { setActiveTab('my-tickets'); fetchCounts(); }} />
          </TabsContent>
          {isSupportStaff && (
            <TabsContent value="support-queue">
              <SupportQueue />
            </TabsContent>
          )}
        </Tabs>
      </main>
    </div>
  );
};

export default Helpdesk;
