import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { ROLE_LABELS, ROLE_APPS, AppInfo } from '@/lib/roleConfig';
import { LogOut, ChevronRight, Shield, Fingerprint, Droplets, Zap, Car, User } from 'lucide-react';
import esLogo from '@/assets/excelsoft-logo-white.svg';
import { Button } from '@/components/ui/button';
import { useEffect, useState } from 'react';



type AppRole =
  | "manager_technical"
  | "employee_system_admin"
  | "manager_store"
  | "employee_security"



const USER_SPECIFIC_APPS: Record<string, AppInfo[]> = {
  'shankar.prasad@excelsoftcorp.com': [
    { id: 'biometrics', name: 'Biometrics', description: 'Manage biometric access and attendance', icon: Fingerprint, color: 'bg-fuchsia-600' },
    { id: 'water-systems', name: 'Water', description: 'Monitor water management systems', icon: Droplets, color: 'bg-cyan-500' },
    { id: 'electrical-systems', name: 'Electricity', description: 'Monitor and manage electrical infrastructure', icon: Zap, color: 'bg-yellow-500' },
    { id: 'fleet-manager', name: 'Vehicle', description: 'Vehicle tracking and scheduling', icon: Car, color: 'bg-emerald-500' },
  ],
};

const Dashboard = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [showLogout, setShowLogout] = useState(false);
  const [open, setOpen] = useState(false);

  const roles: AppRole[] = (() => {
    if (!user?.role) return [];

    switch (user.role) {
      case "Security":
        return ["employee_security"];

      case "Admin":
        return [
          "manager_technical",
          "employee_system_admin",
          "manager_store"
        ];
      case "Employee":
        return [
          "manager_technical",
          "employee_system_admin",
          "manager_store"
        ];

      default:
        return [];
    }
  })();


  const profile = (() => {
    if (!user?.role) return null;

    switch (user.role) {
      case "Security":
        return {
          full_name: "Security",
          employee_id: "100",
          designation: null,
          department: "Security",
          location: null,
          contact_number: null
        };

      case "Admin":
        return {
          full_name: "Admin",
          employee_id: "0000001077",
          designation: "Admin",
          department: "Engineering",
          location: "Mysore",
          contact_number: null
        };

      case "Employee":
        return {
          full_name: "Employee",
          employee_id: "0000001077",
          designation: "Employee",
          department: "Engineering",
          location: "Mysore",
          contact_number: null
        };
      default:
        return null;
    }
  })();

  // Collect unique apps from all roles
  const appsMap = new Map<string, AppInfo>();
  roles.forEach(role => {
    const apps = ROLE_APPS[role] || [];
    apps.forEach(app => appsMap.set(app.id, app));
  });
  const apps = Array.from(appsMap.values());

  // Add user-specific apps
  const userEmail = user?.email?.toLowerCase() || '';
  const extraApps = USER_SPECIFIC_APPS[userEmail] || [];
  extraApps.forEach(app => { if (!appsMap.has(app.id)) appsMap.set(app.id, app); });
  // const allApps = Array.from(appsMap.values());

  const allApps = Array.from(appsMap.values()).filter(
    app => app.id === 'invite-visitor'
  );

  const handleAppClick = (app: AppInfo) => {
    if (app.id === 'user-management') {
      navigate('/admin/users');
    } else if (app.id === 'invite-visitor') {
      navigate('/visitor-management');
    } else if (app.id === 'store-management') {
      navigate('/store-management');
    } else if (app.id === 'procurement') {
      navigate('/procurement');
    } else if (app.id === 'helpdesk') {
      navigate('/helpdesk');
    }
  };

  useEffect(() => {
    if (showLogout) {
      const timer = setTimeout(() => setShowLogout(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [showLogout]);

  return (
    <div className="min-h-screen bg-mesh">
      {/* Header */}
      <header className="border-b border-white/20 glass-header" style={{ background: 'linear-gradient(135deg, rgba(23, 54, 120, 0.85), rgba(21, 150, 193, 0.85))' }}>
        <div className="flex h-12 w-full items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <img src={esLogo} alt="Excelsoft" className="h-8" />
          </div>
          <div className="ml-auto flex shrink-0 items-center gap-4">
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-white">{profile?.full_name || user?.email}</p>
              <p className="text-sm text-white">{user?.email}</p>
            </div>
            <div className="relative">

              {/* PROFILE ICON */}
              <Button
                variant="ghost"
                className="text-white hover:bg-white/10 p-2"
                onClick={() => setOpen(!open)}
              >
                <User className="w-6 h-6" />
              </Button>

              {/* DROPDOWN */}
              {open && (
                <div className="absolute right-0 mt-2 w-40 bg-white rounded-lg shadow-lg border z-50">
                  <button
                    onClick={() => { setOpen(false); signOut(); navigate("/", { replace: true }); }}
                    className="w-full flex items-center gap-2 px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
                  >
                    <LogOut className="w-4 h-4 text-blue-600" />
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Welcome + Roles */}
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-bold text-foreground">
              Welcome back, {profile?.full_name?.split(' ')[0] || 'there'}
            </h1>
            {/* {roles.map(role => ( */}
            {/* <span
                key={role}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-medium"
              >
                <Shield className="w-3 h-3" />
                {ROLE_LABELS[role]}
              </span>
            ))} */}
            {roles.length === 0 && (
              <span className="text-sm text-muted-foreground">
                No roles assigned yet. Contact your administrator to get access.
              </span>
            )}
          </div>
          <p className="text-muted-foreground mt-1">Access your internal applications below.</p>
        </div>

        {/* Apps Grid */}
        {allApps.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
            {allApps.map(app => {
              const Icon = app.icon;
              return (
                <button
                  key={app.id}
                  onClick={() => handleAppClick(app)}
                  className="group relative flex flex-col items-center text-center gap-3 p-6 rounded-xl glass hover:border-primary/40 hover:shadow-lg transition-all duration-200 cursor-pointer"
                >
                  {/* Icon container */}
                  <div
                    className={`w-14 h-14 rounded-2xl ${app.color} flex items-center justify-center shadow-md group-hover:scale-110 transition-transform duration-200`}
                  >
                    <Icon className="w-7 h-7 text-primary-foreground" />
                  </div>

                  {/* Text */}
                  <div className="space-y-1">
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors text-sm">
                      {app.name}
                    </h3>
                    <p className="text-xs text-muted-foreground line-clamp-2 leading-relaxed">
                      {app.description}
                    </p>
                  </div>

                  {/* Hover arrow indicator */}
                  <ChevronRight className="absolute top-3 right-3 w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:text-primary transition-all duration-200" />
                </button>
              );
            })}
          </div>
        ) : (
          roles.length > 0 && (
            <div className="rounded-xl glass p-8 text-center">
              <p className="text-muted-foreground">No applications are configured for your current roles.</p>
            </div>
          )
        )}
      </main>
    </div>
  );
};

export default Dashboard;
