
import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useToast } from '@/hooks/use-toast';
import { Package, Monitor, Users, AlertTriangle } from 'lucide-react';
import { apiFetch } from '@/api/http';


const CATEGORIES = [
  { value: 'product', label: 'Product', icon: Package, description: 'Physical products, equipment, or supplies' },
  { value: 'software_service', label: 'Software / Service', icon: Monitor, description: 'Software licenses, SaaS, or services' },
  { value: 'people', label: 'People', icon: Users, description: 'Staffing, outsourcing, or contractor requests' },
] as const;

const URGENCY_OPTIONS = [
  { value: 'low', label: 'Low', color: 'text-muted-foreground' },
  { value: 'normal', label: 'Normal', color: 'text-foreground' },
  { value: 'high', label: 'High', color: 'text-orange-600' },
  { value: 'critical', label: 'Critical', color: 'text-destructive' },
];

interface Props {
  onSuccess: () => void;
}

export function StoreRequestForm({ onSuccess }: Props) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<any>({});
  const [category, setCategory] = useState<string>('');
  const [isItRelated, setIsItRelated] = useState(false);
  const [form, setForm] = useState({
    title: '',
    description: '',
    estimated_cost: '',
    quantity: '1',
    urgency: 'normal',
    department: '',
    vendor_details: '',
    notes: '',
  });

  const getApprovalPath = () => {
    if (!category) return [];

    if (category === 'product') {
      if (isItRelated) {
        return ['Ops Manager', 'IT Manager', 'COO', 'Finance Authorization', 'Purchase – Release PO'];
      }
      return ['Ops Manager', 'Finance Authorization', 'Purchase – Release PO'];
    }

    if (category === 'software_service') {
      return ['Ops Manager', 'IT Manager', 'COO', 'Finance Authorization', 'Purchase – Release PO'];
    }

    if (category === 'people') {
      if (isItRelated) {
        return ['COO', 'HR – Outsource Initiation', 'Finance Authorization', 'HR – Release PO', 'Ops Manager – Information'];
      }
      return ['Ops Manager', 'Finance Authorization', 'Purchase – Release PO'];
    }

    return [];
  };

  const getInitialStatus = () => {
    if (category === 'people' && isItRelated) return 'pending_coo';
    return 'pending_ops_manager';
  };

  //
  const validateForm = () => {
  let err: any = {};

  if (!form.title.trim()) err.title = "Title is required";

  if (category === "product") {
    if (!form.quantity || Number(form.quantity) <= 0) {
      err.quantity = "Quantity is required";
    }
  }

  if (category === "software_service") {
    if (!form.notes) err.notes = "License type is required";
    if (!form.quantity || Number(form.quantity) <= 0) {
      err.quantity = "Number of licenses is required";
    }
  }

  if (category === "people") {
    if (!form.notes) err.notes = "Employment type is required";
    if (!form.quantity || Number(form.quantity) <= 0) {
      err.quantity = "Number of people is required";
    }
  }

  setErrors(err);
  return Object.keys(err).length === 0;
};
//

 const handleSubmit = async (asDraft: boolean) => {
  if (!user || !category) return;

if (!asDraft) {
  const valid = validateForm();
  console.log("Validation result:", valid);  // ✅ add this
  if (!valid) return;
}


  setLoading(true);

  try {
    await apiFetch("/api/StoreRequests", {
      method: "POST",
      body: JSON.stringify({
        created_by: user.id,
        title: form.title,
        description: form.description || null,
        category,
        is_it_related: isItRelated,
        estimated_cost: form.estimated_cost
          ? parseFloat(form.estimated_cost)
          : null,
        quantity: parseInt(form.quantity) || 1,
        urgency: form.urgency,
        department: form.department || null,
        vendor_details: form.vendor_details || null,
        notes: form.notes || null,
        
// ✅ STEP 5 ADDITION
  license_type: category === "software_service" ? form.notes : null,
  employment_type: category === "people" ? form.notes : null

      })
    });

    toast({ title: "Request submitted successfully" });
    onSuccess();

  } catch (err: any) {
    toast({
      title: "Error",
      description: err.message,
      variant: "destructive"
    });
  }

  setLoading(false);
};



  const approvalPath = getApprovalPath();

  return (
    <div className="space-y-6 max-w-3xl">
      {/* Category Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Request Category</CardTitle>
          <CardDescription>Select the type of procurement request</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {CATEGORIES.map(cat => {
              const Icon = cat.icon;
              const selected = category === cat.value;
              return (
                <button
                  key={cat.value}
                  onClick={() => { setCategory(cat.value); setIsItRelated(false); }}
                  className={`flex flex-col items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                    selected
                      ? 'border-primary bg-primary/5 shadow-sm'
                      : 'border-border hover:border-primary/40'
                  }`}
                >
                  <Icon className={`w-8 h-8 ${selected ? 'text-primary' : 'text-muted-foreground'}`} />
                  <span className={`font-medium text-sm ${selected ? 'text-primary' : 'text-foreground'}`}>{cat.label}</span>
                  <span className="text-xs text-muted-foreground text-center">{cat.description}</span>
                </button>
              );
            })}
          </div>

          {/* IT Related toggle */}
          {(category === 'product' || category === 'people') && (
            <div className="mt-4 flex items-center gap-3 p-3 rounded-lg bg-secondary/50">
              <Switch checked={isItRelated} onCheckedChange={setIsItRelated} />
              <Label className="text-sm font-medium">
                {category === 'product' ? 'Is this an IT product?' : 'Is this for IT Development?'}
              </Label>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Approval Path Preview */}
      {category && approvalPath.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Approval Path</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-medium bg-primary/10 text-primary px-2.5 py-1 rounded-full">You (Requester)</span>
              {approvalPath.map((step, i) => (
                <div key={i} className="flex items-center gap-1.5">
                  <span className="text-muted-foreground text-xs">→</span>
                  <span className="text-xs bg-secondary text-secondary-foreground px-2.5 py-1 rounded-full">{step}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Request Details */}
     {/* Request Details */}
{category && (
  <Card>
    <CardHeader>
      <CardTitle className="text-lg">Request Details</CardTitle>
    </CardHeader>

    {/* ✅ PRODUCT (OLD FORM SAME AS BEFORE) */}
    {category === "product" && (
     
    <CardContent className="space-y-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">

        {/* Title */}
        <div className="sm:col-span-2">
          <Label htmlFor="title">Title *</Label>
          <Input
  id="title"
  className={errors.title ? "border-red-500" : ""}
  value={form.title}
  onChange={e => {
    setForm(f => ({ ...f, title: e.target.value }));
    setErrors((p:any) => ({ ...p, title: "" }));
  }}
/>

{errors.title && <p className="text-red-500 text-xs mt-1">{errors.title}</p>}
        </div>

        {/* Description */}
        <div className="sm:col-span-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            placeholder="Detailed description of what you need..."
            rows={3}
            value={form.description}
            onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
          />
        </div>

        {/* Cost */}
        <div>
          <Label htmlFor="estimated_cost">Estimated Cost (₹)</Label>
          <Input
            id="estimated_cost"
            type="number"
            min="0"
            step="0.01"
            placeholder="0.00"
            value={form.estimated_cost}
            onChange={e => setForm(f => ({ ...f, estimated_cost: e.target.value }))}
          />
        </div>

        {/* Quantity */}
        <div>
          <Label htmlFor="quantity">Quantity</Label>
          <Input
  id="quantity"
  type="number"
  className={errors.quantity ? "border-red-500" : ""}
  value={form.quantity}
  onChange={e => {
    setForm(f => ({ ...f, quantity: e.target.value }));
    setErrors((p:any) => ({ ...p, quantity: "" }));
  }}
/>

{errors.quantity && <p className="text-red-500 text-xs mt-1">{errors.quantity}</p>}
        </div>

        {/* Urgency */}
        <div>
          <Label>Urgency</Label>
          <Select
            value={form.urgency}
            onValueChange={v => setForm(f => ({ ...f, urgency: v }))}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="normal">Normal</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Department */}
        <div>
          <Label htmlFor="department">Department</Label>
          <Select
            value={form.department}
            onValueChange={v => setForm(f => ({ ...f, department: v }))}
          >
            <SelectTrigger id="department">
              <SelectValue placeholder="Select department" />
            </SelectTrigger>
            <SelectContent>
              {['Sales', 'Marketing', 'Engineering', 'Human Resources', 'Finance', 'Operations', 'Business Development', 'Management'].map(dept => (
                <SelectItem key={dept} value={dept}>{dept}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Vendor */}
        <div className="sm:col-span-2">
          <Label htmlFor="vendor">Vendor Details (Optional)</Label>
          <Input
            id="vendor"
            placeholder="Preferred vendor or supplier"
            value={form.vendor_details}
            onChange={e => setForm(f => ({ ...f, vendor_details: e.target.value }))}
          />
        </div>

        {/* Notes */}
        <div className="sm:col-span-2">
          <Label htmlFor="notes">Additional Notes</Label>
          <Textarea
            id="notes"
            placeholder="Any additional information..."
            rows={2}
            value={form.notes}
            onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
          />
        </div>
      </div>

      {/* Info box */}
      <div className="flex items-start gap-2 p-3 rounded-lg bg-amber-50 border border-amber-200">
        <AlertTriangle className="w-4 h-4 text-amber-600 mt-0.5 shrink-0" />
        <p className="text-xs text-amber-800">
          Requests can be rejected for: no budget, no prior approval, or if deemed illegal.
          Finance authorizes only — never approves or rejects.
        </p>
      </div>

      {/* Buttons */}
      <div className="flex gap-3 pt-2">
        <Button variant="outline" onClick={() => handleSubmit(true)} disabled={loading}>
          Save as Draft
        </Button>
        <Button onClick={() => handleSubmit(false)} disabled={loading || !form.title.trim()}>
          {loading ? 'Submitting...' : 'Submit Request'}
        </Button>
      </div>

    </CardContent>
    )}

    {/* ✅ SOFTWARE */}
    {category === "software_service" && (
      <CardContent className="space-y-3">

        <Label>Software Name</Label>
        <Input value={form.title}
          onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
        />

        <Label>License Type</Label>
        <Input value={form.notes}
          placeholder="Annual / Monthly"
          onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
        />

        <Label>No. of Licenses</Label>
        <Input type="number"
          value={form.quantity}
          onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))}
        />

        <Label>Purpose</Label>
        <Textarea
          value={form.description}
          onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
        />

        <Label>Cost</Label>
        <Input type="number"
          value={form.estimated_cost}
          onChange={e => setForm(f => ({ ...f, estimated_cost: e.target.value }))}
        />

        <div className="flex gap-3 pt-3">
          <Button onClick={() => handleSubmit(true)}>Save Draft</Button>
          <Button onClick={() => handleSubmit(false)}>Submit</Button>
        </div>

      </CardContent>
    )}

    {/* ✅ PEOPLE */}
    {category === "people" && (
      <CardContent className="space-y-3">

        <Label>Role / Position</Label>
       <Input
  className={errors.title ? "border-red-500" : ""}
  value={form.title}
  onChange={e => {
    setForm(f => ({ ...f, title: e.target.value }));
    setErrors((prev: any) => ({ ...prev, title: "" }));
  }}
/>

{errors.title && (
  <p className="text-red-500 text-xs mt-1">{errors.title}</p>
)}


        <Label>Number of People</Label>
        <Input type="number"
          value={form.quantity}
          onChange={e => setForm(f => ({ ...f, quantity: e.target.value }))}
        />

        <Label>Employment Type</Label>
        <Input
          value={form.notes}
          placeholder="Full-time / Contract"
          onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
        />

        <Label>Justification</Label>
        <Textarea
          value={form.description}
          onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
        />

        <Label>Expected Salary</Label>
        <Input type="number"
          value={form.estimated_cost}
          onChange={e => setForm(f => ({ ...f, estimated_cost: e.target.value }))}
        />

        <div className="flex gap-3 pt-3">
          <Button onClick={() => handleSubmit(true)}>Save Draft</Button>
          <Button onClick={() => handleSubmit(false)}>Submit</Button>
        </div>

      </CardContent>
    )}

  </Card>
)}
    </div>
  );
}
