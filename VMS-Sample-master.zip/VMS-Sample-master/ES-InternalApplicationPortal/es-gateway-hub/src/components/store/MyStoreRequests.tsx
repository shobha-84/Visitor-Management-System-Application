import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Package, Monitor, Users, Clock, CheckCircle2, XCircle, FileText, Send, ChevronDown, ChevronUp } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/api/http';
  

const STATUS_CONFIG: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline'; color?: string }> = {
  draft: { label: 'Draft', variant: 'outline' },
  pending_ops_manager: { label: 'Pending Ops Manager', variant: 'secondary', color: 'bg-yellow-100 text-yellow-800' },
  pending_it_manager: { label: 'Pending IT Manager', variant: 'secondary', color: 'bg-blue-100 text-blue-800' },
  pending_coo: { label: 'Pending COO', variant: 'secondary', color: 'bg-purple-100 text-purple-800' },
  pending_finance: { label: 'Pending Finance', variant: 'secondary', color: 'bg-indigo-100 text-indigo-800' },
  pending_hr: { label: 'Pending HR', variant: 'secondary', color: 'bg-pink-100 text-pink-800' },
  pending_purchase: { label: 'Pending Purchase', variant: 'secondary', color: 'bg-cyan-100 text-cyan-800' },
  finance_authorized: { label: 'Finance Authorized', variant: 'default', color: 'bg-emerald-100 text-emerald-800' },
  approved: { label: 'Approved', variant: 'default', color: 'bg-green-100 text-green-800' },
  rejected: { label: 'Rejected', variant: 'destructive' },
  po_released: { label: 'PO Released', variant: 'default', color: 'bg-teal-100 text-teal-800' },
};

const CATEGORY_ICONS: Record<string, typeof Package> = {
  product: Package,
  software_service: Monitor,
  people: Users,
};

const CATEGORY_LABELS: Record<string, string> = {
  product: 'Product',
  software_service: 'Software / Service',
  people: 'People',
};

export function MyStoreRequests() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [expandedId, setExpandedId] = useState<string | null>(null);

 const fetchRequests = async () => {
  if (!user) return;

  setLoading(true);

  try {
    const data = await apiFetch(`/api/StoreRequests/user/${user.id}`);
    setRequests(data);
  } catch (err: any) {
    toast({ title: "Error", description: err.message, variant: "destructive" });
  }

  setLoading(false);
};


useEffect(() => {
  if (user) {
    fetchRequests();
  }
}, [user]);
 
  const filtered = useMemo(() => {
    if (statusFilter === 'all') return requests;
    return requests.filter(r => r.status === statusFilter);
  }, [requests, statusFilter]);

  
///
const handleSubmitDraft = async (id: string, request: any) => {
  const initialStatus = request.category === 'people' && request.is_it_related
    ? 'pending_coo'
    : 'pending_ops_manager';

  try {
    await apiFetch(`/api/StoreRequests/${id}`, {
      method: "PUT",
      body: JSON.stringify({
        status: initialStatus,
        current_approver_role:
          request.category === 'people' && request.is_it_related
            ? 'coo'
            : 'manager_non_technical'
      })
    });

    toast({ title: "Request submitted" });
    fetchRequests();

 } catch (err: any) {
  console.error("Fetch error:", err);
  toast({
    title: "Error fetching requests",
    description: err?.message || "Something went wrong",
    variant: "destructive"
  });
}

};
//

  if (loading) {
    return <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" /></div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Filter by status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            {Object.entries(STATUS_CONFIG).map(([k, v]) => (
              <SelectItem key={k} value={k}>{v.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <span className="text-sm text-muted-foreground">{filtered.length} request{filtered.length !== 1 ? 's' : ''}</span>
      </div>

      {filtered.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <FileText className="w-10 h-10 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">No requests found</p>
          </CardContent>
        </Card>
      ) : (
        filtered.map(req => {
          const Icon = CATEGORY_ICONS[req.category] || Package;
          const statusInfo = STATUS_CONFIG[req.status] || { label: req.status, variant: 'secondary' as const, color: '' };
          const expanded = expandedId === req.id;

          return (
            <Card key={req.id} className="overflow-hidden">
              <button
                className="w-full text-left p-4 flex items-center gap-4 hover:bg-secondary/30 transition-colors"
                onClick={() => setExpandedId(expanded ? null : req.id)}
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="font-medium text-foreground truncate">{req.title}</h3>
                    <Badge className={statusInfo.color || ''} variant={statusInfo.variant}>{statusInfo.label}</Badge>
                  </div>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                    <span>{CATEGORY_LABELS[req.category]}</span>
                    {req.is_it_related && <span className="text-primary font-medium">IT Related</span>}
                    <span>•</span>
                    <span>{format(new Date(req.createdAt), 'dd MMM yyyy')}</span>
                    {req.estimated_cost && (
                      <>
                        <span>•</span>
                        <span>₹{Number(req.estimated_cost).toLocaleString()}</span>
                      </>
                    )}
                  </div>
                </div>
                <div className="shrink-0">
                  {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                </div>
              </button>

              {expanded && (
                <div className="px-4 pb-4 border-t border-border pt-3 space-y-3">
                  {req.description && (
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-1">Description</p>
                      <p className="text-sm text-foreground">{req.description}</p>
                    </div>
                  )}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
                    <div>
                      <p className="text-xs text-muted-foreground">Quantity</p>
                      <p className="font-medium">{req.quantity}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Urgency</p>
                      <p className="font-medium capitalize">{req.urgency}</p>
                    </div>
                    {req.department && (
                      <div>
                        <p className="text-xs text-muted-foreground">Department</p>
                        <p className="font-medium">{req.department}</p>
                      </div>
                    )}
                    {req.vendor_details && (
                      <div>
                        <p className="text-xs text-muted-foreground">Vendor</p>
                        <p className="font-medium">{req.vendor_details}</p>
                      </div>
                    )}
                  </div>

                  {/* Approval Timeline */}
                  <div>
                    <p className="text-xs font-medium text-muted-foreground mb-2">Approval Timeline</p>
                    <div className="space-y-1.5">
                      {req.ops_manager_approved_at && (
                        <div className="flex items-center gap-2 text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
                          <span>Ops Manager approved — {format(new Date(req.ops_manager_approved_at), 'dd MMM yyyy, HH:mm')}</span>
                        </div>
                      )}
                      {req.it_manager_approved_at && (
                        <div className="flex items-center gap-2 text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
                          <span>IT Manager approved — {format(new Date(req.it_manager_approved_at), 'dd MMM yyyy, HH:mm')}</span>
                        </div>
                      )}
                      {req.coo_approved_at && (
                        <div className="flex items-center gap-2 text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
                          <span>COO approved — {format(new Date(req.coo_approved_at), 'dd MMM yyyy, HH:mm')}</span>
                        </div>
                      )}
                      {req.finance_authorized_at && (
                        <div className="flex items-center gap-2 text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5 text-blue-600" />
                          <span>Finance authorized — {format(new Date(req.finance_authorized_at), 'dd MMM yyyy, HH:mm')}</span>
                        </div>
                      )}
                      {req.hr_approved_at && (
                        <div className="flex items-center gap-2 text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
                          <span>HR approved — {format(new Date(req.hr_approved_at), 'dd MMM yyyy, HH:mm')}</span>
                        </div>
                      )}
                      {req.po_released_at && (
                        <div className="flex items-center gap-2 text-xs">
                          <CheckCircle2 className="w-3.5 h-3.5 text-teal-600" />
                          <span>PO Released — {format(new Date(req.po_released_at), 'dd MMM yyyy, HH:mm')}</span>
                        </div>
                      )}
                      {req.status === 'rejected' && req.rejection_reason && (
                        <div className="flex items-start gap-2 text-xs">
                          <XCircle className="w-3.5 h-3.5 text-destructive mt-0.5" />
                          <span className="text-destructive">Rejected: {req.rejection_reason}</span>
                        </div>
                      )}
                      {!req.ops_manager_approved_at && !req.coo_approved_at && req.status !== 'draft' && req.status !== 'rejected' && (
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Awaiting approval...</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {req.status === 'draft' && (
                    <Button size="sm" onClick={() => handleSubmitDraft(req.id, req)} className="gap-1.5">
                      <Send className="w-3.5 h-3.5" /> Submit for Approval
                    </Button>
                  )}
                </div>
              )}
            </Card>
          );
        })
      )}
    </div>
  );
}