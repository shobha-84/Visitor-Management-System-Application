import { useState, useEffect, useMemo } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Package, Monitor, Users, CheckCircle2, XCircle, Clock, AlertTriangle } from 'lucide-react';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';
import { apiFetch } from '@/api/http';



const CATEGORY_LABELS: Record<string, string> = {
  product: 'Product',
  software_service: 'Software / Service',
  people: 'People',
};

const CATEGORY_ICONS: Record<string, typeof Package> = {
  product: Package,
  software_service: Monitor,
  people: Users,
};

const URGENCY_COLORS: Record<string, string> = {
  low: 'bg-secondary text-secondary-foreground',
  normal: 'bg-secondary text-secondary-foreground',
  high: 'bg-orange-100 text-orange-800',
  critical: 'bg-red-100 text-red-800',
};

interface ApprovalAction {
  requestId: string;
  type: 'approve' | 'reject' | 'authorize' | 'release_po';
}

export function StoreApprovalQueue() {
  const { user, roles } = useAuth();
  const { toast } = useToast();
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [action, setAction] = useState<ApprovalAction | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [processing, setProcessing] = useState(false);

  const userRole = useMemo(() => {
    if (roles.includes('ceo')) return 'ceo';
    if (roles.includes('coo')) return 'coo';
    if (roles.includes('director')) return 'director';
    if (roles.includes('manager_hr')) return 'manager_hr';
    if (roles.includes('manager_store')) return 'manager_store';
    if (roles.includes('manager_technical')) return 'manager_technical';
    if (roles.includes('manager_non_technical')) return 'manager_non_technical';
    return null;
  }, [roles]);

  const fetchRequests = async () => {
  setLoading(true);

  try {
    const data = await apiFetch("/api/StoreRequests");
    setRequests(data);
 } catch (err: any) {
  console.error("Fetch error:", err);
  toast({
    title: "Error fetching requests",
    description: err?.message || "Something went wrong",
    variant: "destructive"
  });
}


  setLoading(false);
};
//

useEffect(() => {
  if (user) {
    fetchRequests();
  }
}, [user]);


  // Filter requests that need action from this user's role
  const pendingForMe = useMemo(() => {
    
  if (!user) return [];

    const email = user?.email?.toLowerCase();
    const hasRole = (r: string) => roles.includes(r as any);
    return requests.filter(req => {
      const s = req.status;
      if (s === 'pending_ops_manager' && (email === 'tejaswi@excelsoftcorp.com' || hasRole('ops_manager'))) return true;
      if (s === 'pending_it_manager' && (email === 'srinivas@excelsoftcorp.com' || hasRole('it_manager'))) return true;
      if (s === 'pending_coo' && (email === 'mahesh.jambardi@excelsoftcorp.com' || hasRole('coo'))) return true;
      if (s === 'pending_finance' && (email === 'esfinance@excelsoftcorp.com' || hasRole('finance'))) return true;
if (s === 'pending_hr' && (email === 'mahesh.jambardi@excelsoftcorp.com' || hasRole('manager_hr') || hasRole('purchase_hr') || hasRole('hr'))) return true;
      if (s === 'pending_purchase' && (email === 'biju.r@excelsoftcorp.com' || hasRole('purchase_hr') || hasRole('purchase'))) return true;
      if (s === 'pending_hr_po_release' && (email === 'mahesh.jambardi@excelsoftcorp.com' || hasRole('manager_hr') || hasRole('purchase_hr') || hasRole('hr'))) return true;
      if (s === 'pending_ops_info' && (email === 'tejaswi@excelsoftcorp.com' || hasRole('ops_manager'))) return true;
      return false;
    });
  }, [requests, user, roles]);

  const otherRequests = useMemo(() => {
    return requests.filter(r => !pendingForMe.includes(r));
  }, [requests, pendingForMe]);

  const getNextStatus = (req: any): string => {
    const { status, category, is_it_related } = req;

    // Product + IT: Ops Manager → IT Manager → COO → Finance → Purchase (PO)
    if (category === 'product' && is_it_related) {
      if (status === 'pending_ops_manager') return 'pending_it_manager';
      if (status === 'pending_it_manager') return 'pending_coo';
      if (status === 'pending_coo') return 'pending_finance';
      if (status === 'pending_finance') return 'pending_purchase';
      if (status === 'pending_purchase') return 'po_released';
    }

    // Product + non-IT: Ops Manager → Finance → Purchase (PO)
    if (category === 'product' && !is_it_related) {
      if (status === 'pending_ops_manager') return 'pending_finance';
      if (status === 'pending_finance') return 'pending_purchase';
      if (status === 'pending_purchase') return 'po_released';
    }

    // Software Service: Ops Manager → IT Manager → COO → Finance → Purchase (PO)
    if (category === 'software_service') {
      if (status === 'pending_ops_manager') return 'pending_it_manager';
      if (status === 'pending_it_manager') return 'pending_coo';
      if (status === 'pending_coo') return 'pending_finance';
      if (status === 'pending_finance') return 'pending_purchase';
      if (status === 'pending_purchase') return 'po_released';
    }

    // People + IT: COO → HR → Finance → HR (release PO) → Ops Manager (info)
    if (category === 'people' && is_it_related) {
      if (status === 'pending_coo') return 'pending_hr';
      if (status === 'pending_hr') return 'pending_finance';
      if (status === 'pending_finance') return 'pending_hr_po_release';
      if (status === 'pending_hr_po_release') return 'pending_ops_info';
      if (status === 'pending_ops_info') return 'po_released';
    }

    // People + non-IT: Ops Manager → Finance → Purchase (PO)
    if (category === 'people' && !is_it_related) {
      if (status === 'pending_ops_manager') return 'pending_finance';
      if (status === 'pending_finance') return 'pending_purchase';
      if (status === 'pending_purchase') return 'po_released';
    }

    return 'po_released';
  };

 const handleAction = async () => {
  if (!action || !user) return;
  setProcessing(true);

  const req = requests.find(r => r.id === action.requestId);
  if (!req) return;

  let updateData: any = {};

  if (action.type === 'reject') {
    updateData = {
      status: 'rejected',
      rejection_reason: rejectionReason || 'No reason provided'
    };
  } else {
    const nextStatus = getNextStatus(req);
    const now = new Date().toISOString();

    if (req.status === 'pending_ops_manager') {
      updateData.ops_manager_approved_at = now;
    } else if (req.status === 'pending_it_manager') {
      updateData.it_manager_approved_at = now;
    } else if (req.status === 'pending_coo') {
      updateData.coo_approved_at = now;
    } else if (req.status === 'pending_finance') {
      updateData.finance_authorized_at = now;
    } else if (req.status === 'pending_hr') {
      updateData.hr_approved_at = now;
    } else if (req.status === 'pending_purchase') {
      updateData.po_released_at = now;
    } else if (req.status === 'pending_hr_po_release') {
      updateData.po_released_at = now;
    }

    updateData.status = nextStatus;
  }

  try {
    await apiFetch(`/api/StoreRequests/${action.requestId}`, {
      method: "PUT",
      body: JSON.stringify(updateData)
    });

    toast({
      title: action.type === 'reject'
        ? 'Request rejected'
        : 'Request approved'
    });

    fetchRequests();

  } catch (err: any) {
    toast({
      title: "Error",
      description: err.message,
      variant: "destructive"
    });
  }

  setProcessing(false);
  setAction(null);
  setRejectionReason('');
};


  const getActionLabel = (status: string) => {
    if (status === 'pending_finance') return 'Authorize';
    if (status === 'pending_purchase') return 'Release PO';
    if (status === 'pending_hr_po_release') return 'Release PO';
    if (status === 'pending_ops_info') return 'Acknowledge';
    return 'Approve';
  };

  const renderRequestCard = (req: any, showActions: boolean) => {
    const Icon = CATEGORY_ICONS[req.category] || Package;
    return (
      <Card key={req.id}>
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
              <Icon className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0 space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                <h3 className="font-medium text-foreground">{req.title}</h3>
                <Badge className={URGENCY_COLORS[req.urgency] || ''} variant="secondary">{req.urgency}</Badge>
                <Badge variant="outline">{CATEGORY_LABELS[req.category]}</Badge>
                {req.is_it_related && <Badge variant="secondary" className="bg-primary/10 text-primary">IT</Badge>}
              </div>
              {req.description && <p className="text-sm text-muted-foreground">{req.description}</p>}
              <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
                <span>Qty: {req.quantity}</span>
                {req.estimated_cost && <span>₹{Number(req.estimated_cost).toLocaleString()}</span>}
                {req.department && <span>{req.department}</span>}
                <span>{format(new Date(req.createdAt), 'dd MMM yyyy')}</span>
              </div>

              {showActions && (
                <div className="flex gap-2 pt-1">
                  <Button
                    size="sm"
                    className="gap-1.5"
                    onClick={() => setAction({ requestId: req.id, type: 'approve' })}
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    {getActionLabel(req.status)}
                  </Button>
                  {req.status !== 'pending_finance' && (
                    <Button
                      size="sm"
                      variant="destructive"
                      className="gap-1.5"
                      onClick={() => setAction({ requestId: req.id, type: 'reject' })}
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Reject
                    </Button>
                  )}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  if (loading) {
    return <div className="flex justify-center py-12"><div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" /></div>;
  }

  return (
    <div className="space-y-6">
      {/* Pending for me */}
      <div>
        <h2 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
          <Clock className="w-5 h-5 text-primary" />
          Pending Your Action
          {pendingForMe.length > 0 && <Badge variant="secondary">{pendingForMe.length}</Badge>}
        </h2>
        {pendingForMe.length === 0 ? (
          <Card>
            <CardContent className="py-8 text-center text-muted-foreground">
              No requests pending your action
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">{pendingForMe.map(r => renderRequestCard(r, true))}</div>
        )}
      </div>

      {/* All other in-progress */}
      {otherRequests.length > 0 && (
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-3">All In-Progress Requests</h2>
          <div className="space-y-3">{otherRequests.map(r => renderRequestCard(r, false))}</div>
        </div>
      )}

      {/* Rejection dialog */}
      <Dialog open={action?.type === 'reject'} onOpenChange={o => { if (!o) { setAction(null); setRejectionReason(''); } }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-destructive" />
              Reject Request
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Rejection reasons: no budget, no prior approval, or illegal.
            </p>
            <Textarea
              placeholder="Reason for rejection..."
              value={rejectionReason}
              onChange={e => setRejectionReason(e.target.value)}
              rows={3}
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setAction(null); setRejectionReason(''); }}>Cancel</Button>
            <Button variant="destructive" onClick={handleAction} disabled={processing}>
              {processing ? 'Rejecting...' : 'Reject'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Approval confirmation dialog */}
      <Dialog open={action?.type === 'approve'} onOpenChange={o => { if (!o) setAction(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              Confirm {action ? getActionLabel(requests.find(r => r.id === action.requestId)?.status || '') : 'Action'}
            </DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Are you sure you want to {action?.type === 'approve' ? 'approve' : 'process'} this request? It will move to the next step in the approval chain.
          </p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAction(null)}>Cancel</Button>
            <Button onClick={handleAction} disabled={processing}>
              {processing ? 'Processing...' : 'Confirm'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
