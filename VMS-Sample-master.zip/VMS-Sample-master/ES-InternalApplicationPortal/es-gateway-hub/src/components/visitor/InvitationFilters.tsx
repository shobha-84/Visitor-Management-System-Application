import { useState } from 'react';
import { format } from 'date-fns';
import { CalendarIcon, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';

import { startOfMonth } from 'date-fns';

interface Props {
  filter: InvitationFilter;
  onChange: (filter: InvitationFilter) => void;
  statusOptions: { value: string; label: string }[];
}

export function InvitationFilters({ filter, onChange, statusOptions }: Props) {
  const [openFrom, setOpenFrom] = useState(false);
  const [openTo, setOpenTo] = useState(false);

  const handleFromDateSelect = (date: Date | undefined) => {
    if (!date) return;
    if (filter.toDate && date > filter.toDate) {
      toast.error('Start date cannot be after end date');
      return;
    }
    onChange({ ...filter, fromDate: date, toDate: undefined });
    setOpenFrom(false);
  };

  const handleToDateSelect = (date: Date | undefined) => {
    if (!date) return;
    if (filter.fromDate && date < filter.fromDate) {
      toast.error('End date cannot be before start date');
      return;
    }
    onChange({ ...filter, toDate: date });
    setOpenTo(false);
  };

  const handleClear = () => {
    onChange({ fromDate: startOfMonth(new Date()), toDate: new Date(), status: 'all' });
    setOpenFrom(false);
    setOpenTo(false);
  };

  return (
    <div className="flex flex-wrap items-center gap-3 mb-4">
      {/* Start Date Picker */}
      <Popover open={openFrom} onOpenChange={setOpenFrom}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className={cn(
              'justify-start text-left font-normal h-9 w-[170px]',
              !filter.fromDate && 'text-muted-foreground'
            )}
          >
            <CalendarIcon className="w-3.5 h-3.5 mr-1.5" />
            {filter.fromDate ? format(filter.fromDate, 'dd-MM-yyyy') : 'Start date'}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={filter.fromDate}
            onSelect={handleFromDateSelect}
            initialFocus
            disabled={(date) => false}
          />
        </PopoverContent>
      </Popover>

      {/* End Date Picker */}
      <Popover open={openTo} onOpenChange={setOpenTo}>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className={cn(
              'justify-start text-left font-normal h-9 w-[170px]',
              !filter.toDate && 'text-muted-foreground'
            )}
          >
            <CalendarIcon className="w-3.5 h-3.5 mr-1.5" />
            {filter.toDate ? format(filter.toDate, 'dd-MM-yyyy') : 'End date'}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-auto p-0" align="start">
          <Calendar
            mode="single"
            selected={filter.toDate}
            onSelect={handleToDateSelect}
            initialFocus
            disabled={(date) => filter.fromDate ? date < filter.fromDate : date > new Date()}
          />
        </PopoverContent>
      </Popover>

      {/* Status filter */}
      <Select
        value={filter.status}
        onValueChange={(v) => onChange({ ...filter, status: v })}
      >
        <SelectTrigger className="w-[160px] h-9 text-sm">
          <SelectValue placeholder="All statuses" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="all">All Status</SelectItem>
          {statusOptions.map((opt) => (
            <SelectItem key={opt.value} value={opt.value}>
              {opt.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* Clear filters */}
      {(filter.fromDate || filter.toDate || filter.status !== 'all') && (
        <Button
          variant="ghost"
          size="sm"
          className="h-9 px-2 text-muted-foreground"
          onClick={handleClear}
        >
          <X className="w-3.5 h-3.5 mr-1" /> Clear
        </Button>
      )}
    </div>
  );
}

export function filterInvitations(invitations: any[], filter: InvitationFilter, visitorStates?: { [key: string]: string }, visitorStats?: { [key: string]: { last: string | null; count: number } }) {
  return invitations.filter((inv) => {

    // ✅ STATUS FILTER
    if (filter.status !== 'all') {
      const isRecurring = inv.visitor_type === "Recurring";
      const effectiveStatus = isRecurring && visitorStates
        ? (visitorStates[inv.visitor_phone] || inv.status)
        : inv.status;
      if (effectiveStatus !== filter.status) {
        return false;
      }
    }

    // ✅ DATE RANGE FILTER
    if (filter.fromDate || filter.toDate) {
      const isRecurring = inv.visitor_type === "Recurring";
      let checkDate: Date | null = null;

      if (isRecurring && visitorStats?.[inv.visitor_phone]?.last) {
        checkDate = new Date(visitorStats[inv.visitor_phone].last);
      } else {
        checkDate = inv.visitStartDate ? new Date(inv.visitStartDate) : null;
        if (!checkDate) return false;
      }

      const from = filter.fromDate ? new Date(filter.fromDate) : null;
      const to = filter.toDate ? new Date(filter.toDate) : null;

      if (checkDate) {
        checkDate.setHours(0, 0, 0, 0);
        if (from && checkDate.getTime() < from.getTime()) return false;
        if (to) {
          const toNormalized = new Date(to);
          toNormalized.setHours(23, 59, 59, 999);
          if (checkDate.getTime() > toNormalized.getTime()) return false;
        }
      }
    }

    return true;
  });
}