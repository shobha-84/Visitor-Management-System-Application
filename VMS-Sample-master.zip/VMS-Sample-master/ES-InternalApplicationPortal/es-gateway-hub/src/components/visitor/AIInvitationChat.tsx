import { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { extractInvitationFromText, ExtractedInvitation } from "@/services/aiService";
import { getOllamaUrl } from "@/services/aiService";
import { Sparkles, Send, Bot, Loader2, CheckCircle, XCircle, RefreshCw, Mic, MicOff } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { getApiBase } from "@/api/config";

interface AIInvitationChatProps {
  onApply: (data: ExtractedInvitation) => void;
}

type ChatEntry = {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
};

const PROMPT_SUGGESTIONS = [
  "John Doe from Tech Corp, meeting Monday 10 AM to 12 PM, Engineering",
  "Sarah Smith from ABC Ltd, tomorrow 2 PM to 4 PM, Finance dept",
  "Mike Johnson interview, 3 PM today, Human Resources",
];

function audioToWav(audioBlob: Blob): Promise<ArrayBuffer> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => {
      const arrayBuffer = reader.result as ArrayBuffer;
      const context = new AudioContext();
      context.decodeAudioData(arrayBuffer, (buffer) => {
        const numChannels = buffer.numberOfChannels;
        const sampleRate = buffer.sampleRate;
        const format = 1; // PCM
        const bitDepth = 16;
        const bytesPerSample = bitDepth / 8;
        const blockAlign = numChannels * bytesPerSample;
        const numSamples = buffer.length;
        const byteRate = sampleRate * blockAlign;
        const dataSize = numSamples * blockAlign;
        const headerSize = 44;
        const outBuffer = new ArrayBuffer(headerSize + dataSize);
        const view = new DataView(outBuffer);

        function writeString(offset: number, str: string) {
          for (let i = 0; i < str.length; i++) {
            view.setUint8(offset + i, str.charCodeAt(i));
          }
        }

        writeString(0, "RIFF");
        view.setUint32(4, 36 + dataSize, true);
        writeString(8, "WAVE");
        writeString(12, "fmt ");
        view.setUint32(16, 16, true);
        view.setUint16(20, format, true);
        view.setUint16(22, numChannels, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, byteRate, true);
        view.setUint16(32, blockAlign, true);
        view.setUint16(34, bitDepth, true);
        writeString(36, "data");
        view.setUint32(40, dataSize, true);

        const channels = [];
        for (let c = 0; c < numChannels; c++) {
          channels.push(buffer.getChannelData(c));
        }

        let offset = 44;
        for (let i = 0; i < numSamples; i++) {
          for (let c = 0; c < numChannels; c++) {
            const sample = Math.max(-1, Math.min(1, channels[c][i]));
            view.setInt16(offset, sample < 0 ? sample * 0x8000 : sample * 0x7FFF, true);
            offset += 2;
          }
        }

        resolve(outBuffer);
      }, reject);
    };
    reader.onerror = reject;
    reader.readAsArrayBuffer(audioBlob);
  });
}

async function transcribeWithOllama(audioBlob: Blob, retries = 3): Promise<string> {
  const wavBuffer = await audioToWav(audioBlob);
  const formData = new FormData();
  formData.append("audio", new Blob([wavBuffer], { type: "audio/wav" }), "recording.wav");

  const apiBase = getApiBase();
  
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const response = await fetch(`${apiBase}/api/transcription/vosk`, {
        method: "POST",
        body: formData,
      });

      if (!response.ok) {
        const errorText = await response.text();
        if (attempt === retries) {
          throw new Error(`Voice transcription failed: ${errorText}`);
        }
        await new Promise(r => setTimeout(r, 1000 * attempt));
        continue;
      }

      const data = await response.json();
      return data.text?.trim() || "";
    } catch (err: any) {
      if (attempt === retries) {
        throw err;
      }
      await new Promise(r => setTimeout(r, 1000 * attempt));
    }
  }
  
  throw new Error("Voice transcription failed after retries");
}

export function AIInvitationChat({ onApply }: AIInvitationChatProps) {
  const [messages, setMessages] = useState<ChatEntry[]>([]);
  const [input, setInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [lastExtracted, setLastExtracted] = useState<ExtractedInvitation | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isModelLoading, setIsModelLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const isProcessingRef = useRef(false);
  const lastInputRef = useRef("");
  const streamRef = useRef<MediaStream | null>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    if (messages.length === 0) {
      setMessages([{
        id: "welcome",
        role: "assistant",
        content: "Describe the visitor invitation in plain language. I'll extract the details for you.",
        timestamp: new Date(),
      }]);
    }
  }, []);

  useEffect(() => {
    isProcessingRef.current = isProcessing;
  }, [isProcessing]);

  useEffect(() => {
    lastInputRef.current = input;
  }, [input]);

  useEffect(() => {
    return () => {
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const handleSend = useCallback(async () => {
    const currentInput = lastInputRef.current;
    const trimmed = currentInput.trim();
    if (!trimmed || isProcessingRef.current) return;

    const userMsg: ChatEntry = {
      id: `user-${Date.now()}`,
      role: "user",
      content: trimmed,
      timestamp: new Date(),
    };

    setInput("");
    setMessages((prev) => [...prev, userMsg]);
    setIsProcessing(true);
    setError(null);
    setLastExtracted(null);

    const assistantMsgId = `assistant-${Date.now()}`;
    setMessages((prev) => [...prev, {
      id: assistantMsgId,
      role: "assistant",
      content: "",
      timestamp: new Date(),
      isStreaming: true,
    }]);

    try {
      const result = await extractInvitationFromText(trimmed);

      if (result.data) {
        setLastExtracted(result.data);
        setMessages((prev) => [
          ...prev.filter((m) => m.id !== assistantMsgId),
          {
            id: assistantMsgId,
            role: "assistant",
            content: "✅ Details extracted! Click 'Apply to Form' to fill the invitation fields.",
            timestamp: new Date(),
          },
        ]);
      } else {
        setError("Could not extract details. Please rephrase your request with clearer information (name, company, date, time, purpose).");
        setMessages((prev) => prev.filter((m) => m.id !== assistantMsgId));
      }
    } catch (err: any) {
      const errorMsg = err?.message || "Failed to connect to AI model";

      if (errorMsg.includes("Model loading failed") || errorMsg.includes("404")) {
        setIsModelLoading(true);
        setError("Loading model... please wait a moment.");
        try {
          const ollamaUrl = import.meta.env.VITE_OLLAMA_URL || "/ollama";
          await fetch(`${ollamaUrl}/api/pull`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ model: "llama3.2", stream: false }),
          });
          setIsModelLoading(false);
          setError("Model loaded! Try again.");
          setMessages((prev) => [
            ...prev.filter((m) => m.id === "welcome"),
            { id: `sys-${Date.now()}`, role: "assistant", content: "Ready! Try your request.", timestamp: new Date() },
          ]);
        } catch {
          setIsModelLoading(false);
          setError("Could not load model. Check Ollama is running.");
        }
      } else {
        setError(errorMsg);
      }
      setMessages((prev) => prev.filter((m) => m.id !== assistantMsgId));
    } finally {
      setIsProcessing(false);
    }
  }, []);

  const startListening = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const audioChunks: Blob[] = [];
      audioChunksRef.current = audioChunks;

      const mediaRecorder = new MediaRecorder(stream);

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunks.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: "audio/webm" });

        if (audioBlob.size < 1000) {
          setError("No audio recorded. Please try again.");
          stream.getTracks().forEach(track => track.stop());
          streamRef.current = null;
          setIsListening(false);
          return;
        }

        setIsTranscribing(true);
        setError(null);

        try {
          const transcript = await transcribeWithOllama(audioBlob);

          if (transcript) {
            setInput((prev) => (prev ? prev + " " + transcript : transcript));
          } else {
            setError("Could not understand the speech. Please try again.");
          }
        } catch (transcribeErr: any) {
          const msg = transcribeErr?.message || "Transcription failed";
          
          if (msg.includes("Vosk service unavailable") || msg.includes("502") || msg.includes("503")) {
            setError("Voice service is temporarily unavailable. Please try again in a moment or type your request manually.");
          } else if (msg.includes("Voice transcription failed")) {
            setError("Voice transcription failed. Please try speaking more clearly or type your request.");
          } else if (msg.includes("fetch") || msg.includes("network")) {
            setError("Cannot connect to voice service. Please check your connection and try again.");
          } else {
            setError(`Transcription error: ${msg}`);
          }
        } finally {
          setIsTranscribing(false);
          stream.getTracks().forEach(track => track.stop());
          streamRef.current = null;
          setIsListening(false);
        }
      };

      mediaRecorder.start();
      mediaRecorderRef.current = mediaRecorder;
      setIsListening(true);
      setError(null);
    } catch (err: any) {
      if (err.name === "NotAllowedError") {
        setError("Microphone access denied. Please allow microphone permissions.");
      } else if (err.name === "NotFoundError") {
        setError("No microphone found. Please connect a microphone.");
      } else {
        setError(`Could not access microphone: ${err?.message || "Unknown error"}`);
      }
    }
  }, []);

  const stopListening = useCallback(() => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsListening(false);
  }, []);

  const handleVoiceSubmit = useCallback(() => {
    const trimmed = input.trim();
    if (!trimmed || isProcessing) return;

    setInput("");
    handleSend();
  }, [input, isProcessing, handleSend]);

  const handleApply = () => {
    if (lastExtracted) onApply(lastExtracted);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
    inputRef.current?.focus();
  };

  return (
    <Card className="h-full flex flex-col" style={{ height: "calc(100vh - 240px)" }}>
      <CardHeader className="pb-2 px-4 py-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Sparkles className="w-4 h-4 text-purple-500" />
          AI Invitation Assistant
        </CardTitle>
      </CardHeader>
      <CardContent className="flex-1 flex flex-col gap-3 px-4 pb-4 min-h-0">
        {/* Suggestions - shown only on welcome screen */}
        {messages.length <= 1 && (
          <div className="space-y-2 mb-2">
            <p className="text-xs text-muted-foreground">Quick examples:</p>
            <div className="flex flex-col gap-1">
              {PROMPT_SUGGESTIONS.map((suggestion, i) => (
                <Button
                  key={i}
                  variant="outline"
                  size="sm"
                  onClick={() => handleSuggestionClick(suggestion)}
                  className="text-left text-xs h-auto py-1.5 px-3 justify-start"
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>
        )}

        {/* Chat Messages */}
        <div className="flex-1 overflow-y-auto space-y-3 border rounded-md p-3 bg-muted/20 min-h-0">
          {messages.map((msg) => (
            <div key={msg.id} className="flex gap-2">
              <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 text-xs font-bold ${
                msg.role === "user"
                  ? "bg-primary text-primary-foreground"
                  : "bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300"
              }`}>
                {msg.role === "user" ? "U" : "AI"}
              </div>
              <div className="flex-1 min-w-0">
                <div className={`text-sm rounded-md p-2 ${
                  msg.role === "user" ? "bg-primary/10" : "bg-background border"
                }`}>
                  <div className="whitespace-pre-wrap break-words">{msg.content}</div>
                </div>
              </div>
            </div>
          ))}
          <div ref={chatEndRef} />
        </div>

        {/* Error Message */}
        {error && (
          <div className={`flex items-start gap-2 text-xs p-2 rounded-md ${
            error.includes("Loading") || error.includes("ready") || error.includes("Try")
              ? "bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 text-yellow-800 dark:text-yellow-300"
              : "bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 text-red-800 dark:text-red-300"
          }`}>
            {error.includes("Loading") ? (
              <RefreshCw className={`w-3.5 h-3.5 mt-0.5 flex-shrink-0 ${isModelLoading ? "animate-spin" : ""}`} />
            ) : (
              <XCircle className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
            )}
            <span className="break-words">{error}</span>
          </div>
        )}

        {/* Transcribing Indicator */}
        {isTranscribing && (
          <div className="flex items-center gap-2 text-xs text-muted-foreground py-1">
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
            Transcribing audio...
          </div>
        )}

        {/* Apply Button */}
        {lastExtracted && (
          <Button onClick={handleApply} className="w-full bg-green-600 hover:bg-green-700 text-sm">
            <CheckCircle className="w-4 h-4 mr-2" />
            Apply to Form
          </Button>
        )}

        {/* Input Area */}
        <div className="flex gap-2 shrink-0">
          <Textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="e.g., John Doe, Tech Corp, Monday 10 AM, Engineering..."
            disabled={isProcessing}
            className="flex-1 resize-none text-sm"
            rows={2}
          />
          <Button
            onClick={isListening ? stopListening : startListening}
            disabled={isProcessing && !isListening}
            size="icon"
            className={`self-end shrink-0 ${isListening ? "bg-red-500 hover:bg-red-600 animate-pulse" : ""}`}
            title={isListening ? "Stop recording" : "Start voice input"}
          >
            {isListening ? <MicOff className="w-4 h-4 text-white" /> : <Mic className="w-4 h-4" />}
          </Button>
          <Button
            onClick={handleVoiceSubmit}
            disabled={!input.trim() || isProcessing}
            size="icon"
            className="self-end shrink-0"
          >
            {isProcessing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </div>

        {/* Status Badge */}
        <div className="flex items-center gap-2 text-xs text-muted-foreground shrink-0">
          <Badge variant="secondary" className="text-xs">llama3.2</Badge>
          <Badge variant="secondary" className={`text-xs ${isModelLoading ? "opacity-70" : ""}`}>
            {isModelLoading ? "Loading..." : "Ready"}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}
