import { useState, useEffect, useMemo } from "react";
import { useAuth } from "@/hooks/useAuth";
// import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { Edit, Eye, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import Swal from 'sweetalert2';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "../ui/input";
import { Label } from "@/components/ui/label";
import { InvitationDetailsContent } from "@/components/visitor/InvitationDetailsContent";
import { apiFetch } from "@/api/http";
import {
  InvitationFilters,
  filterInvitations,
  type InvitationFilter,
} from "./InvitationFilters";

interface Props {
  onEdit: (invitation: any) => void;
  filterType?: "mine" | "host" | "all";
  refreshKey?: number;
}

const STATUS_COLORS: Record<string, string> = {
  draft: "bg-gray-100 text-gray-800",
  pending: "bg-yellow-100 text-yellow-800",
  approved: "bg-green-100 text-green-800",
  rejected: "bg-red-100 text-red-800",
  cancelled: "bg-red-100 text-red-800",
  checked_in: "bg-blue-100 text-blue-800",
  checked_out: "bg-purple-100 text-purple-800",
};

export function MyInvitations({ onEdit, filterType = "mine", refreshKey }: Props) {
  const { user } = useAuth();
  const isSecurity = user?.role === "employee_security";
  const isAdmin = user?.role === "Admin";
  const [invitations, setInvitations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [selected, setSelected] = useState<any | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<any | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [openComplete, setOpenComplete] = useState<any | null>(null);
  const [openReschedule, setOpenReschedule] = useState<any | null>(null);
  const [meetingAttended, setMeetingAttended] = useState("yes");
  const [remarks, setRemarks] = useState("");
  const [visitorPopup, setVisitorPopup] = useState<any | null>(null);
  const [error, setError] = useState("");
  const [rescheduleForm, setRescheduleForm] = useState({
    visitStartDate: "",
    visitEndDate: "",
    visitStartTime: "",
    visitEndTime: ""
  });
  const [rescheduleError, setRescheduleError] = useState("");
  const [filter, setFilter] = useState<InvitationFilter>({
    fromDate: undefined,
    toDate: undefined,
    status: "all",
  });
  const [isRecurring, setIsRecurring] = useState(false);

  const STATUS_OPTIONS: { value: string; label: string }[] = [
    { value: "checked_in", label: "Checked In" },
    { value: "checked_out", label: "Checked Out" },
    { value: "cancelled", label: "Cancelled" },
  ];

  const fetchInvitations = async () => {
    if (!user) return;

    setLoading(true);
    try {
      // const {
      //   data: { session },
      // } = await supabase.auth.getSession();

      // const accessToken = session?.access_token;

      // if (!accessToken) {
      //   throw new Error("No access token");
      // }

      const data = await apiFetch("/api/visitor-invitations");

      let filteredData = data;

      if (filterType === "all") {
        filteredData = data;
      } else if (filterType === "host") {
        filteredData = data.filter(
          (inv: any) => inv.hostEmail === user?.email
        );
      } else if (filterType === "mine") {
        filteredData = data.filter((inv: any) => {
          const createdByEmail = (inv.createdBy ?? inv.created_by ?? "").toLowerCase();
          const hostEmail = (inv.hostEmail ?? "").toLowerCase();
          const userEmail = user?.email?.toLowerCase();

          return (
            createdByEmail === userEmail ||
            hostEmail === userEmail
          );
        });
      }

      // Security role: filter by visitor_type based on isRecurring
      if (isSecurity) {
        if (!isRecurring) {
          const today = new Date().toISOString().split("T")[0];
          filteredData = filteredData.filter((inv: any) => {
            if (!inv.visitStartDate) return false;
            if (inv.visitor_type === "Recurring") return false;
            // Handle both ISO (2026-10-07) and dd-MM-yyyy (07-10-2026) formats
            const datePart = inv.visitStartDate.split("T")[0];
            const normalizedDate = datePart.includes("-") && datePart.length === 10
              ? (datePart.startsWith("20") ? datePart : datePart.split("-").reverse().join("-"))
              : datePart;
            return normalizedDate === today;
          });
        } else {
          filteredData = filteredData.filter((inv: any) => inv.visitor_type === "Recurring");
        }
      }

      const sortedInvitations = [...filteredData].sort((a, b) => {
        const dateA = a.visitStartDate
          ? new Date(`${a.visitStartDate}T${a.visitStartTime || "00:00:00"}`).getTime()
          : 0;

        const dateB = b.visitStartDate
          ? new Date(`${b.visitStartDate}T${b.visitStartTime || "00:00:00"}`).getTime()
          : 0;

        return dateB - dateA;
      });

      setInvitations(sortedInvitations);
    } catch (err: any) {
      toast.error(err.message || "Failed to load invitations");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchInvitations();
    }
  }, [user, filterType, refreshKey, isRecurring]);

  const filteredInvitations = useMemo(() => {
    return filterInvitations(invitations, filter);
  }, [invitations, filter]);

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setDeleting(true);
    try {
      // const {
      //   data: { session },
      // } = await supabase.auth.getSession();

      // const accessToken = session?.access_token;
      // if (!accessToken) throw new Error("No access token");

      await apiFetch(`/api/visitor-invitations/${deleteTarget.id}`, {
        method: "DELETE",
      });

      // toast.success("Invitation deleted successfully");
      Swal.fire({
        title: 'Success',
        text: "Invitation deleted successfully",
        icon: 'success',
        confirmButtonText: 'OK'
      });
      setInvitations((prev) =>
        prev.filter((inv) => inv.id !== deleteTarget.id)
      );
    } catch (err: any) {
      // toast.error(err.message || "Failed to delete invitation");
      Swal.fire({
        title: 'Success',
        text: err.message || "Failed to delete invitation",
        icon: 'success',
        confirmButtonText: 'OK'
      });
    } finally {
      setDeleting(false);
      setDeleteTarget(null);
    }
  };



  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-6 h-6 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (invitations.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          {filterType === "all"
            ? "No invitations found."
            : "No invitations yet. Create your first visitor invitation."}
        </CardContent>
      </Card>
    );
  }

  const isReadOnly = filterType === "all";

  const handleComplete = async () => {
    if (!openComplete) return;

    try {
      // const {
      //   data: { session }
      // } = await supabase.auth.getSession();

      // if (!session?.access_token) {
      //   throw new Error("No access token");
      // }

      if (!remarks.trim()) {
        setError("Remarks is required");
        return;
      } else {
        setError("");
      }

      await apiFetch(`/api/visitor-invitations/${openComplete.id}/complete`, {
        method: "POST",
        body: JSON.stringify({
          remarks: remarks.trim(),
          visitorAttended: meetingAttended === "yes",
        }),
      });

      // toast.success("Meeting completed ✅");
      Swal.fire({
        title: 'Success',
        text: 'Meeting completed',
        icon: 'success',
        confirmButtonText: 'OK'
      });

      setRemarks("");            // ✅ clear input
      setOpenComplete(null);     // ✅ close dialog
      fetchInvitations();        // ✅ refresh list

    } catch (err: any) {
      toast.error(err.message || "Failed to complete meeting");
    }
  };

  const formatTime = (time: string) => {
    if (!time) return "";
    return time.length === 5 ? time + ":00" : time;
  };
  const handleRescheduleSave = async () => {
    if (!openReschedule) return;

    try {

      // ✅ CHECK IF NOTHING CHANGED
      const isUnchanged =
        rescheduleForm.visitStartDate === openReschedule.visitStartDate &&
        rescheduleForm.visitEndDate === openReschedule.visitEndDate &&
        rescheduleForm.visitStartTime === openReschedule.visitStartTime &&
        rescheduleForm.visitEndTime === openReschedule.visitEndTime;

      if (isUnchanged) {
        setRescheduleError("Please choose the new start date and end date");
        return;
      }

      // ✅ REQUIRED FIELD VALIDATION
      if (
        !rescheduleForm.visitStartDate ||
        !rescheduleForm.visitEndDate ||
        !rescheduleForm.visitStartTime ||
        !rescheduleForm.visitEndTime
      ) {
        setRescheduleError("All fields are required");
        return;
      }

      // ✅ DATE VALIDATION
      const start = new Date(rescheduleForm.visitStartDate);
      const end = new Date(rescheduleForm.visitEndDate);

      if (end < start) {
        setRescheduleError("End date must be greater than start date");
        return;
      }

      // ✅ ✅ ADD HERE → TIME VALIDATION

      // ✅ same day → end time must be after start
      if (
        rescheduleForm.visitStartDate === rescheduleForm.visitEndDate &&
        rescheduleForm.visitEndTime <= rescheduleForm.visitStartTime
      ) {
        setRescheduleError("End time must be after start time");
        return;
      }

      // ✅ today → block past start time
      const today = new Date().toISOString().split("T")[0];

      if (rescheduleForm.visitStartDate === today) {
        const now = new Date();
        const hh = String(now.getHours()).padStart(2, "0");
        const mm = String(now.getMinutes()).padStart(2, "0");

        const currentTime = `${hh}:${mm}`;

        if (rescheduleForm.visitStartTime < currentTime) {
          setRescheduleError("Start time cannot be in the past");
          return;
        }
      }

      // ✅ CLEAR ERROR BEFORE API CALL
      setRescheduleError("");

      // ✅ API CALL
      await apiFetch(`/api/visitor-invitations/${openReschedule.id}/reschedule`, {
        method: "POST",
        body: JSON.stringify({
          visitStartDate: rescheduleForm.visitStartDate,
          visitEndDate: rescheduleForm.visitEndDate,
          visitStartTime: formatTime(rescheduleForm.visitStartTime),
          visitEndTime: formatTime(rescheduleForm.visitEndTime),
        }),
      });

      // toast.success("Rescheduled successfully ✅");
      Swal.fire({
        title: 'Success',
        text: 'Rescheduled successfully ',
        icon: 'success',
        confirmButtonText: 'OK'
      });

      setOpenReschedule(null);
      fetchInvitations();

    } catch (err: any) {
      toast.error(err.message);
    }
  };

  const resetCheckInDialog = () => {
    setOpenReschedule(null);
  };


  const addOneHour = (time: string) => {
    const [hours, minutes] = time.split(":").map(Number);
    const date = new Date();
    date.setHours(hours);
    date.setMinutes(minutes);

    date.setHours(date.getHours() + 1);

    return date.toTimeString().slice(0, 5); // HH:mm
  };


  const getMinStartTime = () => {
    const today = new Date().toISOString().split("T")[0];

    if (rescheduleForm.visitStartDate !== today) return undefined;

    const now = new Date();
    const hh = String(now.getHours()).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");

    return `${hh}:${mm}`;
  };


  const today = new Date().toISOString().split("T")[0];
  return (
    <>
      <InvitationFilters
        filter={filter}
        onChange={setFilter}
        statusOptions={STATUS_OPTIONS}
        isRecurring={isSecurity ? isRecurring : false}
        onRecurringChange={isSecurity ? setIsRecurring : undefined}
      />
      <div className="grid gap-4">
        {filteredInvitations.map((inv) => (
          <Card key={inv.id}>
            <CardContent className="flex items-center justify-between py-4">
              <div className="space-y-1">
                <p className="font-medium">{inv.visitorName}  {inv.additionalVisitors?.length > 0 && (
                  <span
                    className="text-xs text-blue-500 font-normal cursor-pointer"
                    onClick={(e) => {
                      e.stopPropagation();
                      setVisitorPopup(inv);
                    }}
                  >
                    +{inv.additionalVisitors.length} visitors
                  </span>
                )}</p>
                <p className="text-sm text-gray-800">
                  {inv.visitorCompany ? `${inv.visitorCompany} · ` : ""}
                  {inv.purpose} · {inv.department}
                </p>
                <p className="text-xs text-gray-800">
                  {inv.visitStartDate
                    ? format(new Date(inv.visitStartDate), "dd-MM-yyyy")
                    : "—"}{" "}
                  {inv.visitStartTime
                    ? format(new Date(`1970-01-01T${inv.visitStartTime}`), "hh:mm a")
                    : "--"}{" "}
                  –{" "}
                  {inv.visitEndDate
                    ? format(new Date(inv.visitEndDate), "dd-MM-yyyy")
                    : "—"}{" "}
                  {inv.visitEndTime
                    ? format(new Date(`1970-01-01T${inv.visitEndTime}`), "hh:mm a")
                    : "--"}
                </p>


                {/* {inv.additionalVisitors?.length > 0 && (
                  <div className="mt-2 text-xs text-gray-500">
                    <p className="font-medium">Additional Visitors:</p>
                    {inv.additionalVisitors.map((v: any, i: number) => (
                      <div key={i}>
                        {v.name} - {v.email}
                      </div>
                    ))}
                  </div>
                )} */}
              </div>
              <div className="flex items-center gap-2">
                {inv.status?.toLowerCase() !== "approved" && inv.status !== "Pending" && (
                  <Badge className={STATUS_COLORS[inv.status] || ""}>
                    {
                      inv.hostRemarks && !inv.visitorAttended
                        ? "Not Attended"
                        : inv.visitorAttended
                          ? "Completed"
                          : (inv.status === "approved"
                            ? "New"
                            : inv.status)?.replace("_", " ")
                    }
                  </Badge>
                )}
                <Button variant="ghost" size="icon" onClick={() => setSelected(inv)} title="View details">
                  <Eye className="w-4 h-4" />
                </Button>
                {inv.hostEmail === user?.email && !isAdmin && (
                  <>
                    {inv.status === "checked_out" && !inv.meetingCompleted && (
                      <Button
                        // variant="outline"
                        size="sm"
                        onClick={() => setOpenComplete(inv)}
                      >
                        Update Meeting Status
                      </Button>
                    )}
                    {inv.hostEmail === user?.email &&
                      inv.status !== "checked_out" &&
                      inv.status !== "checked_in" &&
                      inv.visitEndDate &&
                      inv.visitEndDate < today && (
                        <Button
                          // variant="outline"
                          size="sm"
                          onClick={() => {
                            setOpenReschedule(inv);
                            setRescheduleForm({
                              visitStartDate: inv.visitStartDate || "",
                              visitEndDate: inv.visitEndDate || "",
                              visitStartTime: inv.visitStartTime || "",
                              visitEndTime: inv.visitEndTime || ""
                            });
                          }}
                        >
                          Reschedule Meeting
                        </Button>
                      )}
                  </>
                )}
                {!isReadOnly &&
                  (inv.status === "draft" || inv.status === "approved") &&
                  !(inv.visitEndDate < today) && (
                    <div className="flex items-center gap-1">

                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => onEdit(inv)}
                        title="Edit invitation"
                      >
                        <Edit className="w-4 h-4" />
                      </Button>

                      {/* Separator */}
                      {/* <span className="text-gray-800 items-center">|</span> */}
                      <div className="h-4 w-0.5 bg-gray-800"></div>

                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setDeleteTarget(inv)}
                        title="Delete invitation"
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>

                    </div>
                  )}
              </div>
            </CardContent>
          </Card>
        ))}
        {filteredInvitations.length === 0 && invitations.length > 0 && (
          <Card>
            <CardContent className="py-12 text-center text-muted-foreground">
              No invitations match the selected filters.
            </CardContent>
          </Card>
        )}
      </div>
      <Dialog open={!!openComplete}
        onOpenChange={(open) => {
          if (!open) {
            // ✅ Reset form when dialog is closed
            setOpenComplete(null);
            setRemarks("");
            setMeetingAttended("yes"); // reset to default
            setError("");
          }
        }}
      >
        <DialogContent className="gap-0 p-0 overflow-hidden [&>button]:text-black [&>button:hover]:text-red-500">
          <DialogHeader className="bg-muted border-b px-6 py-3">
            <DialogTitle>Update Meeting Status</DialogTitle>
          </DialogHeader>
          {openComplete && (
            <div className="space-y-4 px-6 pb-4 pt-3 text-sm">

              <div className="space-y-2">
                <Label>
                  Visitor Attended Meeting <span className="text-red-500">*</span>
                </Label>
                <div className="flex gap-4 items-center">
                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="meetingAttended"
                      value="yes"
                      checked={meetingAttended === "yes"}
                      onChange={(e) => setMeetingAttended(e.target.value)}
                    />
                    Yes
                  </label>

                  <label className="flex items-center gap-2">
                    <input
                      type="radio"
                      name="meetingAttended"
                      value="no"
                      checked={meetingAttended === "no"}
                      onChange={(e) => setMeetingAttended(e.target.value)}
                    />
                    No
                  </label>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="meeting-remarks">
                  Remarks <span className="text-red-500">*</span>
                </Label>
                <Input
                  id="meeting-remarks"
                  value={remarks}
                  onChange={(e) => {
                    setRemarks(e.target.value);

                    // ✅ Clear error when user starts typing
                    if (error) {
                      setError("");
                    }
                  }}
                  placeholder="Enter remarks"
                  maxLength={50}
                />
                {error && (
                  <p className="text-red-500 text-xs mt-1">
                    {error}
                  </p>
                )}
              </div>
              <div className="flex justify-end gap-4 pt-2">
                <Button
                  variant="outline"
                  disabled={loading}
                  onClick={() => {
                    setOpenComplete(null);   // ✅ close dialog
                    setRemarks("");          // ✅ clear input
                    setMeetingAttended("yes"); // ✅ reset radio
                    setError("");            // ✅ clear error
                  }}

                >
                  Cancel
                </Button>
                <Button
                  // variant="outline"
                  disabled={loading}
                  onClick={handleComplete}   // ✅ IMPORTANT
                >
                  Save
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={!!openReschedule}

        onOpenChange={(open) => {
          if (!open) {
            setOpenReschedule(null);
            setRescheduleError(""); // ✅ reset error
          }
        }}
      >
        <DialogContent className="gap-0 p-0 overflow-hidden [&>button]:text-black [&>button:hover]:text-red-500">
          <DialogHeader className="bg-muted border-b px-6 py-3">
            <DialogTitle>Reschedule Meeting</DialogTitle>
          </DialogHeader>
          {openReschedule && (
            <div className="space-y-4 px-6 pb-4 pt-3 text-sm">
              <div className="space-y-2">
                <Label htmlFor="visit_start_date">Start Date <span className="text-red-500">*</span></Label>
                <Input
                  type="date"
                  value={rescheduleForm.visitStartDate}
                  min={new Date().toISOString().split("T")[0]}

                  onChange={(e) => {
                    setRescheduleForm(prev => ({
                      ...prev,
                      visitStartDate: e.target.value
                    }));
                    setRescheduleError(""); // ✅ clear error
                  }
                  }
                />

              </div>
              <div className="space-y-2">
                <Label htmlFor="visit_end_date">End Date <span className="text-red-500">*</span></Label>
                <Input
                  type="date"
                  value={rescheduleForm.visitEndDate}
                  min={rescheduleForm.visitStartDate}
                  onChange={(e) =>
                    setRescheduleForm(prev => ({
                      ...prev,
                      visitEndDate: e.target.value
                    }))
                  }
                />
                {/* {errors.visit_end_date && (
                  <p className="text-sm text-red-500">{errors.visit_end_date}</p>
                )} */}
              </div>
              <div className="space-y-2">
                <Label htmlFor="visit_start_time">Start Time <span className="text-red-500">*</span></Label>
                <Input
                  type="time"
                  value={rescheduleForm.visitStartTime}
                  min={getMinStartTime()}   // ✅ prevent past time in UI
                  onChange={(e) => {
                    const value = e.target.value;

                    setRescheduleForm(prev => ({
                      ...prev,
                      visitStartTime: value
                    }));

                    const today = new Date().toISOString().split("T")[0];

                    // ✅ VALIDATION (no blocking — only error)
                    if (rescheduleForm.visitStartDate === today) {
                      const now = new Date();
                      const hh = String(now.getHours()).padStart(2, "0");
                      const mm = String(now.getMinutes()).padStart(2, "0");
                      const currentTime = `${hh}:${mm}`;

                      if (value < currentTime) {
                        setRescheduleError("Start time cannot be in the past");
                        return;
                      }
                    }

                    // ✅ clear error
                    setRescheduleError("");
                  }}
                />
                {/* {errors.visit_start_time && (
                  <p className="text-sm text-red-500">{errors.visit_start_time}</p>
                )} */}
              </div>
              <div className="space-y-2">
                <Label htmlFor="visit_end_time">End Time <span className="text-red-500">*</span></Label>
                <Input
                  type="time"
                  value={rescheduleForm.visitEndTime}
                  min={
                    rescheduleForm.visitStartDate === rescheduleForm.visitEndDate
                      ? rescheduleForm.visitStartTime
                      : undefined
                  }
                  onChange={(e) => {
                    const value = e.target.value;

                    setRescheduleForm(prev => ({
                      ...prev,
                      visitEndTime: value
                    }));

                    // ✅ Same-day validation
                    if (
                      rescheduleForm.visitStartDate === rescheduleForm.visitEndDate &&
                      rescheduleForm.visitStartTime &&
                      value <= rescheduleForm.visitStartTime
                    ) {
                      setRescheduleError("End time must be after start time");
                      return;
                    }

                    // ✅ clear error
                    setRescheduleError("");
                  }}
                />
                {/* {errors.visit_end_time && (
                  <p className="text-sm text-red-500">{errors.visit_end_time}</p>
                )} */}
                {rescheduleError && (
                  <p className="text-red-500 text-sm">
                    {rescheduleError}
                  </p>
                )}
              </div>
              <div className="flex justify-end gap-4 pt-2">
                <Button
                  variant="outline" onClick={resetCheckInDialog}>Cancel</Button>
                <Button
                  disabled={loading}
                  onClick={handleRescheduleSave}
                >
                  Save
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="gap-0 p-0 overflow-hidden [&>button]:text-black [&>button:hover]:text-red-500">
          <DialogHeader className="bg-muted border-b px-6 py-3">
            <DialogTitle>Invitation Details</DialogTitle>
          </DialogHeader>
          {selected && <InvitationDetailsContent invitation={selected} />}
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteTarget} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent className="gap-0 p-0 overflow-hidden">
          <AlertDialogCancel
            disabled={deleting}
            className="absolute right-4 top-4 
    text-black hover:text-red-600 
    rounded-sm opacity-70 hover:opacity-100 
    transition-all 
    focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 
    disabled:pointer-events-none 
    border-0 bg-transparent p-0 h-auto mt-0 hover:bg-transparent shadow-none"
          >

            <X className="h-4 w-4" />
            <span className="sr-only">Close</span>
          </AlertDialogCancel>
          <AlertDialogHeader className="bg-muted border-b px-6 py-3">
            <AlertDialogTitle>Delete Invitation</AlertDialogTitle>
          </AlertDialogHeader>
          <div className="px-6 pt-3 pb-4">
            <AlertDialogDescription className="text-sm text-foreground">
              Are you sure you want to delete the invitation for <strong>{deleteTarget?.visitorName}</strong>? This action cannot be undone.
            </AlertDialogDescription>
          </div>
          <AlertDialogFooter className="gap-4 px-6 pb-4 pt-0 sm:justify-end">
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} disabled={deleting}>
              {deleting ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <Dialog open={!!visitorPopup} onOpenChange={() => setVisitorPopup(null)}>
        <DialogContent className="gap-0 p-0 overflow-hidden [&>button]:text-black [&>button:hover]:text-red-500">
          <DialogHeader className="bg-muted border-b px-6 py-3">
            <DialogTitle>Visitor Details</DialogTitle>
          </DialogHeader>

          {visitorPopup && (
            <div className="px-6 pb-4 pt-3">
              <table className="w-full text-sm border">
                <thead>
                  <tr className="bg-gray-100 text-left">
                    <th className="p-2 border">Name</th>
                    <th className="p-2 border">Email</th>
                    <th className="p-2 border">Phone</th>
                    <th className="p-2 border">Company</th>
                  </tr>
                </thead>

                <tbody>
                  {/* ✅ MAIN VISITOR */}
                  <tr className="bg-gray-50 font-medium">
                    <td className="p-2 border">{visitorPopup.visitorName}</td>
                    <td className="p-2 border">{visitorPopup.visitorEmail}</td>
                    <td className="p-2 border">{visitorPopup.visitorPhone}</td>
                    <td className="p-2 border">{visitorPopup.visitorCompany}</td>
                  </tr>

                  {/* ✅ ADDITIONAL VISITORS */}
                  {visitorPopup.additionalVisitors?.map((v: any) => (
                    <tr key={v.id}>
                      <td className="p-2 border">{v.name}</td>
                      <td className="p-2 border">{v.email}</td>
                      <td className="p-2 border">{v.phone}</td>
                      <td className="p-2 border">{v.company}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
