type Props = {
  photoUrl?: string | null;
  name: string;
};

const API_BASE = import.meta.env.VITE_API_URL;

export default function VisitorPhoto({ photoUrl, name }: Props) {
  const fullPhotoUrl = photoUrl
    ? `${API_BASE}/${photoUrl}`
    : null;
  return (
    <div className="w-12 h-12 rounded-full bg-gray-200 overflow-hidden flex items-center justify-center">
      {fullPhotoUrl ? (
        <img
          src={fullPhotoUrl}
          alt={name}
          className="w-full h-full object-cover"
          onError={(e) => {
            // fallback if image cannot load
            (e.currentTarget as HTMLImageElement).style.display = "none";
          }}
        />
      ) : (
        <span className="text-sm font-medium text-gray-600">
          {name.charAt(0).toUpperCase()}
        </span>
      )}
    </div>
  );
}
