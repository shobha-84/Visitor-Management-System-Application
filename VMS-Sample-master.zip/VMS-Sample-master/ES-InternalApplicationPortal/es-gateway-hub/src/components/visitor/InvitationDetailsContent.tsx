import { type ReactNode } from "react";
import { format } from "date-fns";
import { Separator } from "@/components/ui/separator";

function DetailField({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="space-y-1">
      <dt className="text-xs font-medium text-muted-foreground">{label}</dt>
      <dd className="text-sm font-medium text-foreground break-words">{value ?? "—"}</dd>
    </div>
  );
}

function DetailSection({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="space-y-3">
      <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
        {title}
      </h4>
      <dl className="grid grid-cols-1 gap-4 sm:grid-cols-2">{children}</dl>
    </section>
  );
}

const formatDisplayDate = (date?: string) => {
  if (!date) return "—";
  try {
    return format(new Date(date), "dd MMM yyyy");
  } catch {
    return date;
  }
};

const formatDisplayTime = (time?: string) => {
  if (!time) return "—";
  try {
    return format(new Date(`1970-01-01T${time}`), "hh:mm a");
  } catch {
    return time;
  }
};

export function InvitationDetailsContent({ invitation }: { invitation: any }) {
  return (
    <div className="max-h-[min(70vh,520px)] overflow-y-auto px-6 pb-4 pt-3 text-sm">
      <div className="space-y-5">
        <DetailSection title="Visitor">
          <DetailField label="Name" value={invitation.visitorName} />
          <DetailField label="Company" value={invitation.visitorCompany || "—"} />
          <DetailField label="Email" value={invitation.visitorEmail || "—"} />
          <DetailField label="Phone" value={invitation.visitorPhone || "—"} />
        </DetailSection>

        {invitation.additionalVisitors?.length > 0 && (
          <>
            <Separator />
            <section className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                Additional Visitors
              </h4>
              <div className="overflow-hidden rounded-md border">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-muted/50 text-left">
                      <th className="px-3 py-2 font-medium text-muted-foreground">Name</th>
                      <th className="px-3 py-2 font-medium text-muted-foreground">Email</th>
                      <th className="px-3 py-2 font-medium text-muted-foreground">Phone</th>
                      <th className="px-3 py-2 font-medium text-muted-foreground">Company</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {invitation.additionalVisitors.map((visitor: any, index: number) => (
                      <tr key={visitor.id ?? index}>
                        <td className="px-3 py-2 font-medium">{visitor.name || "—"}</td>
                        <td className="px-3 py-2">{visitor.email || "—"}</td>
                        <td className="px-3 py-2">{visitor.phone || "—"}</td>
                        <td className="px-3 py-2">{visitor.company || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </>
        )}

        <Separator />

        <DetailSection title="Visit">
          <DetailField label="Purpose" value={invitation.purpose} />
          {invitation.purpose_others && (
            <DetailField label="Purpose Remarks" value={invitation.purpose_others} />
          )}
          <DetailField label="Department" value={invitation.department} />
          <DetailField
            label="Dates"
            value={`${formatDisplayDate(invitation.visitStartDate)} – ${formatDisplayDate(invitation.visitEndDate)}`}
          />
          <DetailField
            label="Time"
            value={`${formatDisplayTime(invitation.visitStartTime)} – ${formatDisplayTime(invitation.visitEndTime)}`}
          />
          <DetailField label="Visitor Type" value={invitation.visitorType} />
          <DetailField label="Status" value={invitation.status?.replace(/_/g, " ")} />
        </DetailSection>

        <Separator />

        <DetailSection title="Host">
          <DetailField label="Host Name" value={invitation.hostName} />
          <DetailField label="Host Email" value={invitation.hostEmail} />
        </DetailSection>

        {(invitation.remarks || invitation.additionalRequirements || invitation.rejectionReason || invitation.cancellationReason) && (
          <>
            <Separator />
            <DetailSection title="Notes">
              {invitation.remarks && (
                <DetailField
                  label="Additional Remarks"
                  value={invitation.remarks}
                />
              )}
              {invitation.additionalRequirements && (
                <DetailField
                  label="Requirements"
                  value={invitation.additionalRequirements}
                />
              )}
              {invitation.rejectionReason && (
                <DetailField
                  label="Rejection Reason"
                  value={invitation.rejectionReason}
                />
              )}
              {invitation.cancellationReason && (
                <DetailField
                  label="Cancellation Reason"
                  value={invitation.cancellationReason}
                />
              )}
            </DetailSection>
          </>
        )}
      </div>
    </div>
  );
}
