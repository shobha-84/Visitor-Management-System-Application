import { useEffect, useState } from "react";
import { apiFetch } from "@/api/http";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import VisitorPhoto from "./VisitorPhoto";

interface Props {
  onView: (invitation: any) => void;
}

export function ApprovalQueue({ onView }: Props) {
  const [pendingInvitations, setPendingInvitations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const normalizeInvitation = (inv: any) => ({
    ...inv,
    id: inv.id ?? inv.invitationId,
    visitor_name: inv.visitor_name ?? inv.visitorName,
    visitor_photo_url: inv.visitor_photo_url ?? inv.visitorPhotoUrl,
    department: inv.department,
    purpose: inv.purpose,
    visit_start_date: inv.visit_start_date ?? inv.visitStartDate,
    visit_end_date: inv.visit_end_date ?? inv.visitEndDate,
    visit_start_time: inv.visit_start_time ?? inv.visitStartTime,
    visit_end_time: inv.visit_end_time ?? inv.visitEndTime,
  });

  const fetchData = async () => {
    try {
      const res = await apiFetch("/api/visitor-invitations?status=pending");
      const list = Array.isArray(res) ? res : [];
      setPendingInvitations(list.map(normalizeInvitation));
    } catch (err: any) {
      toast.error(err.message || "Failed to load approvals");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  if (loading) {
    return <p className="text-muted-foreground">Loading…</p>;
  }

  return (
    <div className="space-y-4">
      {pendingInvitations.length === 0 && (
        <Card>
          <CardContent className="py-6 text-center text-muted-foreground">
            No pending approvals
          </CardContent>
        </Card>
      )}

      {pendingInvitations.map((inv) => (
        <Card key={inv.id}>
          <CardContent className="py-4 flex justify-between items-center">
            <div className="flex gap-4 flex-1">
              <VisitorPhoto
                photoUrl={inv.visitor_photo_url}
                name={inv.visitor_name}
              />

              <div>
                <h3 className="font-semibold">{inv.visitor_name}</h3>
                <p className="text-sm text-muted-foreground">
                  {inv.department} · {inv.purpose}
                </p>
                <p className="text-xs text-muted-foreground">
                  {inv.visit_start_date} to {inv.visit_end_date} ·{" "}
                  {inv.visit_start_time} – {inv.visit_end_time}
                </p>
              </div>
            </div>

            <Button size="sm" onClick={() => onView(inv)}>
              View
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
