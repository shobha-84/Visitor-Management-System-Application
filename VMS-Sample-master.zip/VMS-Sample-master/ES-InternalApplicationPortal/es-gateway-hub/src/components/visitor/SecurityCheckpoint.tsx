import { useEffect, useState, useRef, useCallback, useMemo } from "react";
import { useAuth } from "@/hooks/useAuth";
// import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { VisitorManagerDialog } from "./VisitorManagerDialog";
import { InvitationDetailsContent } from "./InvitationDetailsContent";
import { format, startOfMonth } from "date-fns";
import Swal from 'sweetalert2';
import {
  LogIn,
  LogOut,
  Camera,
  Upload,
  Video,
  VideoOff,
  Eye,
  Edit,
  XCircle,
} from "lucide-react";
import { toast } from "sonner";
import VisitorPhoto from "./VisitorPhoto"; // ✅ FIXED
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogDescription,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  InvitationFilters,
  filterInvitations,
  type InvitationFilter,
} from "./InvitationFilters";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const API_BASE = import.meta.env.VITE_API_URL;
export function SecurityCheckpoint({ onEdit }: { onEdit?: (inv: any) => void }) {
  const { user } = useAuth();
  const [invitations, setInvitations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [photoDialogId, setPhotoDialogId] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [filter, setFilter] = useState<InvitationFilter>({ fromDate: startOfMonth(new Date()), toDate: new Date(), status: 'all' });
  const [isRecurring, setIsRecurring] = useState(false);
  const [dialogInvId, setDialogInvId] = useState(null);
  const [selectedVisitors, setSelectedVisitors] = useState([]);

  const [selected, setSelected] = useState<any | null>(null);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelTarget, setCancelTarget] = useState<any | null>(null);
  const [cancelReason, setCancelReason] = useState("");
  const [canceling, setCanceling] = useState(false);

  const [activeVisitorPanel, setActiveVisitorPanel] = useState<string | null>(null);

  const [mainVisitor, setMainVisitor] = useState<any | null>(null);

  const [newVisitor, setNewVisitor] = useState({
    name: "",
    email: "",
    phone: "",
    company: ""
  });

  const [visitorPopup, setVisitorPopup] = useState<any | null>(null);

  //Recurring
  const [showRecurring, setShowRecurring] = useState(false);
  const [visitorStates, setVisitorStates] = useState<{ [key: string]: string }>({});
  const [visitorStats, setVisitorStats] = useState<{ [key: string]: any }>({});
  const [phoneSearch, setPhoneSearch] = useState("");
  const [checkInMode, setCheckInMode] = useState<"normal" | "recurring">("normal");

  const SEC_STATUS_OPTIONS = useMemo(() => {
    if (showRecurring) {
      return [
        { value: 'checked_in', label: 'Checked In' },
        { value: 'checked_out', label: 'Checked Out' },
      ];
    }
    return [
      { value: 'checked_in', label: 'Checked In' },
      { value: 'checked_out', label: 'Checked Out' },
      { value: 'cancelled', label: 'Cancelled' },
    ];
  }, [showRecurring]);

  // Webcam state
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [laptopDialogId, setLaptopDialogId] = useState<string | null>(null);

  // Camera selection state
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>("");
  const [isEnumeratingDevices, setIsEnumeratingDevices] = useState(false);

  const [badgeNumber, setBadgeNumber] = useState('');
  const [hasLaptop, setHasLaptop] = useState(false);
  const [isCheckInDisabled, setIsCheckInDisabled] = useState(false);

  const [laptopName, setLaptopName] = useState('');
  const [macAddress, setMacAddress] = useState('');
  const [todayBadges, setTodayBadges] = useState<string[]>([]);
  const [errors, setErrors] = useState<{
    badgeNumber?: string;
    laptopName?: string;
    macAddress?: string;
  }>({});

  const IDENTITY_PROOF_OPTIONS = [
    "PAN Card",
    "Passport",
    "Voter ID",
    "Driving License",
    "Employee ID",
  ];

  const [identityProofType, setIdentityProofType] = useState("");
  const [isDocumentVerified, setIsDocumentVerified] = useState(false);
  const [verificationErrors, setVerificationErrors] = useState<Record<string, string>>({});


  const filtered = useMemo(() => {
    let result = filterInvitations(invitations, filter, visitorStates, visitorStats);

    // ✅ Date filter: when isRecurring is false, show only today's records
    if (!isRecurring) {
      const today = new Date().toISOString().split("T")[0];
      result = result.filter((inv: any) => {
        if (!inv.visitStartDate) return false;
        const datePart = inv.visitStartDate.split("T")[0];
        const normalizedDate = datePart.includes("-") && datePart.length === 10
          ? (datePart.startsWith("20") ? datePart : datePart.split("-").reverse().join("-"))
          : datePart;
        return normalizedDate === today;
      });
    }

    // ✅ Step 1: show recurring only when toggle ON, otherwise non-recurring only
    if (showRecurring) {
      result = result.filter(
        (inv) => inv.visitor_type === "Recurring"
      );
    } else {
      result = result.filter(
        (inv) => inv.visitor_type !== "Recurring"
      );
    }

    // ✅ Step 2: apply phone search
    if (showRecurring && phoneSearch.trim()) {
      result = result.filter((inv) =>
        (inv.visitor_phone || "").includes(phoneSearch.trim())
      );
    }

    // ✅ Step 3: sort recurring by phone
    if (showRecurring) {
      result = [...result].sort((a, b) =>
        (a.visitor_phone || "").localeCompare(b.visitor_phone || "")
      );
    }

    return result;
  }, [invitations, filter, showRecurring, phoneSearch, visitorStates, isRecurring]);

  const formatDateTime = (value) => {
    if (!value) return "-";
    return new Date(value).toLocaleString("en-IN", {
      dateStyle: "medium",
      timeStyle: "short",
    });
  };


  const formatTime = (value) => {
    if (!value) return "-";

    const [hours, minutes] = value.split(":");

    return new Date(0, 0, 0, hours, minutes).toLocaleTimeString("en-IN", {
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const [now, setNow] = useState(() => new Date());

  useEffect(() => {
    const interval = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(interval);
  }, []);

  // Enumerate cameras when photo dialog opens
  useEffect(() => {
    if (photoDialogId && videoDevices.length === 0) {
      enumerateCameras();
    }
  }, [photoDialogId, videoDevices.length]);

  const hasVisitStartTimeReached = (inv: any): boolean => {
    if (inv.visitor_type === "Recurring") return true;
    if (!inv.visitStartDate) return true;

    const time = inv.visitStartTime || "00:00:00";
    const normalizedTime = time.length === 5 ? `${time}:00` : time;
    const start = new Date(`${inv.visitStartDate}T${normalizedTime}`);

    return now.getTime() >= start.getTime();
  };

  const openLaptopDialog = (id) => {

    setBadgeNumber("");
    setHasLaptop(false);
    setLaptopName("");
    setMacAddress("");
    setErrors({});
    setIsCheckInDisabled(false);
    setCapturedImage(null);
    setStream(null);
    setIdentityProofType("");
    setIsDocumentVerified(false);
    setVerificationErrors({});

    setLaptopDialogId(id);
  };

  const haslaptopfun = () => {
    setHasLaptop(prev => !prev); // ✅ toggle   
    setIsCheckInDisabled(false);
  }

  const fetchData = async () => {
    if (!user) return;

    setLoading(true);

    try {
      //✅ Get access token (Supabase auth only)
      // const {
      //   data: { session },
      // } = await supabase.auth.getSession();

      // const accessToken = session?.access_token;
      // if (!accessToken) throw new Error("No access token");

      // ✅ Call backend API
      const res = await fetch(
        `${API_BASE}/api/visitor-invitations?status=approved,pending,checked_in,checked_out,cancelled`,
        {
          headers: {
            // Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        });
      if (!res.ok) {
        throw new Error("Failed to load invitations");
      }
      const data = await res.json();
      // ✅ Sort by visit_start_date (frontend side)
      const normalized = data.map((inv) => ({
        ...inv,
        visitor_type: inv.visitorType, // ✅ FIX MAPPING HERE
        visitor_phone: inv.visitorPhone, // ✅ consistency
      }));

      const sortedData = [...normalized].sort((a, b) => {
        const dateA = new Date(
          `${a.visitStartDate}T${a.visitStartTime || "00:00:00"}`
        );
        const dateB = new Date(
          `${b.visitStartDate}T${b.visitStartTime || "00:00:00"}`
        );

        return dateB.getTime() - dateA.getTime();
      });

      const stateMap: any = {};
      const statsMap: any = {};

      for (const inv of sortedData) {
        if (!inv.visitor_phone) continue;

        const result = await fetchVisitorState(inv.visitor_phone);

        stateMap[inv.visitor_phone] = result.state;
        statsMap[inv.visitor_phone] = result;
      }
      setVisitorStates(stateMap);
      setVisitorStats(statsMap);
      setInvitations(sortedData);
      // const grouped = groupRecurringVisitors(sortedData);
      // setRecurringVisitors(grouped);
    } catch (err) {
      console.error("Error fetching invitations:", err);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData();
  }, [showRecurring]);
  const resetCheckInDialog = () => {
    setLaptopDialogId(null);
    setBadgeNumber("");
    setHasLaptop(false);
    setLaptopName("");
    setMacAddress("");
    setErrors({});
    setCheckInMode("normal");
    setIdentityProofType("");
    setIsDocumentVerified(false);
    setVerificationErrors({});
  };


  useEffect(() => {
    fetchData();
    setIsCheckInDisabled(false);
  }, []);

  useEffect(() => {
    if (laptopDialogId) {
      fetchTodayBadges();
    }
  }, [laptopDialogId])

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  }, [stream]);

  const enumerateCameras = useCallback(async () => {
    try {
      setIsEnumeratingDevices(true);
      // Request permission first to get device labels
      const tempStream = await navigator.mediaDevices.getUserMedia({ video: true });
      tempStream.getTracks().forEach(track => track.stop());
      
      const devices = await navigator.mediaDevices.enumerateDevices();
      const cameras = devices.filter(d => d.kind === 'videoinput');
      setVideoDevices(cameras);
      
      // Auto-select first camera if none selected
      if (cameras.length > 0 && !selectedDeviceId) {
        setSelectedDeviceId(cameras[0].deviceId);
      }
    } catch (err) {
      console.error("Failed to enumerate cameras:", err);
      toast.error("Could not access camera list. Please allow camera permissions.");
    } finally {
      setIsEnumeratingDevices(false);
    }
  }, [selectedDeviceId]);

  const startCamera = async () => {
    try {
      setCapturedImage(null);
      // Enumerate cameras if not done yet
      if (videoDevices.length === 0) {
        await enumerateCameras();
      }
      
      const constraints: MediaStreamConstraints = {
        video: {
          deviceId: selectedDeviceId ? { exact: selectedDeviceId } : undefined,
          width: { ideal: 640 },
          height: { ideal: 480 },
        },
      };
      
      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch {
      toast.error("Could not access camera. Please allow camera permissions.");
    }
  };
  const hasVisitEnded = (inv: any): boolean => {
    if (inv.visitor_type === "Recurring") return false; // ✅ allow recurring always
    if (!inv.visitEndDate) return false;

    const today = new Date();
    const endDate = new Date(inv.visitEndDate);

    // ✅ Remove time part (important)
    today.setHours(0, 0, 0, 0);
    endDate.setHours(0, 0, 0, 0);

    return today.getTime() > endDate.getTime(); // ✅ only compare date
  };

  const capturePhoto = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0);
    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    setCapturedImage(dataUrl);
    stopCamera();
  };

  const retakePhoto = () => {
    setCapturedImage(null);
    startCamera();
  };

  const uploadBlob = async (blob: Blob, invitationId: string) => {
    if (uploading) return;
    if (!blob || !invitationId) return;

    const timezoneId = Intl.DateTimeFormat().resolvedOptions().timeZone;
    setUploading(true);

    try {
      // const {
      //   data: { session },
      // } = await supabase.auth.getSession();

      // const accessToken = session?.access_token;
      // if (!accessToken) throw new Error("No access token");

      const formData = new FormData();
      formData.append("photo", blob, "visitor.jpg");

      const inv = invitations.find(i => i.id === invitationId);
      if (!inv || !inv.visitor_phone) {
        throw new Error("Visitor data missing");
      }

      const visitorState = visitorStates[inv.visitor_phone];
      const isFirstVisit =
        !visitorStats[inv.visitor_phone] ||
        visitorStats[inv.visitor_phone].count === 0;


      // =========================
      // ✅ FIRST VISIT ONLY
      // =========================
      // if (isFirstVisit) {

      //   // ✅ Visitor photo
      //   const visitorPhotoRes = await fetch(
      //     `${API_BASE}/api/visitor-invitations/${invitationId}/photo`,
      //     {
      //       method: "POST",
      //       headers: { Authorization: `Bearer ${accessToken}` },
      //       body: formData,
      //     }
      //   );

      //   if (!visitorPhotoRes.ok) {
      //     throw new Error(await visitorPhotoRes.text());
      //   }

      //   // ✅ Visitor check-in
      //   const visitorCheckRes = await fetch(
      //     `${API_BASE}/api/visitor-invitations/${invitationId}/check-in`,
      //     {
      //       method: "POST",
      //       headers: {
      //         Authorization: `Bearer ${accessToken}`,
      //         "Content-Type": "application/json",
      //       },
      //       body: JSON.stringify({
      //         badgeNumber,
      //         hasLaptop,
      //         laptopName,
      //         macAddress,
      //       }),
      //     }
      //   );

      //   if (!visitorCheckRes.ok) {
      //     throw new Error(await visitorCheckRes.text());
      //   }
      // }


      // =========================
      // ✅ ALWAYS DO RECURRING
      // =========================
      if (inv.visitor_type === "Recurring") {

        // ✅ STEP 1 — PHOTO FIRST (CRITICAL)
        const recurringPhotoRes = await fetch(
          `${API_BASE}/api/recurring/${invitationId}/photo`,
          {
            method: "POST",
            // headers: { Authorization: `Bearer ${accessToken}` },
            body: formData,
          }
        );

        if (!recurringPhotoRes.ok) {
          throw new Error(await recurringPhotoRes.text());
        }

        // ✅ STEP 2 — THEN CHECK-IN (updates log)
        const recurringCheckRes = await fetch(
          `${API_BASE}/api/recurring/${invitationId}/check-in`,
          {
            method: "POST",
            headers: {
              // Authorization: `Bearer ${accessToken}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              badgeNumber,
              hasLaptop,
              laptopName,
              macAddress,
              timezoneId,
              IdentityProofType: identityProofType,
              IsDocumentVerified: isDocumentVerified,
              VerifiedBy: user?.email || "security",
            }),
          }
        );

        if (!recurringCheckRes.ok) {
          const msg = await recurringCheckRes.text();

          // ✅ Ignore only duplicate safe case
          if (!msg.toLowerCase().includes("photo not uploaded")) {
            throw new Error(msg);
          }
        }
      } else {
        if (inv.visitor_type !== "Recurring") {
          // ✅ STEP 1 — Upload photo
          const photoRes = await fetch(
            `${API_BASE}/api/visitor-invitations/${invitationId}/photo`,
            {
              method: "POST",
              // headers: { Authorization: `Bearer ${accessToken}` },
              body: formData,
            }
          );
          if (!photoRes.ok) {
            throw new Error(await photoRes.text());
          }
          // ✅ STEP 2 — Check-in
          const checkRes = await fetch(
            `${API_BASE}/api/visitor-invitations/${invitationId}/check-in`,
            {
              method: "POST",
              headers: {
                // Authorization: `Bearer ${accessToken}`,
                "Content-Type": "application/json",
              },
              body: JSON.stringify({
                badgeNumber,
                hasLaptop,
                LaptopName: hasLaptop ? laptopName : null,
                MacAddress: hasLaptop ? macAddress : null,
                timezoneId,
                IdentityProofType: identityProofType,
                IsDocumentVerified: isDocumentVerified,
                VerifiedBy: user?.email || "security",
              }),
            }
          );
          if (!checkRes.ok) {
            throw new Error(await checkRes.text());
          }
        }
      }

      // ✅ CLEANUP
      setLaptopDialogId(null);
      setBadgeNumber("");
      setLaptopName("");
      setMacAddress("");
      setHasLaptop(false);

      // toast.success("Check-in successful ✅");
      Swal.fire({
        title: 'Success',
        text: 'Check-in successful ',
        icon: 'success',
        confirmButtonText: 'OK'
      });
      setIsCheckInDisabled(false);
      closeDialog();

      setTimeout(() => {
        fetchData();
      }, 300);

    } catch (err: any) {
      toast.error(err.message || "Check-in failed");
    } finally {
      setUploading(false);
    }
  };

  const fetchTodayBadges = async () => {
    try {
      // const {
      //   data: { session },
      // } = await supabase.auth.getSession();

      // const accessToken = session?.access_token;
      // if (!accessToken) throw new Error("No access token");

      const res = await fetch(
        `${API_BASE}/api/visitor-invitations/today-checkedin-badges`,
        {
          headers: {
            // Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      if (!res.ok) throw new Error("Failed to fetch badges");

      const data = await res.json();

      console.log("BADGE API RESPONSE:", data); // ✅ DEBUG

      // ✅ STEP 1: clean numbers
      const nums = (data || [])
        .map((b: string) => Number(b))
        .filter((n: number) => Number.isInteger(n) && n > 0);

      // ✅ STEP 2: compute next badge

      let next = 1;
      while (nums.includes(next)) {
        next++;
      }

      console.log("NEXT BADGE:", next);


      // ✅ STEP 3: SET VALUE (CRITICAL)
      setBadgeNumber(next.toString());
    } catch (err) {
      console.error("Badge fetch failed:", err);

      // ✅ FAIL SAFE → ALWAYS SHOW 1
      setBadgeNumber("1");
    }
  };



  // ADD OR REMOVE VISITORS
  const handleAddVisitor = async (invId) => {
    // const { data: { session } } = await supabase.auth.getSession();

    await fetch(`${API_BASE}/api/visitor-invitations/${invId}/additional-visitors`, {
      method: "POST",
      headers: {
        // Authorization: `Bearer ${session?.access_token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(newVisitor)
    });
    // toast.success("Visitor added");
    Swal.fire({
      title: 'Success',
      text: 'Visitor added',
      icon: 'success',
      confirmButtonText: 'OK'
    });
    setNewVisitor({ name: "", email: "", phone: "", company: "" });
    fetchData();
  };

  const handleRemoveVisitor = async (visitorId) => {
    // const { data: { session } } = await supabase.auth.getSession();

    await fetch(`${API_BASE}/api/visitor-invitations/additional-visitors/${visitorId}`, {
      method: "DELETE",
      headers: {
        // Authorization: `Bearer ${session?.access_token}`
      }
    });

    toast.success("Visitor removed");
    fetchData();
  };

  // ADDED SAVEHANDLER (No Refetch)
  const handleSaveVisitors = async (updatedVisitors) => {
    // const { data: { session } } = await supabase.auth.getSession();

    // ✅ Find removed visitors
    const original = selectedVisitors;

    const removed = original.filter(
      o => !updatedVisitors.some(u => u.id === o.id)
    );

    const added = updatedVisitors.filter(v => v.isNew);
    const edited = updatedVisitors.filter(v => v.isEdited && !v.isNew);
    // API Calls
    await Promise.all([
      ...updatedVisitors
        .filter(v => v.isNew)
        .map(async (v) => {
          await fetch(`${API_BASE}/api/visitor-invitations/${dialogInvId}/additional-visitors`, {
            method: "POST",
            headers: {
              // Authorization: `Bearer ${session?.access_token}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({
              name: v.name,
              email: v.email,
              phone: v.phone,
              company: v.company
            })
          });
        }),

      ...original
        .filter(o => !updatedVisitors.some(u => u.id === o.id))
        .map(async (v) => {
          await fetch(`${API_BASE}/api/visitor-invitations/additional-visitors/${v.id}`, {
            method: "DELETE",
            headers: {
              // Authorization: `Bearer ${session?.access_token}`
            }
          });
        })
    ]);
    setInvitations(prev =>
      prev.map(inv =>
        inv.id === dialogInvId
          ? { ...inv, additionalVisitors: updatedVisitors }
          : inv
      )
    );
    Swal.fire({
      title: 'Success',
      text: 'Visitors added successfully',
      icon: 'success',
      confirmButtonText: 'OK'
    });
    // toast.success("Visitors updated");
    setDialogInvId(null);       // ✅ closes popup
    setSelectedVisitors([]);    // ✅ clears previous visitors
  };

  // ================= CHECK-IN =================
  // Old handleCheckInWithLaptop removed - validation now happens in the Confirm button directly

  const handleSaveCaptured = async () => {
    if (!capturedImage) {
      toast.error("No image captured");
      return;
    }
    if (!photoDialogId) {
      toast.error("No visitor selected");
      return;
    }
    if (!isCheckInDisabled) {
      toast.error("Confirm details first");
      return;
    }
    if (uploading) return;
    const res = await fetch(capturedImage);
    const blob = await res.blob();
    await uploadBlob(blob, photoDialogId);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !photoDialogId) return;
    await uploadBlob(file, photoDialogId);
  };

  const closeDialog = () => {
    stopCamera();
    setCapturedImage(null);
    setPhotoDialogId(null);
  };

  // Ensure camera stops when dialog closes
  useEffect(() => {
    if (!photoDialogId) {
      stopCamera();
      setCapturedImage(null);
    }
  }, [photoDialogId, stopCamera]);

  // Attach stream to video element when it changes
  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
    }
  }, [stream]);

  console.log("selected", selected);

  if (loading) return <p className="text-muted-foreground">Loading…</p>;
  if (invitations.length === 0) return <Card><CardContent className="py-8 text-center text-muted-foreground">No visitor invitations to display.</CardContent></Card>;
  const displayList = filtered;
  return (
    <>
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">

          {/* LEFT: Filters */}
          <InvitationFilters
            filter={filter}
            onChange={setFilter}
            statusOptions={SEC_STATUS_OPTIONS}
            isRecurring={isRecurring}
          />

          {/* RIGHT: Search + Checkbox */}
          <div className="flex flex-wrap items-center gap-3 w-full sm:w-auto">

            {showRecurring && (
              <input
                type="text"
                placeholder="Search phone..."
                value={phoneSearch}
                onChange={(e) => setPhoneSearch(e.target.value)}
                className="border rounded-md px-2 py-1 text-sm w-full sm:w-[200px]"
              />
            )}

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={showRecurring}
                onChange={(e) => {
                  setShowRecurring(e.target.checked);
                  setPhoneSearch("");
                }}
              />
              <span className="text-sm font-medium">
                Recurring
              </span>
            </label>

          </div>

        </div>
        {displayList.length === 0 ? (
          <Card><CardContent className="py-8 text-center text-muted-foreground">No invitations match the selected filters.</CardContent></Card>
        ) : displayList.map(inv => (
          <Card key={inv.id}>
            <CardContent className="py-4">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 flex-wrap">
                <div className="flex gap-4 flex-1 min-w-0">
                  <VisitorPhoto photoUrl={inv.visitorPhotoUrl} name={inv.visitorName} />
                  <div className="space-y-1 min-w-0 flex-1">

                    <div className="flex items-center gap-2">
                      <h3 className="font-semibold text-foreground flex items-center gap-2">
                        {inv.visitorName}


                        {inv.additionalVisitors?.length > 0 && (
                          <span
                            className="text-xs text-blue-500 font-normal cursor-pointer"
                            onClick={(e) => {
                              e.stopPropagation();
                              setVisitorPopup(inv);
                            }}
                          >
                            +{inv.additionalVisitors.length} visitors
                          </span>

                        )}

                      </h3>
                      {(() => {
                        const isRecurring = inv.visitor_type === "Recurring";

                        const state =
                          inv.visitor_type === "Recurring"
                            ? (visitorStates[inv.visitor_phone] || inv.status)
                            : inv.status;

                        const isExpired =
                          inv.status === "approved" && hasVisitEnded(inv);

                        if (
                          state !== "checked_in" &&
                          state !== "checked_out" &&
                          state !== "cancelled" &&
                          !isExpired
                        ) {
                          return null;
                        }

                        return (
                          <Badge
                            className={
                              state === "checked_in"
                                ? "bg-blue-100 text-blue-800"
                                : state === "checked_out" || state === "completed"
                                  ? "bg-purple-100 text-purple-800"
                                  : state === "cancelled"
                                    ? "bg-red-100 text-red-800"
                                    : isExpired
                                      ? "bg-red-100 text-red-800"
                                      : ""
                            }
                          >
                            {state === "checked_in"
                              ? "Checked In"
                              : state === "checked_out"
                                ? "Checked Out"
                                : state === "completed"
                                  ? "Completed"
                                  : state === "cancelled"
                                    ? "Cancelled"
                                    : isExpired
                                      ? "Not Visited"
                                      : ""}
                          </Badge>
                        );
                      })()}
                      {/* {inv.visitor_type === "Recurring" && (
                        <Badge className="bg-purple-100 text-purple-800">
                          Recurring
                        </Badge>)} */}
                    </div>
                    <p className="text-xs text-gray-800">
                      📞 {inv.visitor_phone}
                    </p>

                    {showRecurring && visitorStats[inv.visitor_phone] && (
                      <div className="text-xs text-gray-800 space-y-1">
                        <p>
                          Last Visit: {formatDateTime(visitorStats[inv.visitor_phone].last)}
                        </p>

                        <p>
                          No of times visited: {visitorStats[inv.visitor_phone].count}
                        </p>
                      </div>
                    )}
                    <p className="text-sm text-gray-800">
                      {inv.visitorCompany && `${inv.visitorCompany} · `}
                      {inv.department} · {inv.purpose}
                    </p>
                    {inv.visitor_type !== "Recurring" && (
                      <p className="text-xs text-gray-800">
                        Expected Arrival :{" "}
                        {inv.visitStartDate
                          ? format(new Date(inv.visitStartDate), "dd-MM-yyyy")
                          : "—"}{" "}
                        {inv.visitStartTime
                          ? format(new Date(`1970-01-01T${inv.visitStartTime}`), "hh:mm a")
                          : "--"}{" "}
                        –{" "}
                        {inv.visitEndDate
                          ? format(new Date(inv.visitEndDate), "dd-MM-yyyy")
                          : "—"}{" "}
                        {inv.visitEndTime
                          ? format(new Date(`1970-01-01T${inv.visitEndTime}`), "hh:mm a")
                          : "--"}
                      </p>
                    )}

                    {/* {inv.additional_requirements && (
                      <p className="text-sm text-muted-foreground">
                        📌 Requirements: {inv.additional_requirements}
                      </p>
                    )}

                    {inv.facilitator_notes && (
                      <p className="text-sm text-muted-foreground">
                        📋 Facilitator notes: {inv.facilitator_notes}
                      </p>
                    )} */}
                    {(inv.status === "checked_in" || inv.status === "checked_out") && (
                      <span className="mt-3 text-xs text-gray-800">
                        checked-in:{" "}
                        {inv.checkedInAt
                          ? format(new Date(inv.checkedInAt), "dd-MM-yyyy hh:mm a")
                          : "--"}
                      </span>
                    )}

                    {inv.status === "checked_out" && (
                      <span className="mt-3 text-xs text-gray-800">
                        , checked-out:{" "}
                        {inv.checkedOutAt
                          ? format(new Date(inv.checkedOutAt), "dd-MM-yyyy hh:mm a")
                          : "--"}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2 flex-shrink-0">
                  {inv.status === "approved" && !hasVisitEnded(inv) && (
                    <Button
                      // variant="outline"
                      size="sm"
                      onClick={(e) => {

                        e.stopPropagation(); // ✅ IMPORTANT
                        setDialogInvId(inv.id);
                        setSelectedVisitors(inv.additionalVisitors || []);
                        setMainVisitor(inv);
                      }}
                    >
                      Add/Remove Additional Visitors
                    </Button>)}

                  <Button variant="ghost" size="icon"
                    onClick={() => setSelected(inv)}
                    title="View details">
                    <Eye className="w-4 h-4" />
                  </Button>

      {inv.status === "approved" && inv.visitor_type !== "Recurring" && inv.status !== "checked_in" && inv.status !== "checked_out" && inv.createdBy?.toLowerCase() === user?.email?.toLowerCase() && (
        <>
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              if (onEdit) {
                onEdit(inv);
              }
            }}
            title="Edit invitation"
          >
            <Edit className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            onClick={(e) => {
              e.stopPropagation();
              setCancelTarget(inv);
              setCancelOpen(true);
            }}
            title="Cancel invitation"
          >
            <XCircle className="w-4 h-4 text-red-500" />
          </Button>
        </>
      )}
<div className="flex flex-wrap gap-2 w-full sm:w-auto justify-end sm:justify-start">
                    {(() => {
                      const state = visitorStates[inv.visitor_phone];
                      const isRecurring = inv.visitor_type === "Recurring";
                      const effectiveState = isRecurring
                        ? visitorStates[inv.visitor_phone]
                        : inv.status;
                      if (effectiveState === "checked_in") {
                        return (
                          <Button
                            // variant="secondary"
                            size="sm"
                            onClick={() => {
                              if (isRecurring) {
                                handleRecurringCheckOut(inv.id);
                              } else {
                                handleCheckOut(inv.id);
                              }
                            }}
                          >
                            <LogOut className="w-3 h-3 mr-1" />
                            Check Out
                          </Button>
                        );
                      }
                      if (effectiveState === "checked_out") {
                        if (isRecurring) {
                          return (
                            <Button size="sm" onClick={() => openLaptopDialog(inv.id)}>
                              <LogIn className="w-3 h-3 mr-1" />
                              Check In
                            </Button>
                          );
                        }
                        return null;
                      }
                       return (
                         inv.status !== "cancelled" && !hasVisitEnded(inv) &&              // ✅ ADDED (block if expired)
                         hasVisitStartTimeReached(inv) && (
                          <Button size="sm" onClick={() => openLaptopDialog(inv.id)}>
                            <LogIn className="w-3 h-3 mr-1" />
                            Check In
                          </Button>
                        )
                      );
                    })()}

                  </div>

                  {/* {inv.status === 'checked_out' && (
                    <span className="text-xs text-muted-foreground italic">Completed</span>
                  )} */}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>


      {/* ✅ LAPTOP DIALOG */}

      <Dialog open={!!laptopDialogId} onOpenChange={() => resetCheckInDialog()}>
        <DialogContent className="gap-0 p-0 overflow-hidden [&>button]:text-black [&>button:hover]:text-red-500 max-w-[90vw] max-h-[90vh] sm:max-w-lg">
          <DialogHeader className="bg-muted border-b px-6 py-3">
            <DialogTitle>Check-in Details</DialogTitle>
          </DialogHeader>

          <div className="space-y-4 px-6 pb-4 pt-3">

            <div className="space-y-2">
              <Label>
                Identity Proof Type <span className="text-red-500">*</span>
              </Label>

              <Select
                value={identityProofType}
                onValueChange={(v) => {
                  setIdentityProofType(v);
                  setVerificationErrors((prev) => {
                    const copy = { ...prev };
                    delete copy.identityProofType;
                    return copy;
                  });
                }}
              >
                <SelectTrigger className="w-full">
                  <SelectValue placeholder="Select identity proof" />
                </SelectTrigger>
                <SelectContent>
                  {IDENTITY_PROOF_OPTIONS.map((opt) => (
                    <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {verificationErrors.identityProofType && (
                <p className="text-sm text-red-500">{verificationErrors.identityProofType}</p>
              )}
            </div>

            <label className="flex gap-2 items-center text-sm font-normal">
              <input
                type="checkbox"
                checked={isDocumentVerified}
                onChange={(e) => {
                  setIsDocumentVerified(e.target.checked);
                  setVerificationErrors((prev) => {
                    const copy = { ...prev };
                    delete copy.documentVerified;
                    return copy;
                  });
                }}
              />
              Document Verified by Security <span className="text-red-500">*</span>
            </label>
            {verificationErrors.documentVerified && (
              <p className="text-sm text-red-500">{verificationErrors.documentVerified}</p>
            )}

            <div className="space-y-2">
              <Label>
                Badge Number <span className="text-red-500">*</span>
              </Label>
              <input
                value={badgeNumber || "Loading..."}
                onChange={(e) => setBadgeNumber(e.target.value)}
                placeholder="Enter badge number"
                className="border p-2 w-full rounded-md"
                disabled={true}
              />

              {errors.badgeNumber && (
                <p className="text-sm text-red-500">{errors.badgeNumber}</p>
              )}

            </div>

            <label className="flex gap-2 items-center text-sm font-normal">
              <input
                type="checkbox"
                checked={hasLaptop}
                onChange={haslaptopfun}
              />Has Laptop
            </label>

                {hasLaptop && (
                  <>
                    <div className="space-y-2">
                      <Label>
                        Laptop Make and Model <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        value={laptopName}
                        onChange={(e) => {
                          const value = e.target.value;
                          const LAPTOP_REGEX = /^(?=.{2,100}$)[A-Za-z0-9][A-Za-z0-9\s\-._()/+]*$/;
                          if (value && !LAPTOP_REGEX.test(value)) {
                            setLaptopName(value);
                            setErrors((prev) => ({
                              ...prev,
                              laptopName: "Only letters, numbers, spaces, hyphen, dot, underscore, parentheses, slash, plus are allowed. Must start with a letter or number. Length: 2-100 characters."
                            }));
                            return;
                          }
                          setLaptopName(value);
                          if (!value.trim()) {
                            setErrors((prev) => ({
                              ...prev,
                              laptopName: "Laptop Make and Model is required"
                            }));
                          }
                          else {
                            setErrors((prev) => ({
                              ...prev,
                              laptopName: undefined
                            }));
                          }
                        }}
                        placeholder="Enter Laptop Make and Model"
                      />

                      {errors.laptopName && (
                        <p className="text-sm text-red-500">{errors.laptopName}</p>
                      )}

                    </div>

                    <div className="space-y-2">
                      <Label>
                        Laptop serial number <span className="text-red-500">*</span>
                      </Label>
                      <Input
                        value={macAddress}
                        onChange={(e) => {
                          const value = e.target.value;
                          const SERIAL_REGEX = /^(?=.{5,50}$)[A-Za-z0-9][A-Za-z0-9-]*$/;
                          if (value && !SERIAL_REGEX.test(value)) {
                            setMacAddress(value);
                            setErrors((prev) => ({
                              ...prev,
                              macAddress: "Only letters, numbers, and hyphens are allowed. Must start with a letter or number. Length: 5-50 characters."
                            }));
                            return;
                          }
                          setMacAddress(value);
                          if (!value.trim()) {
                            setErrors((prev) => ({
                              ...prev,
                              macAddress: "Laptop serial number is required"
                            }));
                          }
                          else {
                            setErrors((prev) => ({
                              ...prev,
                              macAddress: undefined
                            }));
                          }
                        }}
                        placeholder="Enter Laptop serial number"
                      />

                      {errors.macAddress && (
                        <p className="text-sm text-red-500">{errors.macAddress}</p>
                      )}

                    </div>
                  </>
                )}

              <div className="flex justify-end gap-4 pt-2">
               <Button onClick={resetCheckInDialog}>Cancel</Button>
                <Button
                  onClick={() => {
                    const newErrors: typeof verificationErrors = {};
                    const newFieldErrors: typeof errors = {};
                    if (!identityProofType.trim()) {
                      newErrors.identityProofType = "Identity proof type is required";
                    }
                    if (!isDocumentVerified) {
                      newErrors.documentVerified = "Document must be verified by security";
                    }
                    if (hasLaptop) {
                      if (!laptopName.trim()) {
                        newFieldErrors.laptopName = "Laptop Make and Model is required";
                      }
                      if (!macAddress.trim()) {
                        newFieldErrors.macAddress = "Laptop serial number is required";
                      }
                    }
                    if (Object.keys(newErrors).length > 0 || Object.keys(newFieldErrors).length > 0) {
                      setVerificationErrors(newErrors);
                      setErrors(newFieldErrors);
                      return;
                    }
                    setVerificationErrors({});
                    setErrors({});
                    setIsCheckInDisabled(true);
                    toast.success("Verification complete. Now capture photo.");
                  }}
                 disabled={isCheckInDisabled}
                 className={isCheckInDisabled ? "opacity-50 cursor-not-allowed" : ""}
               >
                 Confirm
               </Button>
               <Button
                 variant="outline"
                 size="sm"
                 disabled={!isCheckInDisabled}
                 onClick={() => {
                   if (!isCheckInDisabled) {
                     toast.error("Please confirm details first");
                     return;
                   }
                   setPhotoDialogId(laptopDialogId!);
                 }}
               >
                 <Camera className="w-3 h-3 mr-1" /> Photo
               </Button>
             </div>

          </div>
        </DialogContent>
      </Dialog>

      {/* Visitor Dialog*/}

      <VisitorManagerDialog
        open={!!dialogInvId}
        onClose={() => {
          setDialogInvId(null);
          setMainVisitor(null);
          setSelectedVisitors([]);
        }}
        invitationId={dialogInvId}
        existingVisitors={selectedVisitors}
        mainVisitor={mainVisitor}
        onSave={handleSaveVisitors}
      />


      <Dialog open={!!photoDialogId} onOpenChange={() => closeDialog()}>
        <DialogContent className="gap-0 p-0 overflow-hidden [&>button]:text-black [&>button:hover]:text-red-500 max-w-[90vw] max-h-[90vh] sm:max-w-lg">
          <DialogHeader className="bg-muted border-b px-6 py-3">
            <DialogTitle>Capture Visitor Photo</DialogTitle>
          </DialogHeader>
          <div className="px-6 pb-4 pt-3">
            <Tabs defaultValue="camera" className="w-full">
              <TabsList className="w-full">
                <TabsTrigger value="camera" className="flex-1 gap-1.5">
                  <Video className="w-3.5 h-3.5" /> Webcam
                </TabsTrigger>
                <TabsTrigger value="upload" className="flex-1 gap-1.5">
                  <Upload className="w-3.5 h-3.5" /> Upload
                </TabsTrigger>
              </TabsList>

              <TabsContent value="camera" className="mt-4">
                <div className="flex flex-col items-center gap-4">
                  {!capturedImage ? (
                    <>
                      {/* Camera Selector Dropdown */}
                      {videoDevices.length > 1 && (
                        <div className="w-full max-w-md">
                          <Label className="text-sm font-medium">Select Camera</Label>
                          <Select value={selectedDeviceId} onValueChange={(deviceId) => {
                            setSelectedDeviceId(deviceId);
                            // If camera is running, restart with new device
                            if (stream) {
                              stopCamera();
                              // Small delay to ensure stream is stopped
                              setTimeout(() => startCamera(), 100);
                            }
                          }} disabled={isEnumeratingDevices}>
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="Select camera..." />
                            </SelectTrigger>
                            <SelectContent>
                              {videoDevices.map((device) => (
                                <SelectItem key={device.deviceId} value={device.deviceId}>
                                  {device.label || `Camera ${videoDevices.indexOf(device) + 1}`}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {isEnumeratingDevices && (
                            <p className="text-xs text-muted-foreground mt-1">Detecting cameras...</p>
                          )}
                        </div>
                      )}
                      
                      <div className="relative w-full aspect-[4/3] bg-muted rounded-lg overflow-hidden">
                        {stream ? (
                          <video
                            ref={videoRef}
                            autoPlay
                            playsInline
                            muted
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center gap-2 text-muted-foreground">
                            <VideoOff className="w-8 h-8" />
                            <p className="text-sm">Camera off</p>
                          </div>
                        )}
                      </div>
                      <div className="flex gap-2">
                        {!stream ? (
                          <Button onClick={startCamera} variant="outline">
                            <Video className="w-4 h-4 mr-1.5" /> Start Camera
                          </Button>
                        ) : (
                          <>
                            <Button onClick={stopCamera} variant="outline" size="sm">
                              <VideoOff className="w-3.5 h-3.5 mr-1" /> Stop
                            </Button>
                            <Button onClick={capturePhoto}>
                              <Camera className="w-4 h-4 mr-1.5" /> Capture
                            </Button>
                          </>
                        )}
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="w-full aspect-[4/3] rounded-lg overflow-hidden">
                        <img src={capturedImage} alt="Captured" className="w-full h-full object-cover" />
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" onClick={retakePhoto}>Retake</Button>
                        <Button onClick={handleSaveCaptured} disabled={uploading}>
                          {uploading ? 'Saving…' : 'Save Photo'}
                        </Button>
                      </div>
                    </>
                  )}
                  <canvas ref={canvasRef} className="hidden" />
                </div>
              </TabsContent>



              <TabsContent value="upload" className="mt-4">
                <div className="flex flex-col items-center gap-4">
                  <p className="text-sm text-muted-foreground">Select an image from your device</p>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    disabled={uploading}
                    className="text-sm file:mr-3 file:px-3 file:py-1.5 file:rounded-md file:border-0 file:bg-primary file:text-primary-foreground file:text-sm file:font-medium file:cursor-pointer"
                  />
                  {uploading && <p className="text-sm text-muted-foreground">Uploading…</p>}
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </DialogContent>
      </Dialog>
      {/* ✅ VIEW DETAILS DIALOG (OUTSIDE) */}
      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="gap-0 p-0 overflow-hidden [&>button]:text-black [&>button:hover]:text-red-500 max-w-[90vw] max-h-[90vh] sm:max-w-lg">
          <DialogHeader className="bg-muted border-b px-6 py-3">
            <DialogTitle>Invitation Details</DialogTitle>
          </DialogHeader>

          {selected && <InvitationDetailsContent invitation={selected} />}

        </DialogContent>
      </Dialog>

      <Dialog open={!!visitorPopup} onOpenChange={() => setVisitorPopup(null)}>
        <DialogContent className="gap-0 p-0 overflow-hidden [&>button]:text-black [&>button:hover]:text-red-500 max-w-[90vw] max-h-[90vh] sm:max-w-lg">
          <DialogHeader className="bg-muted border-b px-6 py-3">
            <DialogTitle>Visitor Details</DialogTitle>
          </DialogHeader>

          {visitorPopup && (
            <div className="px-6 pb-4 pt-3 overflow-x-auto">
              <table className="w-full text-sm border min-w-[500px]">
                <thead>
                  <tr className="bg-gray-100 text-left">
                    <th className="p-2 border">Name</th>
                    <th className="p-2 border">Email</th>
                    <th className="p-2 border">Phone</th>
                    <th className="p-2 border">Company</th>
                  </tr>
                </thead>

                <tbody>
                  {/* ✅ MAIN VISITOR */}
                  <tr className="bg-gray-50 font-medium">
                    <td className="p-2 border">{visitorPopup.visitorName}</td>
                    <td className="p-2 border">{visitorPopup.visitorEmail}</td>
                    <td className="p-2 border">{visitorPopup.visitor_phone}</td>
                    <td className="p-2 border">{visitorPopup.visitorCompany}</td>
                  </tr>

                  {/* ✅ ADDITIONAL VISITORS */}
                  {visitorPopup.additionalVisitors?.map((v: any) => (
                    <tr key={v.id}>
                      <td className="p-2 border">{v.name}</td>
                      <td className="p-2 border">{v.email}</td>
                      <td className="p-2 border">{v.phone}</td>
                      <td className="p-2 border">{v.company}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Cancel Confirmation Dialog */}
      <Dialog open={cancelOpen} onOpenChange={(open) => {
        if (!open) {
          setCancelOpen(false);
          setCancelTarget(null);
          setCancelReason("");
        }
      }}>
        <DialogContent className="gap-0 p-0 overflow-hidden [&>button]:text-black [&>button:hover]:text-red-500 max-w-[90vw] sm:max-w-md">
          <DialogHeader className="bg-muted border-b px-6 py-3">
            <DialogTitle>Cancel Cold Call Invitation</DialogTitle>
          </DialogHeader>
          <div className="px-6 pt-3 pb-4 space-y-4">
            <DialogDescription className="text-sm text-foreground">
              Are you sure you want to cancel the Cold Call invitation for <strong>{cancelTarget?.visitorName}</strong>? This action can be undone later for audit purposes.
            </DialogDescription>
            <div className="space-y-2">
              <Label htmlFor="cancelReason">
                Reason for Cancellation <span className="text-red-500">*</span>
              </Label>
              <textarea
                id="cancelReason"
                value={cancelReason}
                onChange={(e) => setCancelReason(e.target.value)}
                placeholder="Enter the reason for cancellation..."
                rows={3}
                className="w-full border rounded-md px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-ring"
              />
            </div>
          </div>
          <DialogFooter className="gap-4 px-6 pb-4 pt-0 sm:justify-end border-t">
            <Button variant="outline" onClick={() => {
              setCancelOpen(false);
              setCancelTarget(null);
              setCancelReason("");
            }} disabled={canceling}>
              Close
            </Button>
            <Button onClick={handleCancel} disabled={canceling || !cancelReason.trim()}>
              {canceling ? "Cancelling..." : "Cancel Invitation"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );

  // These are hoisted but used in JSX above — defined here for readability

  async function handleCheckIn(id: string) {
    try {
      const timezoneId = Intl.DateTimeFormat().resolvedOptions().timeZone;

      const res = await fetch(
        `${API_BASE}/api/visitor-invitations/${id}/check-in`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            badgeNumber: "N/A",
            hasLaptop: false,
            timezoneId: timezoneId
          })
        }
      );
      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg);
      }

      Swal.fire({
        title: 'Success',
        text: 'Visitor checked in',
        icon: 'success',
        confirmButtonText: 'OK'
      });
      fetchData();

    } catch (err: any) {
      toast.error(err.message || "Check-in failed");
    }
  }




  async function handleRecurringCheckOut(id: string) {
    try {
      // const {
      //   data: { session },
      // } = await supabase.auth.getSession();

      // const accessToken = session?.access_token;
      // if (!accessToken) throw new Error("No access token");

      const res = await fetch(
        `${API_BASE}/api/recurring/${id}/check-out`,
        {
          method: "POST",
          headers: {
            // Authorization: `Bearer ${accessToken}`,
          },
        }
      );

      if (!res.ok) throw new Error(await res.text());

      toast.success("Checked out ✅");

      // ✅ FIX HERE
      await new Promise((resolve) => setTimeout(resolve, 300));
      await fetchData();

    } catch (err: any) {
      toast.error(err.message || "Check-out failed");
    }
  }


  async function fetchVisitorState(phone: string) {
    try {
      const res = await fetch(
        `${API_BASE}/api/recurring/history?phone=${phone}`
      );
      const data = await res.json();


      if (!data || data.length === 0) {
        return {
          state: null,   // ✅ IMPORTANT CHANGE
          count: 0,
          last: null,
        };
      }

      const latest = data[0];

      const currentState =
        latest.check_out_time === null ? "checked_in" : "checked_out";

      return {
        state: currentState,
        count: data.length,
        last: latest.check_in_time,
      };
    } catch {
      return {
        state: null,
        count: 0,
        last: null,
      };
    }
  }

  async function handleCancel() {
    if (!cancelTarget || !cancelReason.trim()) {
      toast.error("Cancellation reason is required");
      return;
    }

    setCanceling(true);
    try {
      const res = await fetch(
        `${API_BASE}/api/visitor-invitations/${cancelTarget.id}/cancel`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            reason: cancelReason.trim(),
            cancelledBy: user?.email || "security",
          }),
        }
      );

      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg);
      }

      Swal.fire({
        title: 'Success',
        text: 'Invitation cancelled successfully',
        icon: 'success',
        confirmButtonText: 'OK'
      });

      setCancelOpen(false);
      setCancelTarget(null);
      setCancelReason("");
      fetchData();

    } catch (err: any) {
      toast.error(err.message || "Failed to cancel invitation");
    } finally {
      setCanceling(false);
    }
  };

  async function handleCheckOut(id: string) {
    try {
      // ✅ Get access token (Supabase AUTH only)
      // const {
      //   data: { session },
      // } = await supabase.auth.getSession();

      // const accessToken = session?.access_token;
      // if (!accessToken) {
      //   throw new Error("No access token");
      // }

      // ✅ Call ASP.NET Core Check‑Out API
      const res = await fetch(
        `${API_BASE}/api/visitor-invitations/${id}/check-out`,
        {
          method: "POST",
          headers: {
            // Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (!res.ok) {
        const msg = await res.text();
        throw new Error(msg);
      }
      Swal.fire({
        title: 'Success',
        text: 'Visitor checked out successfully',
        icon: 'success',
        confirmButtonText: 'OK'
      });
      // toast.success("Visitor checked out");
      await new Promise((resolve) => setTimeout(resolve, 300));
      await fetchData();

    } catch (err: any) {
      // toast.error(err.message || "Check-out failed");
      Swal.fire({
        title: 'Failed',
        text: err.message + '|| "Check-out failed"',
        icon: 'error',
        confirmButtonText: 'OK'
      });

    }
  }
}
