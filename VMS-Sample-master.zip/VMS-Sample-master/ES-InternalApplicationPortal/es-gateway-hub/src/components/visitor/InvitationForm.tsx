import { useState, useEffect, useRef } from "react";
import { format } from "date-fns";
import { Textarea } from "@/components/ui/textarea";
import { useAuth } from "@/hooks/useAuth";
import { apiFetch } from "@/api/http";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { VisitorManagerDialog } from "./VisitorManagerDialog";
// import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "sonner";
import Swal from 'sweetalert2';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { CalendarIcon, XCircle, Trash2 } from "lucide-react";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
// import { supabase } from "@/integrations/supabase/client";
type InvitationMode = "create" | "edit" | "approve";
interface Props {
  onSuccess: () => void;
  editData?: any;
  mode: InvitationMode;
  restrictToDateOnly?: boolean;
  aiData?: Record<string, any> | null;
}

const DEPARTMENTS = [
  "Sales",
  "Marketing",
  "Engineering",
  "Human Resources",
  "Finance",
  "Operations",
  "Business Development",
  "Management",
];

// Regex for "Others" purpose validation
const OTHERS_PURPOSE_REGEX = /^[a-zA-Z0-9\s.,\-_/&():;'"%#@+=!?]{1,500}$/;

const API_BASE = import.meta.env.VITE_API_URL;
// const ADDITIONAL_OPTIONS = ["Wi-Fi access", "Parking", "Meeting Room", "Pickup and Drop", "Stay", "Food"];

// function parseRequirements(val: string): string[] {
//   if (!val) return [];
//   return val
//     .split(",")
//     .map((s) => s.trim())
//     .filter(Boolean);
// }

function formatTimeForInput(time: unknown): string {
  if (!time) return "";
  const value = String(time);
  return value.length >= 5 ? value.substring(0, 5) : value;
}

export function InvitationForm({ onSuccess, editData, mode, restrictToDateOnly, aiData }: Props) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);

  const today = new Date().toISOString().split("T")[0];


  const [form, setForm] = useState({
    visitor_name: "",
    visitor_company: "",
    visitor_email: "",
    visitor_phone: "",
    visit_start_date: "",
    visit_end_date: "",
    visit_start_time: "",
    visit_end_time: "",
    purpose: "",
    purpose_others: "",
    number_of_visitors: "",
    remarks: "",
    department: [] as string[],
      host_name: "",
      host_email: "",
      visitor_type: "Non-Recurring"
  });

  // Ref to always have fresh form values for validation
  const formRef = useRef(form);
  formRef.current = form;


  // ✅ ADD THIS HELPER HERE
  const getMinStartTime = () => {
    if (!form.visit_start_date) return undefined;

    const today = new Date().toISOString().split("T")[0];

    if (form.visit_start_date !== today) return undefined;

    const now = new Date();

    const hh = String(now.getHours()).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");

    return `${hh}:${mm}`;
  };

  const visitorNameRef = useRef<HTMLInputElement>(null);
  const visitorEmailRef = useRef<HTMLInputElement>(null);
  const visitorPhone = useRef<HTMLInputElement>(null);
  const startTimeRef = useRef<HTMLInputElement>(null);
  const endTimeRef = useRef<HTMLInputElement>(null);
  const visitorsCountRef = useRef<HTMLInputElement>(null);
  const hostNameRef = useRef<HTMLInputElement>(null);
  const hostEmailRef = useRef<HTMLInputElement>(null);


  useEffect(() => {
    if (!editData) return;
    setForm({
      visitor_name: editData.visitorName ?? "",
      visitor_company: editData.visitorCompany ?? "",
      visitor_email: editData.visitorEmail ?? "",
      visitor_phone: editData.visitorPhone ?? "",

      visit_start_date: editData.visitStartDate ?? "",
      visit_end_date: editData.visitEndDate ?? "",

      // ✅ trim seconds for <input type="time">
      visit_start_time: formatTimeForInput(editData.visitStartTime),
      visit_end_time: formatTimeForInput(editData.visitEndTime),

      purpose: editData.purpose ?? "",
      purpose_others: editData.purpose_others ?? "",
      number_of_visitors: editData.number_of_visitors?.toString() ?? "",
      remarks: editData.remarks ?? "",
      department: editData.department
        ? editData.department.split(",").map((d: string) => d.trim())
        : [],
      host_name: editData.hostName ?? "",
      host_email: editData.hostEmail ?? "",
      visitor_type: editData.visitorType ?? "Non-Recurring",
    });

    setAdditionalVisitors(
      (editData.additionalVisitors || editData.AdditionalVisitors || []).map((v: any) => ({
        id: v.Id ?? v.id,
        name: v.Name ?? v.name ?? "",
        email: v.Email ?? v.email ?? "",
        phone: v.Phone ?? v.phone ?? "",
        company: v.Company ?? v.company ?? "",
      }))
    );

    console.log("=== EDIT DATA ADDITIONAL VISITORS ===", editData?.AdditionalVisitors, editData?.additionalVisitors);
    console.log("=== FULL EDIT DATA ===", JSON.stringify(editData, null, 2));

    // setSelectedRequirements(
    //   parseRequirements(editData.additional_requirements ?? "")
    // );
  }, [editData]);

  useEffect(() => {
    if (!aiData || editData || mode !== "create") return;

    const mappedDept = Array.isArray(aiData.department)
      ? aiData.department
      : aiData.department
        ? [aiData.department]
        : [];

    setForm({
      visitor_name: aiData.visitor_name ?? "",
      visitor_company: aiData.visitor_company ?? "",
      visitor_email: aiData.visitor_email ?? "",
      visitor_phone: aiData.visitor_phone ?? "",
      visit_start_date: aiData.visit_start_date ?? "",
      visit_end_date: aiData.visit_end_date ?? "",
      visit_start_time: aiData.visit_start_time ?? "",
      visit_end_time: aiData.visit_end_time ?? "",
      purpose: aiData.purpose ?? "",
      purpose_others: aiData.purpose_others ?? "",
      number_of_visitors: "",
      remarks: aiData.remarks ?? "",
      department: mappedDept.length > 0 ? mappedDept : [],
      host_name: aiData.host_name ?? "",
      host_email: aiData.host_email ?? "",
      visitor_type: aiData.visitor_type ?? "Non-Recurring",
    });
  }, [aiData, editData, mode]);


  // const [selectedRequirements, setSelectedRequirements] = useState<string[]>(
  //   parseRequirements(editData?.additional_requirements || "")
  // );
  const [errors, setErrors] = useState<Record<string, string>>({});

  const isNewInvitation = !editData?.id;
  const isApprovalMode = mode === "approve";

  // Auto-populate today's date and current time on load
  useEffect(() => {
    if (editData || isApprovalMode) return;
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, "0");
    const mm = String(now.getMinutes()).padStart(2, "0");
    const currentTime = `${hh}:${mm}`;

    setForm((prev) => ({
      ...prev,
      visit_start_date: prev.visit_start_date || today,
      visit_end_date: prev.visit_end_date || today,
      visit_start_time: prev.visit_start_time || currentTime,
    }));
  }, []);
  const [isDeptOpen, setIsDeptOpen] = useState(false);
  const [managerEditEnabled, setManagerEditEnabled] = useState(false);
  const isReadOnly = isApprovalMode && !managerEditEnabled;

  const [openStartDate, setOpenStartDate] = useState(false);
  const [openEndDate, setOpenEndDate] = useState(false);

  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [rejecting, setRejecting] = useState(false);

  const [rejectId, setRejectId] = useState<string | null>(null);
  const [hideEditButton, setHideEditButton] = useState(false);
  const [visitorDialogOpen, setVisitorDialogOpen] = useState(false);
  const [additionalVisitors, setAdditionalVisitors] = useState<any[]>([]);

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    // ✅ Collect ALL validation errors
    if (!form.visitor_name.trim()) {
      newErrors.visitor_name = "Visitor name is required";
    }

    const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (form.visitor_email.trim() && !EMAIL_REGEX.test(form.visitor_email)) {
      newErrors.visitor_email = "Enter a valid email address";
    }


    // ✅ Phone (ADD THIS HERE ✅)
    if (!form.visitor_phone.trim()) {
      newErrors.visitor_phone = "Phone number is required";
    } else if (!/^\d{1,15}$/.test(form.visitor_phone)) {
      newErrors.visitor_phone = "Phone must be numeric (max 15 digits)";
    }

    if (!form.visit_start_date) {
      newErrors.visit_start_date = "Start date is required";
    }

    if (!form.visit_end_date) {
      newErrors.visit_end_date = "End date is required";
    }

    if (!form.visit_start_time || form.visit_start_time == "00:00") {
      newErrors.visit_start_time = "Start time is required";
    }

    if (!form.visit_end_time || form.visit_end_time == "00:00") {
      newErrors.visit_end_time = "End time is required";
    }

    if (!form.purpose) {
      newErrors.purpose = "Purpose is required";
    }

    // ✅ Validate "Others" purpose remarks
    if (form.purpose === "Others") {
      const othersValue = form.purpose_others?.trim() || "";
      if (!othersValue) {
        newErrors.purpose_others = "Please enter the purpose of visit.";
      } else if (othersValue.length > 500) {
        newErrors.purpose_others = "Purpose of visit cannot exceed 500 characters.";
      } else if (!OTHERS_PURPOSE_REGEX.test(othersValue)) {
        newErrors.purpose_others = 'Only letters, numbers, spaces, and standard business special characters (.,-_/&():;\'"%#@+=!?) are allowed.';
      }
    }

    if (!form.department.length) {
      newErrors.department = "Department is required";
    }

    if (!restrictToDateOnly && !form.visitor_type) {
      newErrors.visitor_type = "Visitor type is required";
    }
    // ✅ Set all errors at once
    setErrors(newErrors);

    // ✅ Focus ONLY the first invalid field (in order)
    if (Object.keys(newErrors).length > 0) {
      if (newErrors.visitor_name) {
        visitorNameRef.current?.focus();
      } else if (newErrors.visitor_email) {
        visitorEmailRef.current?.focus();
      } else if (newErrors.visitor_phone) {
        visitorPhone.current?.focus();
      } else if (newErrors.visit_start_time) {
        startTimeRef.current?.focus();
      } else if (newErrors.visit_end_time) {
        endTimeRef.current?.focus();
      } else if (newErrors.number_of_visitors) {
        visitorsCountRef.current?.focus();
      } else if (newErrors.host_name) {
        hostNameRef.current?.focus();
      } else if (newErrors.host_email) {
        hostEmailRef.current?.focus();
      }
    }
    if (!form.host_name.trim()) {
      newErrors.host_name = "Host name is required";
    }

    if (!form.host_email.trim()) {
      newErrors.host_email = "Host email is required";
    } else if (!EMAIL_REGEX.test(form.host_email)) {
      newErrors.host_email = "Enter a valid host email";
    }
    // ✅ Return validity
    return Object.keys(newErrors).length === 0;
  };

  useEffect(() => {
    const handleClick = () => setIsDeptOpen(false);
    window.addEventListener("click", handleClick);
    return () => window.removeEventListener("click", handleClick);
  }, []);

  useEffect(() => {
    if (!form.visit_start_date) return;

    const today = new Date().toISOString().split("T")[0];

    if (form.visit_start_date === today) {
      const now = new Date();

      const hh = String(now.getHours()).padStart(2, "0");
      const mm = String(now.getMinutes()).padStart(2, "0");

      const currentTime = `${hh}:${mm}`;

      if (!form.visit_start_time || form.visit_start_time < currentTime) {
        setForm((prev) => ({
          ...prev,
          visit_start_time: currentTime,
        }));
      }
    }
  }, [form.visit_start_date]);


  function toTimeSpan(value: string): string {
    return value?.length === 5 ? `${value}:00` : value;
  }

  function formatDateOnly(date: string) {
    return date?.includes("T") ? date.split("T")[0] : date;
  }
  const handleReject = async () => {
    if (!rejectReason.trim()) {
      // toast.error("Please provide a reason");
      Swal.fire({
        title: 'Failed',
        text: 'Please provide a reason',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      return;
    }

    setLoading(true);
    try {
      const payload = {
        reason: rejectReason.trim(),
      };

      await apiFetch(
        `/api/visitor-invitations/${rejectId}/reject`,
        {
          method: "POST",
          body: JSON.stringify(payload),
        }
      );

      // toast.success("Invitation rejected");
      Swal.fire({
        title: 'Failed',
        text: 'Invitation rejected',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      setRejectId(null);
      setRejectReason("");
      // fetch(); // refresh list

    } catch (err: any) {
      // toast.error(err.message || "Something went wrong");
      Swal.fire({
        title: 'Error',
        text: 'Something went wrong',
        icon: 'error',
        confirmButtonText: 'OK'
      });
    } finally {
      setLoading(false);
    }
  };




  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (isReadOnly) return;
    const { name, value } = e.target;

    const REQUIRED_MESSAGES: Record<string, string> = {
      visitor_name: "Visitor name is required",
      visitor_email: "Email is required",
      visitor_phone: "Phone number is required",
      visit_start_date: "Start date is required",
      visit_end_date: "End date is required",
      visit_start_time: "Start time is required",
      visit_end_time: "End time is required",
      number_of_visitors: "Number of visitors is required",
    };


    if (REQUIRED_MESSAGES[name]) {
      if (!value.trim()) {
        setErrors((prev) => ({
          ...prev,
          [name]: REQUIRED_MESSAGES[name],
        }));
      } else {
        setErrors((prev) => {
          const copy = { ...prev };
          delete copy[name];
          return copy;
        });
      }
    }


    // ✅ INPUT RULES (CENTRALIZED)
    let sanitizedValue = value;

    switch (name) {
      case "visitor_name":
        // only letters and spaces, max 50
        if (!/^[a-zA-Z\s]*$/.test(value)) return;
        sanitizedValue = value.slice(0, 50);
        break;

      case "visitor_company":
        // alphanumeric and spaces, max 50
        if (!/^[a-zA-Z0-9\s]*$/.test(value)) return;
        sanitizedValue = value.slice(0, 50);
        break;

      case "visitor_phone":
        if (!/^\d*$/.test(value)) return;
        sanitizedValue = value.slice(0, 10);
        break;

      case "host_name":
        if (!/^[a-zA-Z\s]*$/.test(value)) return;
        sanitizedValue = value.slice(0, 50);
        break;

      default:
        sanitizedValue = value;
    }

    const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    // ✅ LIVE EMAIL VALIDATION while typing

    if (name === "visitor_email") {
      if (value.trim() && !EMAIL_REGEX.test(value)) {
        setErrors((prev) => ({
          ...prev,
          visitor_email: "Enter a valid email address",
        }));
      } else {
        setErrors((prev) => {
          const copy = { ...prev };
          delete copy.visitor_email;
          return copy;
        });
      }
    }

    if (name === "host_email") {
      if (!value.trim()) {
        setErrors(prev => ({
          ...prev,
          host_email: "Host email is required",
        }));
      } else {
        const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!EMAIL_REGEX.test(value)) {
          setErrors(prev => ({
            ...prev,
            host_email: "Enter a valid host email",
          }));
        } else {
          setErrors(prev => {
            const copy = { ...prev };
            delete copy.host_email;
            return copy;
          });
        }
      }
    }


    // ✅ CLEAR host_name error
    if (name === "host_name") {
      if (!value.trim()) {
        setErrors(prev => ({
          ...prev,
          host_name: "Host name is required"
        }));
      } else {
        setErrors(prev => {
          const copy = { ...prev };
          delete copy.host_name;
          return copy;
        });
      }
    }


    // ✅ All validation + update in a single setForm call
    const today = new Date().toISOString().split("T")[0];
    setForm((prev) => {
      const updated = { ...prev, [name]: value };
      let errorsToSet: Record<string, string> | null = null;
      let errorsToClear: string[] = [];

      // ── Date validation ──
      if (name === "visit_start_date") {
        if (restrictToDateOnly && value > today) {
          errorsToSet = { visit_start_date: "Start date cannot be a future date" };
          return prev;
        }
        if (restrictToDateOnly && prev.visit_end_date && prev.visit_end_date > value) {
          updated.visit_end_date = "";
        }
        errorsToClear.push("visit_start_date", "visit_end_date");
      }

      if (name === "visit_end_date") {
        if (restrictToDateOnly && value > today) {
          errorsToSet = { visit_end_date: "End date cannot be a future date" };
          return prev;
        }
        if (value < prev.visit_start_date) {
          errorsToSet = { visit_end_date: "End date cannot be before start date" };
          return prev;
        }
        errorsToClear.push("visit_end_date");
      }

      // ── Time validation ──
      if (name === "visit_start_time") {
        if (updated.visit_start_date === today) {
          const now = new Date();
          const currentTime = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
          if (value < currentTime) {
            errorsToSet = { visit_start_time: "Start time cannot be in the past" };
            return prev;
          }
        }
        errorsToClear.push("visit_start_time", "visit_end_time");
        // If new start_time makes end_time invalid, reset end_time
        if (updated.visit_start_date === updated.visit_end_date && updated.visit_end_time && updated.visit_end_time !== "00:00") {
          const endNum = updated.visit_end_time.replace(":", "");
          const startNum = updated.visit_start_time.replace(":", "");
          if (endNum <= startNum) {
            updated.visit_end_time = "";
          }
        }
      }

      if (name === "visit_end_time") {
        if (updated.visit_start_date === updated.visit_end_date && updated.visit_start_time && updated.visit_start_time !== "00:00") {
          const endNum = value.replace(":", "");
          const startNum = updated.visit_start_time.replace(":", "");
          if (endNum <= startNum) {
            errorsToSet = { visit_end_time: "End time must be after start time on the same day" };
            return prev;
          }
        }
        errorsToClear.push("visit_end_time");
      }

      // ── Apply error changes ──
      if (errorsToSet) {
        setErrors((prevErr) => ({ ...prevErr, ...errorsToSet }));
      } else {
        setErrors((prevErr) => {
          const copy = { ...prevErr };
          errorsToClear.forEach((k) => delete copy[k]);
          return copy;
        });
      }

      return updated;
    });
    return;
  };

  // const toggleRequirement = (req: string) => {
  //   setSelectedRequirements((prev) => (prev.includes(req) ? prev.filter((r) => r !== req) : [...prev, req]));
  // };

  const handleSubmit = async (status: "draft" | "approved") => {

    if (!validateForm()) {
      return;
    }

    if (form.visit_start_date && form.visit_end_date && form.visit_start_date === form.visit_end_date) {
      const start = form.visit_start_time?.replace(":", "");
      const end = form.visit_end_time?.replace(":", "");
      if (start && end && end <= start) {
        toast.error("End time must be after start time on the same day");
        return;
      }
    }

    if (
      !form.visitor_name ||
      !form.visit_start_date ||
      !form.visit_end_date ||
      !form.purpose ||
      !form.department.length
    ) {
      toast.error("Please fill in all required fields");
      return;
    }
    const departmentString = form.department.join(", ");

    if (departmentString.length > 200) {
      toast.error("Too many departments selected (max 100 characters)");
      return;
    }
    setLoading(true);
    try {

      const payload = {
        visitorName: form.visitor_name,
        visitorCompany: form.visitor_company,
        visitorEmail: form.visitor_email,
        visitorPhone: form.visitor_phone,

        visitStartDate: form.visit_start_date,
        visitEndDate: form.visit_end_date,

        visitStartTime:
          form.visit_start_time.length === 5
            ? `${form.visit_start_time}:00`
            : form.visit_start_time,

        visitEndTime:
          form.visit_end_time.length === 5
            ? `${form.visit_end_time}:00`
            : form.visit_end_time,

        purpose: form.purpose,
        purpose_others: form.purpose === "Others" ? form.purpose_others.trim() : "",
        department: departmentString,
        remarks: form.remarks || "",
        hostName: form.host_name,
        hostEmail: form.host_email,
        AdditionalVisitors: (additionalVisitors ?? []).map((v: any) => ({
          Id: v.id,
          Name: v.name || "",
          Email: v.email || "",
          Phone: v.phone || "",
          Company: v.company || "",
        })),
        visitorType: form.visitor_type,
        // additionalRequirements: selectedRequirements.join(", "),
        status,
        ...(!editData?.id ? { createdBy: user?.email?.trim().toLowerCase() ?? "" } : {}),
      };
      
      console.log("=== FULL PAYLOAD ===", JSON.stringify(payload, null, 2));
      console.log("=== ADDITIONAL VISITORS ===", payload.AdditionalVisitors);
      if (editData?.id) {
        await apiFetch(`/api/visitor-invitations/${editData.id}`, {
          method: "PUT",
          body: JSON.stringify(payload),
        });
        // toast.success("Invitation updated successfully");
        Swal.fire({
          title: 'Success',
          text: 'Invitation updated successfully',
          icon: 'success',
          confirmButtonText: 'OK'
        });
      } else {
        await apiFetch("/api/visitor-invitations", {
          method: "POST",
          body: JSON.stringify(payload),
        });

        Swal.fire({
          title: 'Success',
          text:
            status === "draft"
              ? "Draft saved successfully"
              : "Invitation submitted successfully",
          icon: 'success',
          confirmButtonText: 'OK'
        });
      }

      onSuccess();
    } catch (err: any) {
      Swal.fire({
        title: 'Error',
        text: err?.message || 'Something went wrong',
        icon: 'error',
        confirmButtonText: 'OK'
      });
      // toast.error(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-[95vw] sm:max-w-none">
      <CardHeader className="flex flex-row items-center justify-between flex-wrap gap-2">

        <CardTitle>
          {isApprovalMode
            ? managerEditEnabled
              ? "Edit Visitor Invitation"
              : "Review Visitor Invitation"
            : "Create Visitor Invitation"}
        </CardTitle>


        {/* ✅ Edit / Save Edit ONLY for approval review */}
        {isApprovalMode && editData?.id && !hideEditButton && (

          <Button
            variant="outline"
            size="sm"
            onClick={() => setManagerEditEnabled(true)}
          >
            Edit
          </Button>
        )}
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="visitor_name">Visitor Name <span className="text-red-500">*</span></Label>
            <Input
              ref={visitorNameRef}
              id="visitor_name"
              name="visitor_name"
              value={form.visitor_name}
              onChange={handleChange}
              placeholder="Full name"
              disabled={isReadOnly}
              maxLength={50}
            />
            {errors.visitor_name && (
              <p className="text-sm text-red-500">{errors.visitor_name}</p>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="visitor_company">Company</Label>
            <Input
              id="visitor_company"
              name="visitor_company"
              value={form.visitor_company}
              onChange={handleChange}
              placeholder="Company name"
              disabled={isReadOnly}
              maxLength={50}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="visitor_email">Email</Label>
            <Input
              ref={visitorEmailRef}
              id="visitor_email"
              name="visitor_email"
              type="email"
              value={form.visitor_email}
              onChange={handleChange}
              placeholder="visitor@example.com"
              disabled={isReadOnly}

            />
            {errors.visitor_email && (
              <p className="text-sm text-red-500">{errors.visitor_email}</p>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="visitor_phone">Phone <span className="text-red-500">*</span></Label>
            <Input
              ref={visitorPhone}
              id="visitor_phone"
              name="visitor_phone"
              type="tel"
              value={form.visitor_phone}
              onChange={handleChange}
              placeholder="+91 98765 43210"
              disabled={isReadOnly}
              maxLength={10}
            />
            {errors.visitor_phone && (
              <p className="text-sm text-red-500">{errors.visitor_phone}</p>
            )}
          </div>

          {/* Date & Time in a single row */}
          <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div className="space-y-2">
              <Label htmlFor="visit_start_date">Start Date <span className="text-red-500">*</span></Label>
              <Popover open={openStartDate} onOpenChange={setOpenStartDate}>
                <PopoverTrigger asChild>
                  <Button
                    id="visit_start_date"
                    variant={"outline"}
                    disabled={isReadOnly}
                    className={cn(
                      "w-full justify-start text-left font-normal h-9 min-w-0",
                      !form.visit_start_date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="w-3.5 h-3.5 mr-1.5 flex-shrink-0" />
                    {form.visit_start_date ? format(new Date(form.visit_start_date), "dd-MM-yyyy") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={form.visit_start_date ? new Date(form.visit_start_date) : undefined}
                    onSelect={(date) => {
                      if (!date || isReadOnly) return;
                      const dateStr = format(date, "yyyy-MM-dd");
                      setForm((prev) => {
                        const updated = { ...prev, visit_start_date: dateStr };
                        if (restrictToDateOnly && dateStr > prev.visit_end_date) {
                          updated.visit_end_date = "";
                        }
                        return updated;
                      });
                      setErrors((prev) => {
                        const copy = { ...prev };
                        delete copy.visit_start_date;
                        delete copy.visit_end_date;
                        return copy;
                      });
                      setOpenStartDate(false);
                    }}
                    disabled={(date) => {
                      if (restrictToDateOnly) return date > new Date();
                      return false;
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              {errors.visit_start_date && (
                <p className="text-sm text-red-500">{errors.visit_start_date}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="visit_end_date">End Date <span className="text-red-500">*</span></Label>
              <Popover open={openEndDate} onOpenChange={setOpenEndDate}>
                <PopoverTrigger asChild>
                  <Button
                    id="visit_end_date"
                    variant={"outline"}
                    disabled={isReadOnly}
                    className={cn(
                      "w-full justify-start text-left font-normal h-9 min-w-0",
                      !form.visit_end_date && "text-muted-foreground"
                    )}
                  >
                    <CalendarIcon className="w-3.5 h-3.5 mr-1.5 flex-shrink-0" />
                    {form.visit_end_date ? format(new Date(form.visit_end_date), "dd-MM-yyyy") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0" align="start">
                  <Calendar
                    mode="single"
                    selected={form.visit_end_date ? new Date(form.visit_end_date) : undefined}
                    onSelect={(date) => {
                      if (!date || isReadOnly) return;
                      const dateStr = format(date, "yyyy-MM-dd");
                      setForm((prev) => {
                        if (dateStr < prev.visit_start_date) {
                          return prev;
                        }
                        if (restrictToDateOnly && dateStr > new Date().toISOString().split("T")[0]) {
                          return prev;
                        }
                        return { ...prev, visit_end_date: dateStr };
                      });
                      setErrors((prev) => {
                        const copy = { ...prev };
                        delete copy.visit_end_date;
                        return copy;
                      });
                      setOpenEndDate(false);
                    }}
                    disabled={(date) => {
                      if (restrictToDateOnly) return date > new Date();
                      if (form.visit_start_date && date < new Date(form.visit_start_date)) return true;
                      return false;
                    }}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
              {errors.visit_end_date && (
                <p className="text-sm text-red-500">{errors.visit_end_date}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="visit_start_time">Start Time <span className="text-red-500">*</span></Label>
              <Input
                ref={startTimeRef}
                id="visit_start_time"
                name="visit_start_time"
                type="time"
                value={form.visit_start_time}
                onChange={handleChange}
                min={getMinStartTime()}   // ✅ ADD THIS LINE ONLY
                disabled={isReadOnly}
              />
              {errors.visit_start_time && (
                <p className="text-sm text-red-500">{errors.visit_start_time}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="visit_end_time">End Time <span className="text-red-500">*</span></Label>
              <Input
                ref={endTimeRef}
                id="visit_end_time"
                name="visit_end_time"
                type="time"
                min={form.visit_start_date && form.visit_end_date && form.visit_start_date === form.visit_end_date ? form.visit_start_time : undefined}
                value={form.visit_end_time}
                onChange={handleChange}
                disabled={isReadOnly}

              />
              {errors.visit_end_time && (
                <p className="text-sm text-red-500">{errors.visit_end_time}</p>
              )}
            </div>
          </div>

          <div className="space-y-2">
            <Label>Purpose of Visit <span className="text-red-500">*</span></Label>

            <Select
              value={form.purpose}
              onValueChange={(v) => {
                if (isReadOnly) return;

                setForm((prev) => ({
                  ...prev,
                  purpose: v,
                  // Clear "Others" remarks when switching away from "Others"
                  purpose_others: v === "Others" ? prev.purpose_others : "",
                }));

                // ✅ CLEAR purpose and purpose_others errors
                setErrors((prev) => {
                  const copy = { ...prev };
                  delete copy.purpose;
                  delete copy.purpose_others;
                  return copy;
                });
              }}
            >
              <SelectTrigger disabled={isReadOnly}>
                <SelectValue placeholder="Select purpose" />
              </SelectTrigger>
              <SelectContent>
                {[
                  "Meeting",
                  "Interview",
                  "International Client",
                  "Domestic Client",
                  "Vendor Visit",
                  "Audit / Inspection",
                  "Training / Workshop",
                  "Consulting",
                  "Site Tour / Facility Visit",
                  "Delivery / Pickup",
                  "Legal / Compliance",
                  "Board Meeting",
                  "Investor / Stakeholder Visit",
                  "Government / Regulatory",
                  "Personal Visit",
                  "Internship",
                  "Others",
                ].map((p) => (
                  <SelectItem key={p} value={p}>{p}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            {errors.purpose && (
              <p className="text-sm text-red-500">{errors.purpose}</p>
            )}

            {/* ✅ Others Purpose Text Area */}
            {form.purpose === "Others" && (
              <div className="space-y-2 mt-2">
                <Label>
                  Others Remarks <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="purpose_others"
                  name="purpose_others"
                  value={form.purpose_others}
                  onChange={(e) => {
                    if (isReadOnly) return;
                    const value = e.target.value;
                    if (value.length <= 500) {
                      setForm((prev) => ({ ...prev, purpose_others: value }));
                    }
                  }}
                  onBlur={() => {
                    if (isReadOnly) return;
                    const value = form.purpose_others?.trim() || "";
                    if (!value) {
                      setErrors((prev) => ({
                        ...prev,
                        purpose_others: "Please enter the purpose of visit.",
                      }));
                    } else if (value.length > 500) {
                      setErrors((prev) => ({
                        ...prev,
                        purpose_others: "Purpose of visit cannot exceed 500 characters.",
                      }));
                    } else if (!OTHERS_PURPOSE_REGEX.test(value)) {
                      setErrors((prev) => ({
                        ...prev,
                        purpose_others: 'Only letters, numbers, spaces, and standard business special characters (.,-_/&():;\'"%#@+=!?) are allowed.',
                      }));
                    } else {
                      setErrors((prev) => {
                        const copy = { ...prev };
                        delete copy.purpose_others;
                        return copy;
                      });
                    }
                  }}
                  maxLength={500}
                  rows={3}
                  placeholder="Enter purpose of visit..."
                  disabled={isReadOnly}
                  className="resize-y"
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>
                    {form.purpose_others?.length || 0} / 500 characters
                  </span>
                  {form.purpose_others && form.purpose_others.length > 450 && (
                    <span className="text-orange-500">Approaching limit</span>
                  )}
                </div>
                {errors.purpose_others && (
                  <p className="text-sm text-red-500">{errors.purpose_others}</p>
                )}
              </div>
            )}

          </div>
          <div className="space-y-1 space-x-2">
            <Label>Add Additional Visitors</Label>

            <Button
              // variant="outline"
              onClick={() => setVisitorDialogOpen(true)}
            >
              +
            </Button>
            {additionalVisitors.length > 0 && (
              <div className="overflow-x-auto rounded-md border mt-2">
                <table className="w-full min-w-[600px] text-sm">
                  <thead>
                    <tr className="bg-muted/50 text-left">
                      <th className="px-3 py-2 font-medium text-muted-foreground">Visitor Name</th>
                      <th className="px-3 py-2 font-medium text-muted-foreground">Visitor Email</th>
                      <th className="px-3 py-2 font-medium text-muted-foreground">Phone Number</th>
                      <th className="px-3 py-2 font-medium text-muted-foreground">Company</th>
                      <th className="px-3 py-2 font-medium text-muted-foreground">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {additionalVisitors.map((v, i) => (
                      <tr key={i}>
                        <td className="px-3 py-2">{v.name || "—"}</td>
                        <td className="px-3 py-2">{v.email || "—"}</td>
                        <td className="px-3 py-2">{v.phone || "—"}</td>
                        <td className="px-3 py-2">{v.company || "—"}</td>
                        <td className="px-3 py-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-red-500 hover:text-red-700 p-0 h-auto"
                            onClick={() => {
                              const updated = additionalVisitors.filter((_, idx) => idx !== i);
                              setAdditionalVisitors(updated);
                            }}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

          </div>
          <div className="space-y-2">
            <Label htmlFor="remarks">Remarks</Label>
            <Textarea
              id="remarks"
              name="remarks"
              value={form.remarks}
              onChange={(e) => {
                if (isReadOnly) return;
                const value = e.target.value;
                if (value.length <= 500) {
                  setForm((prev) => ({ ...prev, remarks: value }));
                }
              }}
              onBlur={() => {
                if (isReadOnly) return;
                const value = form.remarks?.trim() || "";
                if (value.length > 500) {
                  setErrors((prev) => ({
                    ...prev,
                    remarks: "Remarks cannot exceed 500 characters.",
                  }));
                } else if (value && !OTHERS_PURPOSE_REGEX.test(value)) {
                  setErrors((prev) => ({
                    ...prev,
                    remarks: 'Only letters, numbers, spaces, and standard business special characters (.,-_/&():;\'"%#@+=!?) are allowed.',
                  }));
                } else {
                  setErrors((prev) => {
                    const copy = { ...prev };
                    delete copy.remarks;
                    return copy;
                  });
                }
              }}
              maxLength={500}
              rows={3}
              placeholder="Any additional remarks (optional)"
              disabled={isReadOnly}
              className="overflow-y-auto resize-y"
            />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>
                {form.remarks?.length || 0} / 500 characters
              </span>
              {form.remarks && form.remarks.length > 450 && (
                <span className="text-orange-500">Approaching limit</span>
              )}
            </div>
            {errors.remarks && (
              <p className="text-sm text-red-500">{errors.remarks}</p>
            )}
          </div>
          <div
            className="space-y-2 relative"
            onClick={(e) => e.stopPropagation()}
          >
            <Label>Department to Visit <span className="text-red-500">*</span></Label>

            <div
              className={`border rounded-md px-3 py-2 cursor-pointer bg-background text-sm font-normal ${isReadOnly ? "bg-muted cursor-not-allowed" : "bg-background"
                }`}
              onClick={(e) => {
                e.stopPropagation();
                if (!isReadOnly) setIsDeptOpen((prev) => !prev);
              }}
            >
              {form.department.length > 0
                ? form.department.join(", ")
                : "Select department"}
            </div>

            {isDeptOpen && !isReadOnly && (
              <div
                className="absolute z-20 mt-1 w-full border rounded-md bg-popover text-popover-foreground shadow-lg max-h-40 overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                {DEPARTMENTS.map((dept) => (
                  <div
                    key={dept}
                    className="flex items-center gap-2 px-2 py-1.5 hover:bg-accent cursor-pointer text-sm font-normal"
                  >
                    <input
                      type="checkbox"
                      checked={form.department.includes(dept)}
                      onChange={() => {
                        setForm((prev) => {
                          const updated = prev.department.includes(dept)
                            ? prev.department.filter((d) => d !== dept)
                            : [...prev.department, dept];

                          return { ...prev, department: updated };
                        });

                        setErrors(prev => {
                          const copy = { ...prev };
                          delete copy.department;
                          return copy;
                        });
                      }}

                    />
                    <Label className="cursor-pointer font-normal text-sm">{dept}</Label>
                  </div>
                ))}
              </div>
            )}

            {errors.department && (
              <p className="text-sm text-red-500">{errors.department}</p>
            )}
          </div>
          <div className="space-y-2">
            <Label htmlFor="host_name">Host Name <span className="text-red-500">*</span></Label>
            <Input
              ref={hostNameRef}
              id="host_name"
              name="host_name"
              value={form.host_name}
              onChange={handleChange}
              placeholder="Employee name"
              disabled={isReadOnly}
              maxLength={50}
            />
            {errors.host_name && (
              <p className="text-sm text-red-500">{errors.host_name}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="host_email">Host Email <span className="text-red-500">*</span></Label>
            <Input
              ref={hostEmailRef}
              id="host_email"
              name="host_email"
              type="email"
              value={form.host_email}
              onChange={handleChange}
              placeholder="employee@company.com"
              disabled={isReadOnly}
            />
            {errors.host_email && (
              <p className="text-sm text-red-500">{errors.host_email}</p>
            )}
          </div>
          <div className="space-y-2">
            <Label>Visitor Type <span className="text-red-500">*</span></Label>

            <div className="flex gap-6">
              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="visitor_type"
                  value="Recurring"
                  checked={form.visitor_type === "Recurring"}
                  onChange={(e) =>
                    !isReadOnly &&
                    setForm((prev) => ({ ...prev, visitor_type: e.target.value }))
                  }
                  disabled={restrictToDateOnly || isReadOnly}
                />
                <Label className="font-normal cursor-pointer">Recurring</Label>
              </label>

              <label className="flex items-center gap-2">
                <input
                  type="radio"
                  name="visitor_type"
                  value="Non-Recurring"
                  checked={form.visitor_type === "Non-Recurring"}
                  onChange={(e) =>
                    !isReadOnly &&
                    setForm((prev) => ({ ...prev, visitor_type: e.target.value }))
                  }
                  disabled={isReadOnly}
                />
                <Label className="font-normal cursor-pointer">Non-Recurring</Label>
              </label>
            </div>
            {errors.visitor_type && (
              <p className="text-sm text-red-500">{errors.visitor_type}</p>
            )}
          </div>

          {/* Additional Requirements as checkboxes */}
          {/* <div className="space-y-3 md:col-span-2">
            <Label>Additional Requirements</Label>
            <div className="flex flex-wrap gap-4">
              {ADDITIONAL_OPTIONS.map((opt) => (
                <div key={opt} className="flex items-center space-x-2">
                  <Checkbox
                    id={`req-${opt}`}
                    checked={selectedRequirements.includes(opt)}
                    onCheckedChange={() => toggleRequirement(opt)}
                    disabled={isReadOnly}
                  />
                  <Label htmlFor={`req-${opt}`} className="font-normal cursor-pointer">
                    {opt}
                  </Label>
                </div>
              ))}
            </div>
          </div> */}
        </div>
        <div className="flex flex-wrap gap-3 mt-6">
          {/* ✅ CREATE OR EDIT (normal form usage) */}
          {!isApprovalMode && !managerEditEnabled && (
            <>
              <Button
                variant="outline"
                disabled={loading}
                onClick={() => handleSubmit("draft")}
              >
                Save as Draft
              </Button>

              <Button
                disabled={loading}
                onClick={() => handleSubmit("approved")}
              >
                Submit
              </Button>
            </>
          )}

          {/* ✅ APPROVAL MODE → EDIT ENABLED */}
          {isApprovalMode && managerEditEnabled && !managerEditEnabled && (
            <>
              <Button
                variant="outline"
                disabled={loading}
                onClick={() => handleSubmit("draft")}
              >
                Save as Draft
              </Button>

              <Button
                disabled={loading}
                onClick={() => handleSubmit("approved")}
              >
                Submit
              </Button>
            </>
          )}

          {isApprovalMode && editData?.id && managerEditEnabled && (
            <>
              <Button
                variant="outline"
                disabled={loading}
                onClick={async () => {
                  if (managerEditEnabled) {
                    try {
                      await apiFetch(`/api/visitor-invitations/${editData.id}`, {
                        method: "PUT",
                        body: JSON.stringify({
                          visitorName: form.visitor_name,
                          visitorCompany: form.visitor_company || "",
                          visitorEmail: form.visitor_email,
                          visitorPhone: form.visitor_phone || "",
                          visitStartDate: formatDateOnly(form.visit_start_date),
                          visitEndDate: formatDateOnly(form.visit_end_date),
                          visitStartTime: toTimeSpan(form.visit_start_time),
                          visitEndTime: toTimeSpan(form.visit_end_time),
                          purpose: form.purpose,
                          purpose_others: form.purpose === "Others" ? form.purpose_others.trim() : "",
                          numberOfVisitors: Number(form.number_of_visitors || 1),
                          remarks: form.remarks || "",
                          department: form.department.join(", "),
                          visitorType: form.visitor_type,
                          // additionalRequirements: selectedRequirements.join(", "),
                        }),
                      });
                      // toast.success("Changes saved");
                      Swal.fire({
                        title: 'Success',
                        text: 'Changes saved',
                        icon: 'success',
                        confirmButtonText: 'OK'
                      });
                      setManagerEditEnabled(false);
                    } catch (e: any) {
                      toast.error(e.message || "Failed to save edits");
                    }
                  } else {
                    setManagerEditEnabled(true);
                  }
                }}
              >
                Update/Edit
              </Button>

              <Button
                disabled={loading}
                onClick={() => handleSubmit("approved")}
              >
                Cancel
              </Button>
            </>
          )}

          {/* ✅ APPROVAL MODE → DEFAULT (read‑only) */}
          {isApprovalMode && !managerEditEnabled && editData?.id && (
            <>
              <Button
                onClick={async () => {
                  await apiFetch(
                    `/api/visitor-invitations/${editData.id}/approve`,
                    { method: "POST" }
                  );
                  toast.success("Invitation approved");
                  onSuccess();
                }}
              >
                Approve
              </Button>

              <Button variant="destructive" size="sm" onClick={() => setRejectId(editData.id)}>
                <XCircle className="w-3 h-3 mr-1" /> Reject
              </Button>

              <Dialog
                open={!!rejectId}
                onOpenChange={(open) => {
                  if (!open) {
                    setRejectId(null);
                    setRejectReason("");
                  }
                }}
              >
                <DialogContent className="max-w-md">

                  <DialogHeader>
                    <DialogTitle className="text-lg font-semibold text-destructive">
                      Reject Invitation
                    </DialogTitle>
                  </DialogHeader>

                  <div className="space-y-3">
                    <Label className="text-sm font-medium">
                      Reason for rejection
                    </Label>

                    <Textarea
                      value={rejectReason}
                      onChange={(e) => setRejectReason(e.target.value)}
                      placeholder="Please provide a reason..."
                      className="resize-none"
                      rows={3}
                      autoFocus
                    />
                  </div>

                  <DialogFooter className="mt-4 flex justify-end gap-2">
                    <Button
                      variant="outline"
                      onClick={() => {
                        setRejectId(null);
                        setRejectReason("");
                      }}
                    >
                      Cancel
                    </Button>

                    <Button
                      variant="destructive"
                      disabled={!rejectReason.trim()}
                      onClick={handleReject}
                    >
                      Reject
                    </Button>
                  </DialogFooter>

                </DialogContent>
              </Dialog>
            </>
          )}
        </div>
      </CardContent>
      <VisitorManagerDialog
        open={visitorDialogOpen}
        onClose={() => setVisitorDialogOpen(false)}
        invitationId={null} // not needed here
        existingVisitors={additionalVisitors}

        mainVisitor={{
          visitorName: form.visitor_name,
          visitorEmail: form.visitor_email,
          visitorPhone: form.visitor_phone,
          visitorCompany: form.visitor_company
        }}

        onSave={(updated) => {
          if (updated.length > 10) {
            // alert("Maximum 5 visitors allowed");
            return;
          }

          setAdditionalVisitors(updated);
          setVisitorDialogOpen(false);
        }}
      />

    </Card>

  );
}
