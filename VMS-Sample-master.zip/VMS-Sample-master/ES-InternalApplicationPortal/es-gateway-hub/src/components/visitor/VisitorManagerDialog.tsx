import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Trash2 } from "lucide-react";
import Swal from "sweetalert2";
import { Label } from "@/components/ui/label";

type Visitor = {
  id?: number;
  name: string;
  email: string;
  phone: string;
  company?: string;
  isNew?: boolean;
  isEdited?: boolean;
};

/** ✅ VALIDATION FUNCTION */
const validateVisitor = (visitor: Visitor) => {
  const errors: Record<string, string> = {};

  if (!visitor.name?.trim()) {
    errors.name = "Name is required";
  }

  if (visitor.email && !/\S+@\S+\.\S+/.test(visitor.email)) {
    errors.email = "Invalid email format";
  }

  if (!visitor.phone?.trim()) {
    errors.phone = "Phone number is required";
  } else if (!/^\d{10}$/.test(visitor.phone)) {
    errors.phone = "Phone must be 10 digits";
  }

  return errors;
};

export function VisitorManagerDialog({
  open,
  onClose,
  invitationId,
  existingVisitors,
  mainVisitor,
  onSave
}) {
  const emptyVisitor: Visitor = {
    id: undefined,
    name: "",
    email: "",
    phone: "",
    company: "",
    isNew: true
  };

  const [visitors, setVisitors] = useState<Visitor[]>([]);
  const [newVisitor, setNewVisitor] = useState<Visitor>(emptyVisitor);

  const [errors, setErrors] = useState<{ visitor_additional?: string }>({});
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (open) {
      setVisitors(existingVisitors || []);
    }
  }, [open, existingVisitors]);


  useEffect(() => {
    if (open) {
      setVisitors(existingVisitors || []);
    } else {
      // ✅ Reset everything when dialog closes
      setVisitors([]);
      setNewVisitor(emptyVisitor);
      setErrors({});
      setFieldErrors({});
    }
  }, [open, existingVisitors]);


  /** ✅ ADD */
  const handleAdd = () => {
    const validationErrors = validateVisitor(newVisitor);

    if (Object.keys(validationErrors).length > 0) {
      setFieldErrors(validationErrors);
      return;
    }

    setFieldErrors({});
    setErrors({ visitor_additional: "" });
    if (visitors.length >= 10) {
      // Swal.fire("Limit reached", "Maximum 10 visitors allowed", "warning");
      setErrors({ visitor_additional: "Maximum 10 Additional visitors allowed." });
      return;
    }

    // const isDuplicate = visitors.some(
    //   v => v.email === newVisitor.email || v.phone === newVisitor.phone
    // );

    // if (isDuplicate) {
    //   setErrors({ visitor_additional: "Duplicate phone number" });
    //   return;
    // }

    setVisitors(prev => [
      ...prev,
      {
        ...newVisitor,
        id: 0,
        isNew: true
      }
    ]);
    setNewVisitor(emptyVisitor);
  };

  /** ✅ REMOVE */
  const handleRemove = async (id?: number) => {
    if (!id) return;

    setVisitors(prev => prev.filter(v => v.id !== id));
  };

  /** ✅ EDIT */
  const handleEdit = (id: number, field: string, value: string) => {
    if (field === "email" || field === "phone") {
      const isDuplicate = visitors.some(
        v =>
          v.id !== id &&
          ((field === "email" && v.email === value) ||
            (field === "phone" && v.phone === value))
      );

      if (isDuplicate) {
        Swal.fire("Duplicate", `${field} already exists`, "error");
        return;
      }
    }

    setVisitors(prev =>
      prev.map(v =>
        v.id === id ? { ...v, [field]: value, isEdited: true } : v
      )
    );
  };

  /** ✅ SAVE */
  const handleSave = async () => {
    if (!visitors.length && !mainVisitor) {
      setErrors({ visitor_additional: "Please add at least one visitor." });
      return;
    }

    for (let v of visitors) {
      const err = validateVisitor(v);

      if (Object.keys(err).length > 0) {
        Swal.fire(
          "Invalid Visitor",
          `${v.name || "Visitor"}: ${Object.values(err)[0]}`,
          "error"
        );
        return;
      }
    }

    setErrors({});
    await onSave(visitors);
    onClose();
  };

  const handleClose = () => {
    setVisitors([]);
    setNewVisitor(emptyVisitor);
    setErrors({});
    setFieldErrors({});
    onClose();
  };


  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="flex max-h-[90vh] max-w-[95vw] w-full sm:w-[850px] flex-col gap-0 overflow-hidden p-0 
  [&>button]:text-black 
  [&>button:hover]:text-red-600 
  [&>button]:transition-colors">
        <DialogHeader className="bg-muted border-b px-6 py-3">
          <DialogTitle>Add/Remove Additional Visitors</DialogTitle>
        </DialogHeader>

        <div className="flex-1 space-y-4 overflow-y-auto px-6 py-3">
          {/* ✅ FORM */}
          <div className="border p-3 rounded space-y-3">

            {/* Name */}
            <div className="space-y-2">
              <Label htmlFor="visitor_email">Name <span className="text-red-500">*</span></Label>

              <input
                placeholder="Enter name"
                value={newVisitor.name}
                onChange={e => {
                  const value = e.target.value;

                  setNewVisitor({ ...newVisitor, name: value });

                  // ✅ validate instantly
                  if (!value.trim()) {
                    setFieldErrors(prev => ({ ...prev, name: "Name is required" }));
                  } else {
                    setFieldErrors(prev => ({ ...prev, name: "" }));
                  }
                }}
                className={`border p-2 w-full rounded-md ${fieldErrors.name ? "border-red-500" : ""}`}
              />

              {fieldErrors.name && <p className="text-red-500 text-xs">{fieldErrors.name}</p>}
            </div>
            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="visitor_email">Email</Label>
              <input
                placeholder="Email"
                value={newVisitor.email}

                onChange={e => {
                  const value = e.target.value;

                  setNewVisitor({ ...newVisitor, email: value });

                  setErrors(prev => ({ ...prev, visitor_additional: "" }));

                  if (value && !/\S+@\S+\.\S+/.test(value)) {
                    setFieldErrors(prev => ({ ...prev, email: "Invalid email format" }));
                  } else {
                    setFieldErrors(prev => ({ ...prev, email: "" }));
                  }
                }}

                className={`border p-2 w-full rounded-md ${fieldErrors.email ? "border-red-500" : ""}`}
              />
              {fieldErrors.email && <p className="text-red-500 text-xs">{fieldErrors.email}</p>}
            </div>
            {/* Phone */}
            <div className="space-y-2">
              <Label htmlFor="visitor_email">Phone Number <span className="text-red-500">*</span></Label>
              <input
                placeholder="Phone"
                value={newVisitor.phone}
                onChange={e => {
                  let value = e.target.value.replace(/\D/g, "");

                  // ✅ limit to 10 digits
                  if (value.length > 10) {
                    value = value.slice(0, 10);
                  }

                  setNewVisitor({ ...newVisitor, phone: value });

                  if (!value.trim()) {
                    setFieldErrors(prev => ({ ...prev, phone: "Phone number is required" }));
                  } else if (value.length !== 10) {
                    setFieldErrors(prev => ({ ...prev, phone: "Phone must be 10 digits" }));
                  } else {
                    setFieldErrors(prev => ({ ...prev, phone: "" }));
                  }
                }}
                className={`border p-2 w-full rounded-md ${fieldErrors.phone ? "border-red-500" : ""}`}
              />
              {fieldErrors.phone && <p className="text-red-500 text-xs">{fieldErrors.phone}</p>}
            </div>
            {/* Company */}
            <div className="space-y-2">
              <Label htmlFor="visitor_email">Company</Label>
              <input
                placeholder="Company"
                value={newVisitor.company}
                onChange={e =>
                  setNewVisitor({ ...newVisitor, company: e.target.value })
                }
                className="border p-2 w-full rounded-md"
              />
            </div>
            <Button type="button" onClick={handleAdd}>
              + Add Visitor
            </Button>
          </div>

          {errors.visitor_additional && (
            <p className="text-sm text-red-500">{errors.visitor_additional}</p>
          )}

          {/* ✅ TABLE */}
          {visitors.length > 0 && (
            <div className="border rounded max-h-[250px] overflow-x-auto">
              <table className="w-full min-w-[600px] text-sm">
                <thead>
                  <tr className="bg-muted/50 text-left">
                    <th className="px-3 py-2 font-medium text-muted-foreground">Visitor Name</th>
                    <th className="px-3 py-2 font-medium text-muted-foreground">Visitor Email</th>
                    <th className="px-3 py-2 font-medium text-muted-foreground">Phone Number</th>
                    <th className="px-3 py-2 font-medium text-muted-foreground">Company</th>
                    <th className="px-3 py-2 font-medium text-muted-foreground">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {mainVisitor && (
                    <tr className="bg-blue-50 font-semibold">
                      <td className="px-3 py-2">{mainVisitor.visitorName}</td>
                      <td className="px-3 py-2">{mainVisitor.visitorEmail}</td>
                      <td className="px-3 py-2">{mainVisitor.visitorPhone}</td>
                      <td className="px-3 py-2">{mainVisitor.visitorCompany}</td>
                      <td className="px-3 py-2">Main</td>
                    </tr>
                  )}

                  {visitors.map(v => (
                    <tr key={v.id}>
                      <td className="px-3 py-2">
                        <input value={v.name} onChange={e => handleEdit(v.id!, "name", e.target.value)} />
                      </td>
                      <td className="px-3 py-2">
                        <input value={v.email} onChange={e => handleEdit(v.id!, "email", e.target.value)} />
                      </td>
                      <td className="px-3 py-2">
                        <input value={v.phone} onChange={e => handleEdit(v.id!, "phone", e.target.value.replace(/\D/g, ""))} />
                      </td>
                      <td className="px-3 py-2">
                        <input value={v.company} onChange={e => handleEdit(v.id!, "company", e.target.value)} />
                      </td>
                      <td className="px-3 py-2">
                        <Button
                          type="button"
                          className="bg-white hover:bg-gray-100 text-red-500"
                          onClick={() => handleRemove(v.id!)}
                          title="Remove"
                        >
                          <Trash2 />
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

        </div>

        <div className="flex justify-end gap-4 px-6 pb-4 pt-0">
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button type="button" onClick={handleSave}>
            Save
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}