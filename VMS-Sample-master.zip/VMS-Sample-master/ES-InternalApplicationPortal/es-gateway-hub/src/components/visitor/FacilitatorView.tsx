import { useEffect, useState, useMemo } from "react";
// import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import VisitorPhoto from "./VisitorPhoto";
import {
  InvitationFilters,
  filterInvitations,
  type InvitationFilter,
} from "./InvitationFilters";
import { Checkbox } from "@/components/ui/checkbox";
const API_BASE = import.meta.env.VITE_API_URL;

const SERVICES = [
  { key: "wifi", label: "Wi‑Fi access" },
  { key: "parking", label: "Parking" },
  { key: "meeting_room", label: "Meeting Room" },
  { key: "pickup_drop", label: "Pickup and Drop" },
  { key: "stay", label: "Stay" },
  { key: "food", label: "Food" },
];

export function FacilitatorView() {
  const [invitations, setInvitations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editingNotes, setEditingNotes] = useState<Record<string, string>>({});
  const [localServices, setLocalServices] = useState<
    Record<string, Record<string, boolean>>
  >({}); // ✅ LOCAL ONLY
  const [filter, setFilter] = useState<InvitationFilter>({
    date: undefined,
    status: "all",
  });

  const FAC_STATUS_OPTIONS = [
    { value: "approved", label: "Approved" },
    { value: "checked_in", label: "Checked In" },
    { value: "checked_out", label: "Checked Out" },
  ];

  const filtered = useMemo(
    () => filterInvitations(invitations, filter),
    [invitations, filter]
  );


  function mapRequirementsToServices(requirements: string[] = []) {
    const serviceMap: Record<string, boolean> = {};

    SERVICES.forEach((service) => {
      serviceMap[service.key] = requirements.includes(service.key);
    });

    return serviceMap;
  }

  function normalizeRequirementsFromDb(value: string): string[] {
    return value
      .split(",")
      .map(v => v.trim().toLowerCase())
      .map(v => {
        if (v.includes("wifi")) return "wifi";
        if (v.includes("parking")) return "parking";
        if (v.includes("meeting")) return "meeting_room";
        if (v.includes("pickup")) return "pickup_drop";
        if (v.includes("stay")) return "stay";
        if (v.includes("food")) return "food";
        return "";
      })
      .filter(Boolean);
  }

  const fetchData = async () => {
    setLoading(true);

    try {
      // const {
      //   data: { session },
      // } = await supabase.auth.getSession();

      // const accessToken = session?.access_token;
      // if (!accessToken) throw new Error("No access token");

      const res = await fetch(
        `${API_BASE}/api/visitor-invitations?status=approved,checked_in,checked_out`,
        {
          headers: {
            // Authorization: `Bearer ${accessToken}`,
            "Content-Type": "application/json",
          },
        }
      );

      if (!res.ok) throw new Error("Failed to load invitations");

      const data = await res.json();
      console.log("sadfsdf", data);
      const sortedData = [...data].sort(
        (a, b) =>
          new Date(a.visit_start_date).getTime() -
          new Date(b.visit_start_date).getTime()
      );


      setInvitations(sortedData);

      // ✅ INITIALIZE CHECKBOX STATE FROM DB
      const servicesState: Record<string, Record<string, boolean>> = {};

      sortedData.forEach((inv) => {

        const normalizedRequirements =
          typeof inv.additional_requirements === "string"
            ? normalizeRequirementsFromDb(inv.additional_requirements)
            : [];

        servicesState[inv.id] = mapRequirementsToServices(normalizedRequirements);

      });

      setLocalServices(servicesState);
    } catch (error) {
      console.error(error);
      toast.error("Failed to load visitor invitations");
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    fetchData();
  }, []);

function getSelectedFacilities(
  services: Record<string, boolean>
): string[] {
  return Object.entries(services)
    .filter(([_, checked]) => checked)
    .map(([key]) => key);
}

 
const handleSaveNotes = async (id: string) => {
  try {
    // const {
    //   data: { session },
    // } = await supabase.auth.getSession();

    // const accessToken = session?.access_token;
    // if (!accessToken) throw new Error("No access token");

    const selectedFacilities = getSelectedFacilities(
      localServices[id] ?? {}
    );

    const res = await fetch(
      `${API_BASE}/api/visitor-invitations/${id}/facilitator-notes`,
      {
        method: "POST",
        headers: {
          // Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          notes: editingNotes[id],
          facilities: selectedFacilities,
        }),
      }
    );

    if (!res.ok) throw new Error(await res.text());

    toast.success("Notes & facilities saved");

    setEditingNotes((prev) => {
      const updated = { ...prev };
      delete updated[id];
      return updated;
    });

    fetchData();
  } catch (err: any) {
    toast.error(err.message || "Failed to save notes");
  }
};


  if (loading)
    return <p className="text-muted-foreground">Loading…</p>;

  if (invitations.length === 0)
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          No approved visitor invitations.
        </CardContent>
      </Card>
    );

  return (
    <div className="space-y-4">
      <InvitationFilters
        filter={filter}
        onChange={setFilter}
        statusOptions={FAC_STATUS_OPTIONS}
      />

      {filtered.map((inv) => {
        const services = localServices[inv.id] ?? {};

        return (
          <Card key={inv.id}>
            <CardContent className="py-4 space-y-4">
              {/* HEADER */}
              <div className="flex gap-4">
                <VisitorPhoto
                  photoUrl={inv.visitor_photo_url}
                  name={inv.visitor_name}
                />

                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="font-semibold">{inv.visitor_name}</h3>
                    <Badge className="bg-green-100 text-green-800">
                      {inv.status.replace("_", " ")}
                    </Badge>
                  </div>

                  <p className="text-sm text-muted-foreground">
                    {inv.visitor_company && `${inv.visitor_company} · `}
                    {inv.department} · {inv.purpose}
                  </p>

                  <p className="text-xs text-muted-foreground">
                    {inv.visit_start_date} to {inv.visit_end_date} ·{" "}
                    {inv.visit_start_time} – {inv.visit_end_time}
                  </p>

                  {inv.additional_requirements && (
                    <p className="text-sm text-muted-foreground">
                      Requirements: {inv.additional_requirements}
                    </p>
                  )}
                </div>
              </div>

              {/* ✅ NOTES (UNCHANGED) */}
              <Textarea
                placeholder="Add facilitator notes (e.g., arrangements made, room booked)..."
                value={editingNotes[inv.id] ?? inv.facilitator_notes ?? ""}
                onChange={(e) =>
                  setEditingNotes((prev) => ({
                    ...prev,
                    [inv.id]: e.target.value,
                  }))
                }
              />

              {/* ✅ ✅ CHECKBOXES ADDED HERE */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {SERVICES.map((s) => (
                  <label
                    key={s.key}
                    className="flex items-center gap-2 text-sm"
                  >
                    <Checkbox
                      checked={!!services[s.key]}
                      onCheckedChange={(checked) =>
                        setLocalServices((prev) => ({
                          ...prev,
                          [inv.id]: {
                            ...(prev[inv.id] ?? {}),
                            [s.key]: checked === true,
                          },
                        }))
                      }
                    />
                    {s.label}
                  </label>
                ))}
              </div>

              {/* ✅ SAVE NOTES BUTTON (UNCHANGED) */}
              {editingNotes[inv.id] !== undefined &&
                editingNotes[inv.id] !== (inv.facilitator_notes ?? "") && (
                  <Button size="sm" onClick={() => handleSaveNotes(inv.id)}>
                    Save Notes
                  </Button>
                )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}