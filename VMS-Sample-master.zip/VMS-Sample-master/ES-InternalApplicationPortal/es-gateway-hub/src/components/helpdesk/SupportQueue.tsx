import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { Clock, CheckCircle, Loader2, AlertTriangle, Play, Check, Ticket } from 'lucide-react';

const STATUS_CONFIG: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline'; icon: typeof Clock }> = {
  open: { label: 'Open', variant: 'destructive', icon: Clock },
  in_progress: { label: 'In Progress', variant: 'secondary', icon: Loader2 },
  resolved: { label: 'Resolved', variant: 'outline', icon: CheckCircle },
  closed: { label: 'Closed', variant: 'outline', icon: CheckCircle },
};

const PRIORITY_CONFIG: Record<string, { label: string; className: string }> = {
  low: { label: 'Low', className: 'bg-muted text-muted-foreground' },
  medium: { label: 'Medium', className: 'bg-yellow-100 text-yellow-800' },
  high: { label: 'High', className: 'bg-orange-100 text-orange-800' },
  critical: { label: 'Critical', className: 'bg-destructive/10 text-destructive' },
};

const CATEGORY_LABELS: Record<string, string> = {
  it_hardware: 'IT – Hardware',
  it_software: 'IT – Software',
  it_network: 'IT – Network',
  facilities: 'Facilities',
  hr: 'HR',
  admin: 'Admin',
  other: 'Other',
};

export const SupportQueue = () => {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('active');
  const [resolveDialog, setResolveDialog] = useState<any | null>(null);
  const [resolutionNotes, setResolutionNotes] = useState('');
  const [updating, setUpdating] = useState(false);

  const fetchTickets = async () => {
    if (!user) return;
    setLoading(true);
    let query = supabase.from('helpdesk_tickets' as any).select('*').order('created_at', { ascending: false });

    if (filter === 'active') {
      query = query.in('status', ['open', 'in_progress']);
    } else if (filter !== 'all') {
      query = query.eq('status', filter);
    }

    const { data } = await query;
    setTickets((data as any[]) || []);
    setLoading(false);
  };

  useEffect(() => { fetchTickets(); }, [user, filter]);

  const updateStatus = async (ticketId: string, status: string, notes?: string) => {
    setUpdating(true);
    const updates: any = { status, updated_at: new Date().toISOString() };
    if (status === 'resolved' || status === 'closed') {
      updates.resolved_at = new Date().toISOString();
      updates.resolved_by = user?.id;
      if (notes) updates.resolution_notes = notes;
    }

    const { error } = await supabase.from('helpdesk_tickets' as any).update(updates).eq('id', ticketId);
    setUpdating(false);
    if (error) {
      toast.error('Update failed', { description: error.message });
    } else {
      toast.success(`Ticket ${status === 'in_progress' ? 'picked up' : status}`);
      setResolveDialog(null);
      setResolutionNotes('');
      fetchTickets();
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Filter */}
      <div className="flex items-center gap-3">
        <Label className="text-sm">Filter:</Label>
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="active">Active (Open / In Progress)</SelectItem>
            <SelectItem value="open">Open</SelectItem>
            <SelectItem value="in_progress">In Progress</SelectItem>
            <SelectItem value="resolved">Resolved</SelectItem>
            <SelectItem value="closed">Closed</SelectItem>
            <SelectItem value="all">All</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {tickets.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <Ticket className="w-12 h-12 text-muted-foreground/50 mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-1">No tickets found</h3>
            <p className="text-sm text-muted-foreground">No tickets match the current filter.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {tickets.map((ticket: any) => {
            const status = STATUS_CONFIG[ticket.status] || STATUS_CONFIG.open;
            const priority = PRIORITY_CONFIG[ticket.priority] || PRIORITY_CONFIG.medium;
            const StatusIcon = status.icon;

            return (
              <Card key={ticket.id} className="hover:border-primary/30 transition-colors">
                <CardContent className="p-4 sm:p-5">
                  <div className="flex flex-col gap-3">
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-xs font-mono text-muted-foreground">{ticket.ticket_number}</span>
                          <Badge variant={status.variant} className="gap-1 text-xs">
                            <StatusIcon className="w-3 h-3" />
                            {status.label}
                          </Badge>
                          <Badge className={`text-xs ${priority.className}`}>
                            {ticket.priority === 'critical' && <AlertTriangle className="w-3 h-3 mr-0.5" />}
                            {priority.label}
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {CATEGORY_LABELS[ticket.category] || ticket.category}
                          </Badge>
                        </div>
                        <h3 className="font-medium text-foreground">{ticket.title}</h3>
                        {ticket.description && (
                          <p className="text-sm text-muted-foreground line-clamp-2">{ticket.description}</p>
                        )}
                        <p className="text-xs text-muted-foreground">
                          Created {format(new Date(ticket.created_at), 'dd MMM yyyy, HH:mm')}
                        </p>
                      </div>

                      {/* Actions */}
                      {(ticket.status === 'open' || ticket.status === 'in_progress') && (
                        <div className="flex gap-2 flex-shrink-0">
                          {ticket.status === 'open' && (
                            <Button size="sm" variant="outline" onClick={() => updateStatus(ticket.id, 'in_progress')} disabled={updating}>
                              <Play className="w-3 h-3 mr-1" /> Pick Up
                            </Button>
                          )}
                          <Button size="sm" onClick={() => { setResolveDialog(ticket); setResolutionNotes(''); }} disabled={updating}>
                            <Check className="w-3 h-3 mr-1" /> Resolve
                          </Button>
                        </div>
                      )}
                    </div>

                    {ticket.resolution_notes && (
                      <div className="p-3 rounded-lg bg-muted/50 text-sm space-y-1">
                        <p className="font-medium text-xs text-muted-foreground">Resolution</p>
                        <p className="text-foreground">{ticket.resolution_notes}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Resolve Dialog */}
      <Dialog open={!!resolveDialog} onOpenChange={(open) => { if (!open) setResolveDialog(null); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Resolve Ticket</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-sm text-muted-foreground">
              Resolving: <strong>{resolveDialog?.title}</strong>
            </p>
            <div className="space-y-2">
              <Label>Resolution Notes</Label>
              <Textarea
                placeholder="Describe how the issue was resolved…"
                value={resolutionNotes}
                onChange={(e) => setResolutionNotes(e.target.value)}
                rows={4}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setResolveDialog(null)}>Cancel</Button>
            <Button onClick={() => updateStatus(resolveDialog.id, 'resolved', resolutionNotes)} disabled={updating}>
              {updating ? 'Resolving…' : 'Mark as Resolved'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};
