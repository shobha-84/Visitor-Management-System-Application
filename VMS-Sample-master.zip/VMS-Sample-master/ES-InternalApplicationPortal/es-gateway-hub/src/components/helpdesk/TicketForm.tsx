import { useState, useRef } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { ROLE_LABELS } from '@/lib/roleConfig';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Send, AlertTriangle, User, Paperclip, X } from 'lucide-react';

const CATEGORIES = [
  { value: 'it_hardware', label: 'IT – Hardware' },
  { value: 'it_software', label: 'IT – Software' },
  { value: 'it_network', label: 'IT – Network' },
  { value: 'facilities', label: 'Facilities' },
  { value: 'hr', label: 'HR' },
  { value: 'admin', label: 'Admin' },
  { value: 'other', label: 'Other' },
];

const PRIORITIES = [
  { value: 'low', label: 'Low', color: 'text-muted-foreground' },
  { value: 'medium', label: 'Medium', color: 'text-yellow-600' },
  { value: 'high', label: 'High', color: 'text-orange-600' },
  { value: 'critical', label: 'Critical', color: 'text-destructive' },
];

interface TicketFormProps {
  onSuccess: () => void;
}

export const TicketForm = ({ onSuccess }: TicketFormProps) => {
  const { user, profile, roles } = useAuth();
  const [submitting, setSubmitting] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [priority, setPriority] = useState('medium');
  const [contactNumber, setContactNumber] = useState(profile?.contact_number || '');
  const [attachments, setAttachments] = useState<File[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setAttachments(prev => [...prev, ...newFiles]);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeAttachment = (index: number) => {
    setAttachments(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !title.trim() || !category) return;

    setSubmitting(true);

    // Update contact number in profile if changed
    if (contactNumber !== (profile?.contact_number || '')) {
      await supabase.from('profiles').update({ contact_number: contactNumber.trim() || null } as any).eq('user_id', user.id);
    }

    const { data, error } = await supabase.from('helpdesk_tickets' as any).insert({
      created_by: user.id,
      title: title.trim(),
      description: description.trim() || null,
      category,
      priority,
    } as any).select('id').single();

    if (error) {
      setSubmitting(false);
      toast.error('Failed to submit ticket', { description: error.message });
      return;
    }

    // Upload attachments
    if (attachments.length > 0 && data) {
      for (const file of attachments) {
        const filePath = `${(data as any).id}/${Date.now()}-${file.name}`;
        await supabase.storage.from('helpdesk-attachments').upload(filePath, file);
      }
    }

    setSubmitting(false);
    toast.success('Ticket submitted successfully');
    setTitle('');
    setDescription('');
    setCategory('');
    setPriority('medium');
    setAttachments([]);
  };

  return (
    <div className="space-y-6">
      {/* Personal Details Card */}
      <Card>
        <CardHeader className="pb-4">
          <CardTitle className="text-lg flex items-center gap-2">
            <User className="w-5 h-5" />
            Personal Details
          </CardTitle>
          <CardDescription>Your details are pre-filled from your profile.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Employee Name</Label>
              <Input value={profile?.full_name || '—'} readOnly className="bg-muted/50 cursor-default" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Role/Designation</Label>
              <Input value={roles.length > 0 ? roles.map(r => ROLE_LABELS[r] || r).join(', ') : '—'} readOnly className="bg-muted/50 cursor-default" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Employee Code</Label>
              <Input value={profile?.employee_id || '—'} readOnly className="bg-muted/50 cursor-default" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Email ID</Label>
              <Input value={user?.email || '—'} readOnly className="bg-muted/50 cursor-default" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Department</Label>
              <Input value={profile?.department || '—'} readOnly className="bg-muted/50 cursor-default" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Location</Label>
              <Input value={profile?.location || '—'} readOnly className="bg-muted/50 cursor-default" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Contact Number</Label>
              <Input
                value={contactNumber}
                onChange={(e) => setContactNumber(e.target.value)}
                placeholder="Enter contact number"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Ticket Details Card */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Ticket Details</CardTitle>
          <CardDescription>Describe your issue and we'll get it resolved as soon as possible.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2">
              <Label htmlFor="ticket-title">Subject *</Label>
              <Input
                id="ticket-title"
                placeholder="Brief summary of your issue"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label>Category *</Label>
                <Select value={category} onValueChange={setCategory} required>
                  <SelectTrigger>
                    <SelectValue placeholder="Select category" />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map(c => (
                      <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Priority</Label>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {PRIORITIES.map(p => (
                      <SelectItem key={p.value} value={p.value}>
                        <span className={`flex items-center gap-2 ${p.color}`}>
                          {p.value === 'critical' && <AlertTriangle className="w-3 h-3" />}
                          {p.label}
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Attachment</Label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  multiple
                  className="hidden"
                  accept="image/*,.pdf,.doc,.docx,.xls,.xlsx,.txt,.csv"
                />
                <Button
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Paperclip className="w-4 h-4 mr-2" />
                  {attachments.length > 0 ? `${attachments.length} file(s)` : 'Attach files'}
                </Button>
              </div>
            </div>

            {attachments.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {attachments.map((file, idx) => (
                  <div key={idx} className="flex items-center gap-1.5 bg-muted/50 border border-border rounded-md px-2.5 py-1 text-xs">
                    <Paperclip className="w-3 h-3 text-muted-foreground" />
                    <span className="max-w-[150px] truncate">{file.name}</span>
                    <button type="button" onClick={() => removeAttachment(idx)} className="text-muted-foreground hover:text-destructive">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="ticket-desc">Description</Label>
              <Textarea
                id="ticket-desc"
                placeholder="Provide details about the issue — what happened, steps to reproduce, etc."
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={5}
              />
            </div>

            <Button type="submit" disabled={submitting || !title.trim() || !category} className="w-full sm:w-auto">
              <Send className="w-4 h-4 mr-2" />
              {submitting ? 'Submitting…' : 'Submit Ticket'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};
