import { useState, useEffect } from 'react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { Ticket, Clock, CheckCircle, AlertTriangle, Loader2 } from 'lucide-react';

const STATUS_CONFIG: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline'; icon: typeof Clock }> = {
  open: { label: 'Open', variant: 'default', icon: Clock },
  in_progress: { label: 'In Progress', variant: 'secondary', icon: Loader2 },
  resolved: { label: 'Resolved', variant: 'outline', icon: CheckCircle },
  closed: { label: 'Closed', variant: 'outline', icon: CheckCircle },
};

const PRIORITY_CONFIG: Record<string, { label: string; className: string }> = {
  low: { label: 'Low', className: 'bg-muted text-muted-foreground' },
  medium: { label: 'Medium', className: 'bg-yellow-100 text-yellow-800' },
  high: { label: 'High', className: 'bg-orange-100 text-orange-800' },
  critical: { label: 'Critical', className: 'bg-destructive/10 text-destructive' },
};

const CATEGORY_LABELS: Record<string, string> = {
  it_hardware: 'IT – Hardware',
  it_software: 'IT – Software',
  it_network: 'IT – Network',
  facilities: 'Facilities',
  hr: 'HR',
  admin: 'Admin',
  other: 'Other',
};

export const MyTickets = () => {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const fetchTickets = async () => {
      setLoading(true);
      const { data } = await supabase
        .from('helpdesk_tickets' as any)
        .select('*')
        .eq('created_by', user.id)
        .order('created_at', { ascending: false });
      setTickets((data as any[]) || []);
      setLoading(false);
    };
    fetchTickets();
  }, [user]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="w-8 h-8 border-4 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (tickets.length === 0) {
    return (
      <Card>
        <CardContent className="flex flex-col items-center justify-center py-12 text-center">
          <Ticket className="w-12 h-12 text-muted-foreground/50 mb-4" />
          <h3 className="text-lg font-medium text-foreground mb-1">No tickets yet</h3>
          <p className="text-sm text-muted-foreground">Create a new ticket to get support.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-3">
      {tickets.map((ticket: any) => {
        const status = STATUS_CONFIG[ticket.status] || STATUS_CONFIG.open;
        const priority = PRIORITY_CONFIG[ticket.priority] || PRIORITY_CONFIG.medium;
        const StatusIcon = status.icon;

        return (
          <Card key={ticket.id} className="hover:border-primary/30 transition-colors">
            <CardContent className="p-4 sm:p-5">
              <div className="flex flex-col sm:flex-row sm:items-start gap-3">
                {/* Left: Info */}
                <div className="flex-1 min-w-0 space-y-2">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs font-mono text-muted-foreground">{ticket.ticket_number}</span>
                    <Badge variant={status.variant} className="gap-1 text-xs">
                      <StatusIcon className="w-3 h-3" />
                      {status.label}
                    </Badge>
                    <Badge className={`text-xs ${priority.className}`}>
                      {ticket.priority === 'critical' && <AlertTriangle className="w-3 h-3 mr-0.5" />}
                      {priority.label}
                    </Badge>
                  </div>
                  <h3 className="font-medium text-foreground truncate">{ticket.title}</h3>
                  {ticket.description && (
                    <p className="text-sm text-muted-foreground line-clamp-2">{ticket.description}</p>
                  )}
                  <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
                    <span>{CATEGORY_LABELS[ticket.category] || ticket.category}</span>
                    <span>Created {format(new Date(ticket.created_at), 'dd MMM yyyy, HH:mm')}</span>
                  </div>
                </div>

                {/* Resolution notes */}
                {ticket.resolution_notes && (
                  <div className="sm:max-w-[240px] p-3 rounded-lg bg-muted/50 text-sm space-y-1">
                    <p className="font-medium text-xs text-muted-foreground">Resolution</p>
                    <p className="text-foreground line-clamp-3">{ticket.resolution_notes}</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};
