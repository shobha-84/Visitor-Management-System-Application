import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Package, Monitor, Users, ArrowDown, Mail, User, Shield, CheckCircle2, Ban, DollarSign } from 'lucide-react';

const HIERARCHY_ROLES = [
  {
    role: 'Ops Manager',
    email: 'tejaswi@excelsoftcorp.com',
    responsibility: 'Initial approval for products and non-IT people requests. Acknowledges IT people requests.',
    actions: ['Approve', 'Reject'],
    icon: Shield,
    color: 'border-emerald-200 bg-emerald-50 dark:border-emerald-800 dark:bg-emerald-950/30',
    iconColor: 'text-emerald-600',
  },
  {
    role: 'IT Manager',
    email: 'srinivas@excelsoftcorp.com',
    responsibility: 'Approves IT-related product and software/service requests after Ops Manager.',
    actions: ['Approve', 'Reject'],
    icon: Monitor,
    color: 'border-blue-200 bg-blue-50 dark:border-blue-800 dark:bg-blue-950/30',
    iconColor: 'text-blue-600',
  },
  {
    role: 'COO / HR',
    email: 'mahesh.jambardi@excelsoftcorp.com',
    responsibility: 'Approves after IT Manager for products/software. Initiates IT people hiring. Handles HR outsource and PO release for IT people.',
    actions: ['Approve', 'Reject', 'Release PO'],
    icon: User,
    color: 'border-purple-200 bg-purple-50 dark:border-purple-800 dark:bg-purple-950/30',
    iconColor: 'text-purple-600',
  },
  {
    role: 'Finance',
    email: 'esfinance@excelsoftcorp.com',
    responsibility: 'Authorizes budget allocation. Does not approve or reject — only authorizes.',
    actions: ['Authorize'],
    icon: DollarSign,
    color: 'border-amber-200 bg-amber-50 dark:border-amber-800 dark:bg-amber-950/30',
    iconColor: 'text-amber-600',
  },
  {
    role: 'Purchase / HR',
    email: 'biju.r@excelsoftcorp.com',
    responsibility: 'Final step — releases the Purchase Order to complete the procurement cycle.',
    actions: ['Release PO'],
    icon: Package,
    color: 'border-teal-200 bg-teal-50 dark:border-teal-800 dark:bg-teal-950/30',
    iconColor: 'text-teal-600',
  },
];

const FLOWS = [
  {
    title: 'Product (IT Related)',
    subtitle: 'Physical IT products, equipment, hardware',
    icon: Package,
    badgeColor: 'bg-primary/10 text-primary',
    steps: [
      { label: 'Ops Manager', detail: 'tejaswi@excelsoftcorp.com' },
      { label: 'IT Manager', detail: 'srinivas@excelsoftcorp.com' },
      { label: 'COO', detail: 'mahesh.jambardi@excelsoftcorp.com' },
      { label: 'Finance Authorization', detail: 'esfinance@excelsoftcorp.com' },
      { label: 'Purchase – Release PO', detail: 'biju.r@excelsoftcorp.com' },
    ],
  },
  {
    title: 'Product (Non-IT)',
    subtitle: 'Office supplies, non-technical equipment',
    icon: Package,
    badgeColor: 'bg-secondary text-secondary-foreground',
    steps: [
      { label: 'Ops Manager', detail: 'tejaswi@excelsoftcorp.com' },
      { label: 'Finance Authorization', detail: 'esfinance@excelsoftcorp.com' },
      { label: 'Purchase – Release PO', detail: 'biju.r@excelsoftcorp.com' },
    ],
  },
  {
    title: 'Software / Service',
    subtitle: 'Software licenses, SaaS subscriptions, services',
    icon: Monitor,
    badgeColor: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900/40 dark:text-indigo-300',
    steps: [
      { label: 'Ops Manager', detail: 'tejaswi@excelsoftcorp.com' },
      { label: 'IT Manager', detail: 'srinivas@excelsoftcorp.com' },
      { label: 'COO', detail: 'mahesh.jambardi@excelsoftcorp.com' },
      { label: 'Finance Authorization', detail: 'esfinance@excelsoftcorp.com' },
      { label: 'Purchase – Release PO', detail: 'biju.r@excelsoftcorp.com' },
    ],
  },
  {
    title: 'People (IT Development)',
    subtitle: 'IT staffing, outsourcing, contractor requests',
    icon: Users,
    badgeColor: 'bg-purple-100 text-purple-800 dark:bg-purple-900/40 dark:text-purple-300',
    steps: [
      { label: 'COO', detail: 'mahesh.jambardi@excelsoftcorp.com' },
      { label: 'HR – Outsource Initiation', detail: 'mahesh.jambardi@excelsoftcorp.com' },
      { label: 'Finance Authorization', detail: 'esfinance@excelsoftcorp.com' },
      { label: 'HR – Release PO', detail: 'mahesh.jambardi@excelsoftcorp.com' },
      { label: 'Ops Manager – Acknowledge', detail: 'tejaswi@excelsoftcorp.com' },
    ],
  },
  {
    title: 'People (Non-IT)',
    subtitle: 'Non-technical staffing and contractor requests',
    icon: Users,
    badgeColor: 'bg-secondary text-secondary-foreground',
    steps: [
      { label: 'Ops Manager', detail: 'tejaswi@excelsoftcorp.com' },
      { label: 'Finance Authorization', detail: 'esfinance@excelsoftcorp.com' },
      { label: 'Purchase – Release PO', detail: 'biju.r@excelsoftcorp.com' },
    ],
  },
];

export function ApprovalHierarchy() {
  return (
    <div className="space-y-8">
      {/* Approver Directory */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Approver Directory</CardTitle>
          <CardDescription>Key personnel in the procurement approval chain</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {HIERARCHY_ROLES.map(h => {
              const Icon = h.icon;
              return (
                <div key={h.role} className={`rounded-xl border p-4 space-y-3 ${h.color}`}>
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-lg bg-card flex items-center justify-center shrink-0 shadow-sm`}>
                      <Icon className={`w-4.5 h-4.5 ${h.iconColor}`} />
                    </div>
                    <div>
                      <h4 className="font-semibold text-sm text-foreground">{h.role}</h4>
                      <div className="flex items-center gap-1 text-xs text-muted-foreground">
                        <Mail className="w-3 h-3" />
                        <span className="truncate">{h.email}</span>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{h.responsibility}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {h.actions.map(a => (
                      <Badge key={a} variant="outline" className="text-[10px] px-2 py-0.5">
                        {a === 'Approve' && <CheckCircle2 className="w-2.5 h-2.5 mr-1 text-emerald-600" />}
                        {a === 'Reject' && <Ban className="w-2.5 h-2.5 mr-1 text-destructive" />}
                        {a === 'Authorize' && <DollarSign className="w-2.5 h-2.5 mr-1 text-amber-600" />}
                        {a === 'Release PO' && <Package className="w-2.5 h-2.5 mr-1 text-teal-600" />}
                        {a}
                      </Badge>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Flow Diagrams */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Approval Flows by Category</CardTitle>
          <CardDescription>Each category follows a specific approval path based on type and IT relevance</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {FLOWS.map(flow => {
              const Icon = flow.icon;
              return (
                <div key={flow.title} className="rounded-xl border border-border p-5 space-y-4">
                  <div className="flex items-center gap-3">
                    <Badge className={flow.badgeColor} variant="secondary">
                      <Icon className="w-3.5 h-3.5 mr-1.5" />
                      {flow.title}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{flow.subtitle}</p>

                  <div className="space-y-0">
                    {/* Requester */}
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center shrink-0 shadow-sm">
                        <User className="w-4 h-4 text-primary-foreground" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-foreground">Requester</p>
                        <p className="text-[10px] text-muted-foreground">Any authenticated user</p>
                      </div>
                    </div>

                    {flow.steps.map((step, i) => (
                      <div key={i}>
                        <div className="flex justify-center w-8 py-1">
                          <ArrowDown className="w-3.5 h-3.5 text-muted-foreground" />
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0 text-xs font-bold text-secondary-foreground shadow-sm">
                            {i + 1}
                          </div>
                          <div>
                            <p className="text-xs font-semibold text-foreground">{step.label}</p>
                            <p className="text-[10px] text-muted-foreground">{step.detail}</p>
                          </div>
                        </div>
                      </div>
                    ))}

                    {/* Final */}
                    <div className="flex justify-center w-8 py-1">
                      <ArrowDown className="w-3.5 h-3.5 text-emerald-500" />
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center shrink-0 shadow-sm">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-emerald-700 dark:text-emerald-400">PO Released</p>
                        <p className="text-[10px] text-muted-foreground">Procurement complete</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Rules */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Rejection & Authorization Rules</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-lg border border-destructive/20 bg-destructive/5">
              <h4 className="text-sm font-semibold text-destructive mb-2 flex items-center gap-1.5">
                <Ban className="w-4 h-4" /> No Budget
              </h4>
              <p className="text-xs text-muted-foreground">Request rejected when insufficient budget is available for the department or category.</p>
            </div>
            <div className="p-4 rounded-lg border border-destructive/20 bg-destructive/5">
              <h4 className="text-sm font-semibold text-destructive mb-2 flex items-center gap-1.5">
                <Ban className="w-4 h-4" /> No Prior Approval
              </h4>
              <p className="text-xs text-muted-foreground">Request rejected when it bypasses required prior authorization steps.</p>
            </div>
            <div className="p-4 rounded-lg border border-destructive/20 bg-destructive/5">
              <h4 className="text-sm font-semibold text-destructive mb-2 flex items-center gap-1.5">
                <Ban className="w-4 h-4" /> Deemed Illegal
              </h4>
              <p className="text-xs text-muted-foreground">Request rejected if the procurement item or purpose violates company policy or law.</p>
            </div>
          </div>
          <div className="p-4 rounded-lg border border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-950/30">
            <h4 className="text-sm font-semibold text-amber-800 dark:text-amber-200 mb-1 flex items-center gap-1.5">
              <DollarSign className="w-4 h-4" /> Finance Authorization
            </h4>
            <p className="text-xs text-amber-700 dark:text-amber-300">Finance only authorizes budget — they never approve or reject requests. Authorization confirms funds availability.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
