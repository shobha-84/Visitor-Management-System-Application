export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      helpdesk_tickets: {
        Row: {
          assigned_to: string | null
          category: Database["public"]["Enums"]["ticket_category"]
          created_at: string
          created_by: string
          description: string | null
          id: string
          priority: Database["public"]["Enums"]["ticket_priority"]
          resolution_notes: string | null
          resolved_at: string | null
          resolved_by: string | null
          status: Database["public"]["Enums"]["ticket_status"]
          ticket_number: string
          title: string
          updated_at: string
        }
        Insert: {
          assigned_to?: string | null
          category?: Database["public"]["Enums"]["ticket_category"]
          created_at?: string
          created_by: string
          description?: string | null
          id?: string
          priority?: Database["public"]["Enums"]["ticket_priority"]
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: Database["public"]["Enums"]["ticket_status"]
          ticket_number: string
          title: string
          updated_at?: string
        }
        Update: {
          assigned_to?: string | null
          category?: Database["public"]["Enums"]["ticket_category"]
          created_at?: string
          created_by?: string
          description?: string | null
          id?: string
          priority?: Database["public"]["Enums"]["ticket_priority"]
          resolution_notes?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: Database["public"]["Enums"]["ticket_status"]
          ticket_number?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          contact_number: string | null
          created_at: string
          department: string | null
          designation: string | null
          employee_id: string | null
          full_name: string | null
          id: string
          location: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          contact_number?: string | null
          created_at?: string
          department?: string | null
          designation?: string | null
          employee_id?: string | null
          full_name?: string | null
          id?: string
          location?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          contact_number?: string | null
          created_at?: string
          department?: string | null
          designation?: string | null
          employee_id?: string | null
          full_name?: string | null
          id?: string
          location?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      store_requests: {
        Row: {
          category: Database["public"]["Enums"]["store_request_category"]
          coo_approved_at: string | null
          coo_approved_by: string | null
          created_at: string
          created_by: string
          current_approver_role: string | null
          department: string | null
          description: string | null
          estimated_cost: number | null
          finance_authorized_at: string | null
          finance_authorized_by: string | null
          hr_approved_at: string | null
          hr_approved_by: string | null
          id: string
          is_it_related: boolean
          it_manager_approved_at: string | null
          it_manager_approved_by: string | null
          notes: string | null
          ops_manager_approved_at: string | null
          ops_manager_approved_by: string | null
          po_released_at: string | null
          po_released_by: string | null
          quantity: number | null
          rejection_reason: string | null
          status: Database["public"]["Enums"]["store_request_status"]
          title: string
          updated_at: string
          urgency: string | null
          vendor_details: string | null
        }
        Insert: {
          category: Database["public"]["Enums"]["store_request_category"]
          coo_approved_at?: string | null
          coo_approved_by?: string | null
          created_at?: string
          created_by: string
          current_approver_role?: string | null
          department?: string | null
          description?: string | null
          estimated_cost?: number | null
          finance_authorized_at?: string | null
          finance_authorized_by?: string | null
          hr_approved_at?: string | null
          hr_approved_by?: string | null
          id?: string
          is_it_related?: boolean
          it_manager_approved_at?: string | null
          it_manager_approved_by?: string | null
          notes?: string | null
          ops_manager_approved_at?: string | null
          ops_manager_approved_by?: string | null
          po_released_at?: string | null
          po_released_by?: string | null
          quantity?: number | null
          rejection_reason?: string | null
          status?: Database["public"]["Enums"]["store_request_status"]
          title: string
          updated_at?: string
          urgency?: string | null
          vendor_details?: string | null
        }
        Update: {
          category?: Database["public"]["Enums"]["store_request_category"]
          coo_approved_at?: string | null
          coo_approved_by?: string | null
          created_at?: string
          created_by?: string
          current_approver_role?: string | null
          department?: string | null
          description?: string | null
          estimated_cost?: number | null
          finance_authorized_at?: string | null
          finance_authorized_by?: string | null
          hr_approved_at?: string | null
          hr_approved_by?: string | null
          id?: string
          is_it_related?: boolean
          it_manager_approved_at?: string | null
          it_manager_approved_by?: string | null
          notes?: string | null
          ops_manager_approved_at?: string | null
          ops_manager_approved_by?: string | null
          po_released_at?: string | null
          po_released_by?: string | null
          quantity?: number | null
          rejection_reason?: string | null
          status?: Database["public"]["Enums"]["store_request_status"]
          title?: string
          updated_at?: string
          urgency?: string | null
          vendor_details?: string | null
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      visitor_invitations: {
        Row: {
          additional_requirements: string | null
          approved_at: string | null
          approved_by: string | null
          checked_in_at: string | null
          checked_in_by: string | null
          checked_out_at: string | null
          checked_out_by: string | null
          created_at: string
          created_by: string
          department: string
          facilitator_notes: string | null
          id: string
          purpose: string
          rejected_at: string | null
          rejected_by: string | null
          rejection_reason: string | null
          status: Database["public"]["Enums"]["invitation_status"]
          updated_at: string
          visit_end_date: string
          visit_end_time: string
          visit_start_date: string
          visit_start_time: string
          visitor_company: string | null
          visitor_email: string | null
          visitor_name: string
          visitor_phone: string | null
          visitor_photo_url: string | null
        }
        Insert: {
          additional_requirements?: string | null
          approved_at?: string | null
          approved_by?: string | null
          checked_in_at?: string | null
          checked_in_by?: string | null
          checked_out_at?: string | null
          checked_out_by?: string | null
          created_at?: string
          created_by: string
          department: string
          facilitator_notes?: string | null
          id?: string
          purpose: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          status?: Database["public"]["Enums"]["invitation_status"]
          updated_at?: string
          visit_end_date: string
          visit_end_time: string
          visit_start_date: string
          visit_start_time: string
          visitor_company?: string | null
          visitor_email?: string | null
          visitor_name: string
          visitor_phone?: string | null
          visitor_photo_url?: string | null
        }
        Update: {
          additional_requirements?: string | null
          approved_at?: string | null
          approved_by?: string | null
          checked_in_at?: string | null
          checked_in_by?: string | null
          checked_out_at?: string | null
          checked_out_by?: string | null
          created_at?: string
          created_by?: string
          department?: string
          facilitator_notes?: string | null
          id?: string
          purpose?: string
          rejected_at?: string | null
          rejected_by?: string | null
          rejection_reason?: string | null
          status?: Database["public"]["Enums"]["invitation_status"]
          updated_at?: string
          visit_end_date?: string
          visit_end_time?: string
          visit_start_date?: string
          visit_start_time?: string
          visitor_company?: string | null
          visitor_email?: string | null
          visitor_name?: string
          visitor_phone?: string | null
          visitor_photo_url?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role:
        | "trainee"
        | "employee_technical"
        | "employee_non_technical"
        | "employee_security"
        | "employee_electricity"
        | "employee_water"
        | "employee_driver"
        | "employee_approver_technical"
        | "employee_approver_non_technical"
        | "employee_facilitator"
        | "manager_technical"
        | "manager_non_technical"
        | "manager_store"
        | "manager_hr"
        | "director"
        | "coo"
        | "ceo"
        | "employee_system"
        | "employee_system_admin"
        | "ops_manager"
        | "it_manager"
        | "finance"
        | "purchase_hr"
        | "purchase"
        | "hr"
        | "house_keeping"
      invitation_status:
        | "draft"
        | "pending"
        | "approved"
        | "rejected"
        | "checked_in"
        | "checked_out"
      store_request_category: "product" | "software_service" | "people"
      store_request_status:
        | "draft"
        | "pending_ops_manager"
        | "pending_it_manager"
        | "pending_coo"
        | "pending_finance"
        | "pending_hr"
        | "pending_purchase"
        | "finance_authorized"
        | "approved"
        | "rejected"
        | "po_released"
        | "pending_hr_po_release"
        | "pending_ops_info"
      ticket_category:
        | "it_hardware"
        | "it_software"
        | "it_network"
        | "facilities"
        | "hr"
        | "admin"
        | "other"
      ticket_priority: "low" | "medium" | "high" | "critical"
      ticket_status: "open" | "in_progress" | "resolved" | "closed"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: [
        "trainee",
        "employee_technical",
        "employee_non_technical",
        "employee_security",
        "employee_electricity",
        "employee_water",
        "employee_driver",
        "employee_approver_technical",
        "employee_approver_non_technical",
        "employee_facilitator",
        "manager_technical",
        "manager_non_technical",
        "manager_store",
        "manager_hr",
        "director",
        "coo",
        "ceo",
        "employee_system",
        "employee_system_admin",
        "ops_manager",
        "it_manager",
        "finance",
        "purchase_hr",
        "purchase",
        "hr",
        "house_keeping",
      ],
      invitation_status: [
        "draft",
        "pending",
        "approved",
        "rejected",
        "checked_in",
        "checked_out",
      ],
      store_request_category: ["product", "software_service", "people"],
      store_request_status: [
        "draft",
        "pending_ops_manager",
        "pending_it_manager",
        "pending_coo",
        "pending_finance",
        "pending_hr",
        "pending_purchase",
        "finance_authorized",
        "approved",
        "rejected",
        "po_released",
        "pending_hr_po_release",
        "pending_ops_info",
      ],
      ticket_category: [
        "it_hardware",
        "it_software",
        "it_network",
        "facilities",
        "hr",
        "admin",
        "other",
      ],
      ticket_priority: ["low", "medium", "high", "critical"],
      ticket_status: ["open", "in_progress", "resolved", "closed"],
    },
  },
} as const
