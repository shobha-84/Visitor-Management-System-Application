const DEFAULT_OLLAMA_URL = "/ollama";

export function getOllamaUrl(): string {
  const raw = (import.meta.env.VITE_OLLAMA_URL || DEFAULT_OLLAMA_URL).trim();
  return raw.replace(/\/$/, "");
}

export interface ExtractedInvitation {
  visitor_name: string;
  visitor_company: string;
  visitor_email: string;
  visitor_phone: string;
  visit_start_date: string;
  visit_end_date: string;
  visit_start_time: string;
  visit_end_time: string;
  purpose: string;
  department: string[];
  host_name: string;
  host_email: string;
  remarks: string;
  visitor_type: string;
}

export type ChatMessage = {
  role: "user" | "assistant" | "system";
  content: string;
};

function getSystemPrompt(): string {
  const today = new Date().toISOString().split("T")[0];
  const dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const todayName = dayNames[new Date().getDay()];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().split("T")[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split("T")[0];
  return `You are a helpful assistant for a Visitor Management System. Your job is to extract visitor invitation details from natural language and return structured JSON.

Return ONLY valid JSON with no markdown formatting, no code blocks, no explanation text. The JSON must match this exact schema:
{
  "visitor_name": string,
  "visitor_company": string,
  "visitor_email": string,
  "visitor_phone": string,
  "visit_start_date": "YYYY-MM-DD",
  "visit_end_date": "YYYY-MM-DD",
  "visit_start_time": "HH:MM",
  "visit_end_time": "HH:MM",
  "purpose": string,
  "department": string[],
  "host_name": string,
  "host_email": string,
  "remarks": string,
  "visitor_type": "Recurring" | "Non-Recurring"
}

Today's date is: ${today} (${todayName}).

Rules:
- If a field is not mentioned, use empty string "" or empty array []
- Convert relative dates to YYYY-MM-DD format using today (${today}) as the reference
  * "tomorrow" = ${tomorrow}
  * "yesterday" = ${yesterday}
  * "today" = ${today}
  * "next Monday" = calculate from today's date
- Convert time descriptions to HH:MM 24-hour format
- Map purpose keywords to these options: "Meeting", "Interview", "International Client", "Domestic Client", "Vendor Visit", "Audit / Inspection", "Training / Workshop", "Consulting", "Site Tour / Facility Visit", "Delivery / Pickup", "Legal / Compliance", "Board Meeting", "Investor / Stakeholder Visit", "Government / Regulatory", "Personal Visit", "Internship", "Others"
- Map department keywords to these options: "Sales", "Marketing", "Engineering", "Human Resources", "Finance", "Operations", "Business Development", "Management"
- Identify the visitor as the person being invited (not the host)
- Extract host_name and host_email from phrases like "host name is X", "meeting with X", "hosted by X", "contact: X"
- Extract host_email from email addresses that follow host references (e.g., "host name is shobha, shobks@gmail.com")
- visitor_type defaults to "Non-Recurring" unless context suggests recurring
- visitor_phone must be numeric only (max 10 digits)

Example conversation:
User: "Create an invitation for John Doe from Tech Corp, visiting for a meeting, Monday at 10 AM to 12 PM, Engineering department"
Assistant: {"visitor_name": "John Doe", "visitor_company": "Tech Corp", "visitor_email": "", "visitor_phone": "", "visit_start_date": "${tomorrow}", "visit_end_date": "${tomorrow}", "visit_start_time": "10:00", "visit_end_time": "12:00", "purpose": "Meeting", "department": ["Engineering"], "host_name": "", "host_email": "", "remarks": "", "visitor_type": "Non-Recurring"}

User: "John Doe from Tech Corp, meeting tomorrow 10 AM to 12 PM, Engineering, host name is shobha, shobks@gmail.com"
Assistant: {"visitor_name": "John Doe", "visitor_company": "Tech Corp", "visitor_email": "", "visitor_phone": "", "visit_start_date": "${tomorrow}", "visit_end_date": "${tomorrow}", "visit_start_time": "10:00", "visit_end_time": "12:00", "purpose": "Meeting", "department": ["Engineering"], "host_name": "shobha", "host_email": "shobks@gmail.com", "remarks": "", "visitor_type": "Non-Recurring"}

Now extract information from the user's message.`;
}

export async function* streamAIResponse(
  userMessage: string,
  signal?: AbortSignal
): AsyncGenerator<string> {
  const ollamaUrl = getOllamaUrl();

  const response = await fetch(`${ollamaUrl}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "llama3.2",
        messages: [
          { role: "system", content: getSystemPrompt() },
          { role: "user", content: userMessage },
        ],
      stream: true,
    }),
    signal,
  });

  if (!response.ok) {
    throw new Error(`Ollama API error: ${response.status} ${response.statusText}`);
  }

  const reader = response.body!.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split("\n");
      buffer = lines.pop() || "";

      for (const line of lines) {
        if (!line.trim()) continue;
        try {
          const parsed = JSON.parse(line);
          if (parsed.message?.content) {
            yield parsed.message.content;
          }
          if (parsed.done && parsed.done_reason === "load") {
            throw new Error("Model loading failed");
          }
        } catch {
          // skip malformed JSON
        }
      }
    }
  } finally {
    reader.releaseLock();
  }
}

export async function extractInvitationFromText(
  text: string
): Promise<{ data: ExtractedInvitation | null; rawResponse: string }> {
  let fullContent = "";
  const controller = new AbortController();

  try {
    for await (const chunk of streamAIResponse(text, controller.signal)) {
      fullContent += chunk;
    }
  } catch (err: any) {
    controller.abort();
    throw new Error(err?.message || "AI request failed. Make sure Ollama is running with 'ollama run llama3.2'");
  }

  const cleaned = fullContent
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();

  try {
    const parsed = JSON.parse(cleaned) as ExtractedInvitation;
    return { data: parsed, rawResponse: fullContent };
  } catch {
    console.warn("Failed to parse AI response as JSON:", cleaned);
    return { data: null, rawResponse: fullContent };
  }
}
