# Visitor Management System (VMS) - Technical Documentation

## Overview

The Visitor Management System (VMS) is a comprehensive web application built for managing visitor invitations, check-ins, approvals, and security operations. The system supports multiple user roles with distinct permissions and workflows.

---

## Technology Stack

### Frontend (es-gateway-hub)
- **Framework:** React 18 + TypeScript
- **Build Tool:** Vite 5
- **UI Library:** shadcn/ui (Radix UI primitives)
- **Styling:** Tailwind CSS
- **State Management:** React Hooks (useState, useEffect, useMemo)
- **Date Handling:** date-fns
- **Notifications:** Sonner (toast)
- **API Client:** Custom fetch wrapper with Supabase auth integration
- **Real-time:** Supabase Realtime (for live updates)

### Backend (ExcelsoftInternalPortal)
- **Framework:** ASP.NET Core 8
- **Architecture:** Clean Architecture (Domain, Application, Infrastructure)
- **ORM:** Entity Framework Core 8
- **Database:** SQL Server
- **Authentication:** JWT + Supabase
- **API:** RESTful controllers

### External Services
- **Vosk Speech Recognition:** Python service for voice-to-text (port 5000)
- **Ollama:** Local LLM for AI-assisted invitation creation (port 11434)
- **Supabase:** Auth, Database, Realtime, Storage

---

## System Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   Frontend      │────▶│   Backend API   │────▶│   Database      │
│   (React/Vite)  │     │   (ASP.NET)     │     │   (SQL Server)  │
└─────────────────┘     └─────────────────┘     └─────────────────┘
        │                       │                       │
        ▼                       ▼                       ▼
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│  Supabase       │     │  Vosk Service   │     │  Ollama LLM     │
│  (Auth/Realtime)│     │  (Python/Port5000)│    │  (Port 11434)   │
└─────────────────┘     └─────────────────┘     └─────────────────┘
```

---

## User Roles & Permissions

| Role | Code | Description | Key Permissions |
|------|------|-------------|-----------------|
| **Admin** | `Admin` | System administrator | Full access, all invitations, user management |
| **Security** | `employee_security` | Security personnel | Check-in/out, recurring visitors, My Invitations (filtered) |
| **Facilitator** | `employee_facilitator` | Facilitator | Approve/reject invitations, facilitator view |
| **Host/Employee** | `employee` | Regular employee | Create invitations, My Invitations, Host invitations |
| **Approver** | `employee_approver` | Approver | Approve/reject invitations |

---

## Core Features

### 1. Invitation Management

#### Create Invitation
- **Access:** All authenticated users
- **Fields:**
  - Visitor details (Name, Email, Phone, Company, Designation)
  - Visit details (Start/End Date, Start/End Time)
  - Purpose, Additional Requirements, Remarks
  - Additional visitors (max 10)
  - Recurring type (Recurring/Non-Recurring)
- **Validation:** Client + server-side
- **AI Assist:** Voice-to-text via Vosk, AI form filling via Ollama

#### Edit/Update
- **Access:** Creator, Host, Admin
- **Restrictions:** Cannot edit checked-in/out invitations
- **Reschedule:** Available for past-due invitations

#### Statuses
| Status | Description |
|--------|-------------|
| `draft` | Created but not submitted |
| `submitted` | Submitted for approval |
| `approved` | Approved by facilitator/approver |
| `rejected` | Rejected with reason |
| `checked_in` | Visitor checked in |
| `checked_out` | Visitor checked out |
| `completed` | Meeting completed |
| `cancelled` | Cancelled with reason |

---

### 2. My Invitations (Security Role Enhancement)

#### Default View (Recurring Unchecked)
- Shows **today's non-recurring** invitations only
- Date pickers **hidden**
- Recurring checkbox visible on right side

#### Recurring View (Recurring Checked)
- Shows **all recurring** invitations (`visitor_type === "Recurring"`)
- Date pickers **visible** (blank by default)
- Phone search visible next to checkbox
- Filters: Date range + Phone number

#### Filters
| Filter | Behavior |
|--------|----------|
| Start Date | Filters by `visitStartDate` |
| End Date | Filters by `visitStartDate` |
| Status | Filters by current status |
| Phone Search | Filters recurring by `visitor_phone` |
| Clear | Resets all filters to default |

---

### 3. Security Checkpoint

#### Features
- Real-time visitor check-in/out
- Photo capture/upload
- Recurring visitor management
- Visitor history by phone
- Mobile-responsive UI

#### Recurring Visitor Management
- **isRecurring toggle:** Shows/hides date pickers
- **Phone search:** Filters recurring visitors by phone
- **Check-in modes:** Normal vs Recurring
- **Grouped view:** Recurring visitors grouped by phone

#### Filters
| Filter | Behavior |
|--------|----------|
| Recurring Toggle | Shows recurring visitors when checked |
| Date Range | Filters by `visitStartDate` (when recurring checked) |
| Phone Search | Filters recurring by `visitor_phone` |
| Status | Filter by check-in status |
| Clear | Resets to blank dates |

---

### 4. Approval Workflow

#### Facilitator View
- Pending approvals list
- Approve/Reject with remarks
- Bulk operations support

#### Approval Process
1. Invitation submitted → `submitted`
2. Facilitator reviews → `approved`/`rejected`
3. If approved → Host notified
4. Visitor checks in on arrival

---

### 5. AI Assist (Voice/Chat)

#### Voice Transcription (Vosk)
- WebM audio recording → WAV conversion
- Proxy via ASP.NET controller to Python Vosk
- Real-time transcription with retry logic
- Fallback for browser compatibility

#### AI Form Filling (Ollama)
- Natural language → Structured invitation data
- Dynamic system prompt with current date
- Context-aware field mapping
- Apply to form with validation

---

### 6. Visitor Photos

- Capture via webcam (mobile responsive)
- Upload to Supabase Storage
- Display in cards and detail views
- Recurring visitor photo history

---

## Data Models

### VisitorInvitation (Core Entity)
```csharp
public class VisitorInvitation
{
    public Guid Id { get; set; }
    public string VisitorName { get; set; }
    public string VisitorEmail { get; set; }
    public string VisitorPhone { get; set; }
    public string VisitorCompany { get; set; }
    public string VisitorDesignation { get; set; }
    public string VisitorType { get; set; } // "Recurring" | "Non-Recurring"
    public DateTime VisitStartDate { get; set; }
    public DateTime VisitEndDate { get; set; }
    public TimeSpan VisitStartTime { get; set; }
    public TimeSpan VisitEndTime { get; set; }
    public string Purpose { get; set; }
    public string AdditionalRequirements { get; set; }
    public string Remarks { get; set; }
    public string Status { get; set; }
    public string HostEmail { get; set; }
    public string HostName { get; set; }
    public string CreatedBy { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string CancellationReason { get; set; }
    public string RejectionReason { get; set; }
    public bool VisitorAttended { get; set; }
    public bool MeetingCompleted { get; set; }
    public string VisitorPhotoUrl { get; set; }
    public List<AdditionalVisitor> AdditionalVisitors { get; set; }
}
```

### AdditionalVisitor
```csharp
public class AdditionalVisitor
{
    public string Name { get; set; }
    public string Email { get; set; }
    public string Phone { get; set; }
    public string Company { get; set; }
    public string Designation { get; set; }
}
```

---

## API Endpoints

### Visitor Invitations
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/visitor-invitations` | List all invitations (with filters) |
| GET | `/api/visitor-invitations/{id}` | Get single invitation |
| POST | `/api/visitor-invitations` | Create invitation |
| PUT | `/api/visitor-invitations/{id}` | Update invitation |
| DELETE | `/api/visitor-invitations/{id}` | Delete invitation |
| POST | `/api/visitor-invitations/{id}/check-in` | Check-in visitor |
| POST | `/api/visitor-invitations/{id}/check-out` | Check-out visitor |
| POST | `/api/visitor-invitations/{id}/complete` | Complete meeting |
| POST | `/api/visitor-invitations/{id}/cancel` | Cancel invitation |
| POST | `/api/visitor-invitations/{id}/reschedule` | Reschedule invitation |

### Recurring Visitors
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/recurring/history?phone={phone}` | Get history by phone |
| POST | `/api/recurring/{id}/check-in` | Recurring check-in |
| POST | `/api/recurring/{id}/check-out` | Recurring check-out |
| GET | `/api/recurring/{id}/photo` | Get visitor photo |

### Transcription (Vosk)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/transcription/vosk` | Transcribe audio |
| GET | `/api/transcription/health` | Health check |

---

## Frontend Component Structure

```
src/components/visitor/
├── MyInvitations.tsx          # Main invitations list (all roles)
├── SecurityCheckpoint.tsx     # Security check-in/out interface
├── InvitationForm.tsx         # Create/Edit invitation form
├── InvitationFilters.tsx      # Shared filter component
├── InvitationDetailsContent.tsx  # Detail view modal
├── VisitorManagerDialog.tsx   # Additional visitors management
├── VisitorPhoto.tsx           # Photo capture/upload
├── FacilitatorView.tsx        # Approver/facilitator view
├── AIInvitationChat.tsx       # AI chat for form filling
└── SecurityVisitorCard.tsx    # Security-specific card view
```

### Key Hooks
- `useAuth()` - Authentication state (user, role, token)
- `useVisitorCounts()` - Badge counts for tabs

---

## Security & Authentication

### Supabase Auth
- JWT tokens with role claims
- Auto-refresh via `supabase.auth.onAuthStateChange`
- Role-based UI rendering

### API Security
- Bearer token on all requests
- Role-based authorization in controllers
- Input validation (client + server)

### Data Protection
- No sensitive data in localStorage
- Secure photo uploads to Supabase Storage
- SQL injection prevention via EF Core

---

## Deployment Configuration

### Frontend (Vite)
```typescript
// vite.config.ts
proxy: {
  "/ExcelSoftVMSPortal": {
    target: "http://localhost:5194",
    rewrite: (path) => path.replace(/^\/ExcelSoftVMSPortal/, ""),
  },
  "/ollama": {
    target: "http://localhost:11434",
    rewrite: (path) => path.replace(/^\/ollama/, ""),
  },
}
```

### Environment Variables
```env
# Frontend (.env)
VITE_API_URL=/ExcelSoftVMSPortal
VITE_SUPABASE_URL=https://xxx.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=xxx

# Backend (appsettings.json)
"VoskService": { "Url": "http://localhost:5000" }
"ConnectionStrings": { "DefaultConnection": "Server=...;Database=VMS;..." }
```

---

## Development Setup

### Prerequisites
- Node.js 18+
- .NET 8 SDK
- Python 3.10+ (for Vosk)
- SQL Server
- Supabase account

### Start Services
```bash
# Terminal 1: Python Vosk
cd vosk-service && python app.py

# Terminal 2: Backend
cd ExcelsoftInternalPortal/InternalPortal && dotnet run

# Terminal 3: Frontend
cd es-gateway-hub && npm run dev

# Terminal 4: Ollama (optional, for AI)
ollama serve
```

---

## Key Implementation Details

### Date Filter Logic (Security Role)
```typescript
// MyInvitations.tsx - fetchInvitations()
if (isSecurity) {
  if (!isRecurring) {
    // Today's non-recurring only
    filteredData = filteredData.filter(inv => 
      inv.visitor_type !== "Recurring" && isToday(inv.visitStartDate)
    );
  } else {
    // All recurring
    filteredData = filteredData.filter(inv => inv.visitor_type === "Recurring");
    // Apply date range if set
    if (filter.fromDate || filter.toDate) { /* ... */ }
    // Apply phone search
    if (phoneSearch) { /* ... */ }
  }
}
```

### InvitationFilters Date Visibility
```typescript
// Show for: non-security always, security only when isRecurring=true
{(!onRecurringChange || (onRecurringChange && isRecurring)) && (
  <DatePickers />
)}
```

### Clear Button Behavior
```typescript
const handleClear = () => {
  onChange({ fromDate: undefined, toDate: undefined, status: 'all' });
};
```

---

## Testing Checklist

### Security Role - My Invitations
- [ ] Default: Today's non-recurring only
- [ ] Unchecked: Date pickers hidden
- [ ] Checked: Date pickers visible, blank
- [ ] Checked: Phone search visible
- [ ] Date filter works for recurring
- [ ] Phone search filters recurring
- [ ] Clear resets dates to blank
- [ ] Admin sees all tabs

### Security Checkpoint
- [ ] Recurring toggle shows/hides date pickers
- [ ] Phone search filters recurring
- [ ] Check-in/out works for both modes
- [ ] Clear resets dates to blank
- [ ] Photo capture works

### General
- [ ] Create/Edit/Delete invitations
- [ ] Approval workflow
- [ ] AI voice transcription
- [ ] AI form filling
- [ ] Photo upload/view
- [ ] Responsive on mobile

---

## Performance Considerations

- **Pagination:** Implement for large datasets
- **Memoization:** `useMemo` for filtered lists
- **Lazy Loading:** Code-split heavy components
- **Caching:** Supabase Realtime for live updates
- **Image Optimization:** Compress photos before upload

---

## Future Enhancements

1. **Notifications:** Email/SMS for status changes
2. **Reports:** Export to PDF/Excel
3. **Analytics:** Dashboard with visit metrics
4. **Multi-language:** i18n support
5. **Offline Mode:** PWA with background sync
6. **Advanced AI:** Smart scheduling, duplicate detection

---

## Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2026-10-06 | Initial release with Vosk transcription |
| 1.1.0 | 2026-10-08 | Security role recurring filter |
| 1.2.0 | 2026-10-09 | Phone search, date clear fixes, duplicate checkbox removal |

---

## Support & Maintenance

- **Logs:** Backend logs in `bin/Debug/net8.0/Logs/`
- **Monitoring:** Supabase dashboard for auth/database
- **Updates:** Regular dependency updates via Dependabot
- **Backups:** Automated SQL Server backups

---

*Document Version: 1.2.0 | Last Updated: 2026-10-09*