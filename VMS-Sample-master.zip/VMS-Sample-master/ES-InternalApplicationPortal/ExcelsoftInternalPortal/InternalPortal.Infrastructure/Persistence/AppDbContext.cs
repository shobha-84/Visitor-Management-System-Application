﻿
//using InternalPortal.Domain.Entities;
//using Microsoft.EntityFrameworkCore;

//namespace InternalPortal.Infrastructure.Persistence
//{
//    public class AppDbContext : DbContext
//    {
//        public AppDbContext(DbContextOptions<AppDbContext> options)
//            : base(options)
//        {
//        }


//        public DbSet<VisitorInvitation> VisitorInvitations { get; set; }

//        public DbSet<VisitorAdditional> VisitorAdditionals { get; set; }

//        public DbSet<RecurringVisitLog> RecurringVisitLogs { get; set; }

//        protected override void OnModelCreating(ModelBuilder modelBuilder)
//        {
//            modelBuilder.Entity<VisitorInvitation>(entity =>
//            {
//                entity.ToTable("visitor_invitations", "internalapplicationportaldb");

//                entity.HasKey(e => e.Id);

//                entity.Property(e => e.Id)
//                      .HasColumnType("uuid")
//                      .HasDefaultValueSql("gen_random_uuid()")
//                      .HasColumnName("id");

//                entity.Property(e => e.VisitorName).HasColumnName("visitor_name");
//                entity.Property(e => e.VisitorCompany).HasColumnName("visitor_company");
//                entity.Property(e => e.VisitorEmail).HasColumnName("visitor_email");
//                entity.Property(e => e.VisitorPhone).HasColumnName("visitor_phone");

//                entity.Property(e => e.NumberOfVisitors).HasColumnName("number_of_visitors");
//                entity.Property(e => e.Remarks).HasColumnName("remarks");

//                entity.Property(e => e.VisitStartDate).HasColumnName("visit_start_date");
//                entity.Property(e => e.VisitEndDate).HasColumnName("visit_end_date");

//                entity.Property(e => e.VisitStartTime).HasColumnName("visit_start_time");
//                entity.Property(e => e.VisitEndTime).HasColumnName("visit_end_time");

//                entity.Property(e => e.Purpose).HasColumnName("purpose");
//                entity.Property(e => e.Department).HasColumnName("department");

//                entity.Property(e => e.AdditionalRequirements).HasColumnName("additional_requirements");

//                entity.Property(e => e.Status).HasColumnName("status");

//                entity.Property(e => e.CreatedAt)
//                      .HasColumnName("created_at")
//                      .HasColumnType("timestamp with time zone");

//                entity.Property(e => e.UpdatedAt)
//                      .HasColumnName("updated_at")
//                      .HasColumnType("timestamp with time zone");

//                entity.Property(e => e.CreatedBy)
//                      .HasColumnName("created_by")
//                      .IsRequired();

//                entity.Property(e => e.HostName).HasColumnName("host_name");
//                entity.Property(e => e.HostEmail).HasColumnName("host_email");

//                entity.Property(e => e.VisitorType)
//                      .HasColumnName("visitor_type")
//                      .HasMaxLength(50)
//                      .IsRequired();

//                entity.Property(e => e.BadgeNumber)
//                      .HasColumnName("badge_number");

//                entity.Property(e => e.LaptopName)
//                      .HasColumnName("laptop_name");

//                entity.Property(e => e.MacAddress)
//                      .HasColumnName("mac_address");

//                entity.Property(e => e.CheckedInAt)
//                      .HasColumnName("checked_in_at");

//                entity.Property(e => e.CheckedOutAt)
//                      .HasColumnName("checked_out_at");

//                entity.Property(e => e.VisitorPhotoUrl)
//                      .HasColumnName("visitor_photo_url");

//                entity.Property(e => e.ClosedAt)
//                        .HasColumnName("closed_at");

//                entity.Property(e => e.ClosedBy)
//                        .HasColumnName("closed_by");

//                entity.Property(e => e.FacilitatorNotes)
//                      .HasColumnName("facilitator_notes");

//                entity.Property(e => e.RejectionReason)
//                      .HasColumnName("rejection_reason");


//                entity.Property(e => e.HostRemarks)
//                      .HasColumnName("host_remarks");

//                entity.Property(e => e.MeetingCompleted)
//                      .HasColumnName("meeting_completed");


//            });

//            modelBuilder.Entity<VisitorAdditional>(entity =>
//            {
//                entity.ToTable("visitor_additional", "internalapplicationportaldb");

//                entity.HasKey(e => e.Id);

//                entity.Property(e => e.Id).HasColumnName("id");

//                entity.Property(e => e.InvitationId).HasColumnName("invitation_id");

//                entity.Property(e => e.Name).HasColumnName("name").HasMaxLength(100);
//                entity.Property(e => e.Email).HasColumnName("email").HasMaxLength(150);
//                entity.Property(e => e.Phone).HasColumnName("phone").HasMaxLength(20);
//                entity.Property(e => e.Company).HasColumnName("company").HasMaxLength(100);

//                //entity.Property(e => e.CreatedAt)
//                //      .HasColumnName("created_at")
//                //      .HasColumnType("timestamp with time zone");

//            });


//            modelBuilder.Entity<VisitorAdditional>()
//            .HasOne(v => v.Invitation)
//            .WithMany(i => i.AdditionalVisitors)
//            .HasForeignKey(v => v.InvitationId)
//            .OnDelete(DeleteBehavior.Cascade);

//            modelBuilder.Entity<RecurringVisitLog>(entity =>
//            {
//                entity.ToTable("recurring_visit_logs", "internalapplicationportaldb");

//                entity.HasKey(e => e.id);

//                entity.Property(e => e.id)
//                      .HasColumnType("uuid");

//                entity.Property(e => e.invitation_id)
//                      .HasColumnType("uuid");

//                entity.Property(e => e.visitor_phone);

//                entity.Property(e => e.check_in_time)
//                      .HasColumnType("timestamp with time zone");

//                entity.Property(e => e.check_out_time)
//                      .HasColumnType("timestamp with time zone");

//                entity.Property(e => e.status);

//                entity.Property(e => e.created_at)
//                      .HasColumnType("timestamp with time zone");
//            });
//        }

//    }


//    }




using InternalPortal.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using ProcurementAPI.Models;
using InternalPortal.Domain;

namespace InternalPortal.Infrastructure.Persistence
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<VisitorInvitation> VisitorInvitations { get; set; }
        public DbSet<VisitorAdditional> VisitorAdditionals { get; set; }
        public DbSet<RecurringVisitLog> RecurringVisitLogs { get; set; }
        public DbSet<StoreRequest> StoreRequests { get; set; }
        public DbSet<User> users { get; set; }
        public DbSet<Role> UserRoles { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // ✅ Set schema once
            modelBuilder.HasDefaultSchema("internalapplicationportaldb");

            // ✅ Visitor Invitation
            modelBuilder.Entity<VisitorInvitation>(entity =>
            {
                entity.ToTable("visitor_invitations");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id)
                      .HasColumnType("uuid")
                      .HasDefaultValueSql("gen_random_uuid()")
                      .HasColumnName("id");

                entity.Property(e => e.VisitorName).HasColumnName("visitor_name");
                entity.Property(e => e.VisitorCompany).HasColumnName("visitor_company");
                entity.Property(e => e.VisitorEmail).HasColumnName("visitor_email");
                entity.Property(e => e.VisitorPhone).HasColumnName("visitor_phone");

                entity.Property(e => e.NumberOfVisitors).HasColumnName("number_of_visitors");
                entity.Property(e => e.Remarks).HasColumnName("remarks");

                entity.Property(e => e.VisitStartDate).HasColumnName("visit_start_date");
                entity.Property(e => e.VisitEndDate).HasColumnName("visit_end_date");

                entity.Property(e => e.VisitStartTime).HasColumnName("visit_start_time");
                entity.Property(e => e.VisitEndTime).HasColumnName("visit_end_time");

                entity.Property(e => e.Purpose).HasColumnName("purpose");
                entity.Property(e => e.PurposeOthers).HasColumnName("purpose_others");
                entity.Property(e => e.Department).HasColumnName("department");

                entity.Property(e => e.AdditionalRequirements).HasColumnName("additional_requirements");

                entity.Property(e => e.Status).HasColumnName("status");

                entity.Property(e => e.CreatedAt)
                      .HasColumnName("created_at")
                      .HasColumnType("timestamp with time zone");

                entity.Property(e => e.UpdatedAt)
                      .HasColumnName("updated_at")
                      .HasColumnType("timestamp with time zone");

                entity.Property(e => e.CreatedBy)
                      .HasColumnName("created_by");

                entity.Property(e => e.HostName).HasColumnName("host_name");
                entity.Property(e => e.HostEmail).HasColumnName("host_email");

                entity.Property(e => e.VisitorType).HasColumnName("visitor_type");

                entity.Property(e => e.BadgeNumber).HasColumnName("badge_number");
                entity.Property(e => e.LaptopName).HasColumnName("laptop_name");
                entity.Property(e => e.MacAddress).HasColumnName("mac_address");

                entity.Property(e => e.CheckedInAt).HasColumnName("checked_in_at");
                entity.Property(e => e.CheckedOutAt).HasColumnName("checked_out_at");

                entity.Property(e => e.VisitorPhotoUrl).HasColumnName("visitor_photo_url");

                entity.Property(e => e.ClosedAt).HasColumnName("closed_at");
                entity.Property(e => e.ClosedBy).HasColumnName("closed_by");

                entity.Property(e => e.FacilitatorNotes).HasColumnName("facilitator_notes");
                entity.Property(e => e.RejectionReason).HasColumnName("rejection_reason");

                entity.Property(e => e.HostRemarks).HasColumnName("host_remarks");
                entity.Property(e => e.MeetingCompleted).HasColumnName("meeting_completed");

                entity.Property(e => e.IdentityProofType).HasColumnName("identity_proof_type");
                entity.Property(e => e.IsDocumentVerified).HasColumnName("is_document_verified");
                entity.Property(e => e.VerifiedBy).HasColumnName("verified_by");
                entity.Property(e => e.VerifiedOn).HasColumnName("verified_on");

                entity.Property(e => e.CancelledBy).HasColumnName("cancelled_by");
                entity.Property(e => e.CancelledAt).HasColumnName("cancelled_at");
                entity.Property(e => e.CancellationReason).HasColumnName("cancellation_reason");
            });

            // ✅ Visitor Additional
            modelBuilder.Entity<VisitorAdditional>(entity =>
            {
                entity.ToTable("visitor_additional");

                entity.HasKey(e => e.Id);

                entity.Property(e => e.Id).HasColumnName("id");
                entity.Property(e => e.InvitationId).HasColumnName("invitation_id");

                entity.Property(e => e.Name).HasColumnName("name");
                entity.Property(e => e.Email).HasColumnName("email");
                entity.Property(e => e.Phone).HasColumnName("phone");
                entity.Property(e => e.Company).HasColumnName("company");
            });

            // ✅ Relationship
            modelBuilder.Entity<VisitorAdditional>()
                .HasOne(v => v.VisitorInvitation)
                .WithMany(i => i.AdditionalVisitors)
                .HasForeignKey(v => v.InvitationId)
                .OnDelete(DeleteBehavior.Cascade);

            // ✅ Recurring Visit Log
            modelBuilder.Entity<RecurringVisitLog>(entity =>
            {
                entity.ToTable("recurring_visit_logs");

                entity.HasKey(e => e.id);

                entity.Property(e => e.id).HasColumnType("uuid");
                entity.Property(e => e.invitation_id).HasColumnType("uuid");

                entity.Property(e => e.visitor_phone)
                      .IsRequired()
                      .HasColumnType("text");

                entity.Property(e => e.status)
                      .IsRequired()
                      .HasColumnType("text");

                entity.Property(e => e.check_in_time)
                      .HasColumnType("timestamp with time zone");

                entity.Property(e => e.check_out_time)
                      .HasColumnType("timestamp with time zone");

                entity.Property(e => e.created_at)
                      .HasColumnType("timestamp with time zone");

                // ✅ IMPORTANT: Add index for performance
                entity.HasIndex(e => e.visitor_phone);

                entity.Property(e => e.identity_proof_type);
                entity.Property(e => e.is_document_verified);
                entity.Property(e => e.verified_by);
                entity.Property(e => e.verified_on);
            });

            // ✅ StoreRequest (Procurement)
            modelBuilder.Entity<StoreRequest>(entity =>
            {
                entity.ToTable("store_requests");
                entity.HasKey(e => e.Id);
            });


        }
    }
}