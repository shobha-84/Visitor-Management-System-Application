﻿using InternalPortal.Application.DTOs;
using InternalPortal.Application.Interfaces;
using InternalPortal.Domain.Entities;
using InternalPortal.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;


namespace InternalPortal.Infrastructure.Repositories
{


    public class VisitorRepository : IVisitorRepository
    {
        private readonly AppDbContext _context;


        public async Task<List<VisitorInvitation>> GetAllAsync()
        {
            return await _context.VisitorInvitations
                .Include(x => x.AdditionalVisitors)
                .ToListAsync();
        }



        public VisitorRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<VisitorInvitation?> GetByIdAsync(Guid id)
        {
            return await _context.VisitorInvitations
                .Include(x => x.AdditionalVisitors)
                .FirstOrDefaultAsync(x => x.Id == id);
        }



        public async Task AddAsync(VisitorInvitation entity)
        {
            await _context.VisitorInvitations.AddAsync(entity);
        }

        public async Task AddAdditionalAsync(VisitorAdditional visitor)
        {
            await _context.VisitorAdditionals.AddAsync(visitor);
        }


        public async Task AddAdditionalRangeAsync(List<VisitorAdditional> visitors)
        {
            await _context.VisitorAdditionals.AddRangeAsync(visitors);
        }

        public async Task RemoveAdditionalAsync(int id)
        {
            var entity = await _context.VisitorAdditionals.FindAsync(id);

            if (entity != null)
            {
                _context.VisitorAdditionals.Remove(entity);
            }
        }

        public async Task<List<VisitorAdditional>> GetAdditionalsByInvitation(Guid id)
        {
            return await _context.VisitorAdditionals
                .Where(x => x.InvitationId == id)
                .ToListAsync();
        }



        // ⚠️ Only use this for DETACHED entities (not used here)
        public void Update(VisitorInvitation entity)
        {
            _context.VisitorInvitations.Update(entity);
        }

        public void Delete(VisitorInvitation entity)
        {
            _context.VisitorInvitations.Remove(entity);
        }

        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }

        public async Task<List<string>> GetTodayCheckedInBadgesAsync()
        {
            var today = DateOnly.FromDateTime(DateTime.UtcNow);

            return await _context.VisitorInvitations
                .Where(v =>
                    v.VisitStartDate == today &&
                    v.Status == "checked_in" &&
                    v.BadgeNumber != null
                )
                .Select(v => v.BadgeNumber!)
                .ToListAsync();
        }
    }
}

