﻿using InternalPortal.Application.Interfaces;
using InternalPortal.Domain.Entities;
using InternalPortal.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace InternalPortal.Infrastructure.Repositories
{
    public class RecurringRepository : IRecurringRepository
    {
        private readonly AppDbContext _context;

        public RecurringRepository(AppDbContext context)
        {
            _context = context;
        }

        // ✅ Get invitation
        public async Task<VisitorInvitation?> GetInvitationByIdAsync(Guid id)
        {
            return await _context.VisitorInvitations
                .FirstOrDefaultAsync(x => x.Id == id);
        }

        // ✅ Get recurring history by phone
        public async Task<List<RecurringVisitLog>> GetHistoryAsync(string phone)
        {
            return await _context.RecurringVisitLogs
                .Where(x => x.visitor_phone == phone)
                .OrderByDescending(x => x.check_in_time)
                .ToListAsync();
        }

        public async Task<RecurringVisitLog?> GetLatestRecurringVisitorAsync(string phone)
        {
            return await _context.RecurringVisitLogs
                .Where(x => x.visitor_phone == phone)
                .OrderByDescending(x => x.created_at)
                .FirstOrDefaultAsync();
        }

        public async Task<RecurringVisitLog?> GetActiveLogAsync(string phone)
        {
            return await _context.RecurringVisitLogs
                .FirstOrDefaultAsync(x =>
                    x.visitor_phone == phone &&
                    x.check_out_time == null);
        }

        // ✅ Add new log
        public async Task AddLogAsync(RecurringVisitLog log)
        {
            await _context.RecurringVisitLogs.AddAsync(log);
        }

        public async Task<List<RecurringVisitLog>> GetActiveLogsAsync()
        {
            return await _context.RecurringVisitLogs
                .Where(x => x.check_out_time == null)
                .ToListAsync();
        }

        // ✅ Save changes
        public async Task SaveChangesAsync()
        {
            await _context.SaveChangesAsync();
        }
    }
}