using InternalPortal.Application.Interfaces;
using InternalPortal.Application.Options;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace InternalPortal.Infrastructure.Services
{
    public class SendGridEmailService : IEmailService
    {
        private readonly SendGridSettings _settings;
        private readonly ILogger<SendGridEmailService> _logger;
        private readonly SendGridClient _sendGridClient;
        private readonly IMailDumpService _mailDumpService;

        public SendGridEmailService(
            IOptions<SendGridSettings> settings,
            ILogger<SendGridEmailService> logger,
            IMailDumpService mailDumpService)
        {
            _settings = settings.Value;
            _logger = logger;
            _mailDumpService = mailDumpService;

            if (string.IsNullOrWhiteSpace(_settings.ApiKey))
                throw new InvalidOperationException("SendGrid ApiKey is not configured.");

            _sendGridClient = new SendGridClient(_settings.ApiKey);
        }

        public async Task SendAsync(
            string toEmail,
            string toName,
            string subject,
            string htmlBody)
        {
            if (string.IsNullOrWhiteSpace(toEmail))
            {
                _logger.LogWarning(
                    "SendGrid email skipped: recipient address is empty. Subject: '{Subject}'.",
                    subject);
                return;
            }

            if (_settings.SendMail == 0)
            {
                var requestIdentifier = Guid.NewGuid().ToString("N")[..8];

                _logger.LogWarning(
                    "SendGrid email sending skipped due to SendMail=0 configuration. To: {Email}, Subject: '{Subject}'. Dumping to MailDump folder.",
                    toEmail,
                    subject);

                try
                {
                    var filePath = await _mailDumpService.DumpEmailAsync(
                        toEmail,
                        toName,
                        subject,
                        htmlBody,
                        requestIdentifier);

                    _logger.LogInformation(
                        "SendGrid email dump completed successfully. To: {Email}, File saved at: {FilePath}",
                        toEmail,
                        filePath);
                }
                catch (Exception ex)
                {
                    _logger.LogError(
                        ex,
                        "SendGrid failed to dump email to MailDump folder. To: {Email}, Subject: '{Subject}'. Business flow continues.",
                        toEmail,
                        subject);
                }

                return;
            }

            if (string.IsNullOrWhiteSpace(_settings.SenderEmail))
                throw new InvalidOperationException("SendGrid SenderEmail is not configured.");

            var from = new EmailAddress(_settings.SenderEmail, _settings.SenderName);
            var to = new EmailAddress(toEmail, toName ?? toEmail);
            var htmlContent = htmlBody;

            var mail = MailHelper.CreateSingleEmail(from, to, subject, null, htmlContent);

            var response = await _sendGridClient.SendEmailAsync(mail);

            if (response.IsSuccessStatusCode)
            {
                _logger.LogInformation(
                    "SendGrid email sent successfully. To: {Email}, Subject: '{Subject}', Status: {StatusCode}",
                    toEmail,
                    subject,
                    response.StatusCode);
            }
            else
            {
                var errorBody = await response.Body.ReadAsStringAsync();

                _logger.LogError(
                    "SendGrid email failed. To: {Email}, Subject: '{Subject}', Status: {StatusCode}, Error: {Error}",
                    toEmail,
                    subject,
                    response.StatusCode,
                    errorBody);

                throw new InvalidOperationException(
                    $"SendGrid failed to send email to {toEmail}. Status: {response.StatusCode}. {errorBody}");
            }
        }
    }
}
