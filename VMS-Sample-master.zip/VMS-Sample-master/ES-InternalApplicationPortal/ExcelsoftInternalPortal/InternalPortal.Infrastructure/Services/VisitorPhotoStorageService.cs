﻿using InternalPortal.Application.Interfaces;
using Microsoft.AspNetCore.Hosting;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace InternalPortal.Infrastructure.Services
{
    public class VisitorPhotoStorageService : IVisitorPhotoStorage
    {
        private readonly IWebHostEnvironment _env;

        public VisitorPhotoStorageService(IWebHostEnvironment env)
        {
            _env = env;
        }

        public async Task<string> SaveAsync(
            Guid invitationId,
            string originalFileName,
            byte[] content)
        {
            var folderPath = Path.Combine(
                AppContext.BaseDirectory,
                "AppData",
                "VisitorPhotos"
            );

            Directory.CreateDirectory(folderPath);

            var ext = Path.GetExtension(originalFileName).ToLowerInvariant();
            var allowed = new[] { ".jpg", ".jpeg", ".png", ".webp" };

            if (!allowed.Contains(ext))
            {
                throw new Exception("Invalid image type");
            }

            var fileName = $"{invitationId}{ext}";
            var fullPath = Path.Combine(folderPath, fileName);

            await File.WriteAllBytesAsync(fullPath, content);

            return $"VisitorPhotos/{fileName}";
        }
    }
}