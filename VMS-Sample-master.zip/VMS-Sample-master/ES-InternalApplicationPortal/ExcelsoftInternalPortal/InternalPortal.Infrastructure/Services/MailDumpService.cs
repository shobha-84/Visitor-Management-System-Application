using InternalPortal.Application.Interfaces;
using Microsoft.Extensions.Logging;
using System.Text;

namespace InternalPortal.Infrastructure.Services
{
    public class MailDumpService : IMailDumpService
    {
        private readonly ILogger<MailDumpService> _logger;

        public MailDumpService(ILogger<MailDumpService> logger)
        {
            _logger = logger;
        }

        public async Task<string> DumpEmailAsync(
            string toEmail,
            string toName,
            string subject,
            string htmlBody,
            string requestId)
        {
            var mailDumpPath = GetMailDumpDirectory();

            try
            {
                Directory.CreateDirectory(mailDumpPath);
                _logger.LogInformation("MailDump directory verified or created at: {MailDumpPath}", mailDumpPath);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to create MailDump directory at {MailDumpPath}", mailDumpPath);
                throw new InvalidOperationException($"Failed to create MailDump directory: {ex.Message}", ex);
            }

            var fileName = GenerateFileName(requestId);
            var filePath = Path.Combine(mailDumpPath, fileName);

            var fullHtml = BuildFullHtmlDocument(subject, toEmail, toName, htmlBody);

            try
            {
                await File.WriteAllTextAsync(filePath, fullHtml);

                _logger.LogInformation(
                    "Email dump created successfully. To: {Email} ({Name}), Subject: '{Subject}', File: {FilePath}",
                    toEmail,
                    toName,
                    subject,
                    filePath);

                return filePath;
            }
            catch (Exception ex)
            {
                _logger.LogError(
                    ex,
                    "Failed to write email dump to {FilePath}. To: {Email}, Subject: '{Subject}'",
                    filePath,
                    toEmail,
                    subject);

                throw new InvalidOperationException(
                    $"Failed to write email dump to {filePath}: {ex.Message}",
                    ex);
            }
        }

        private string GetMailDumpDirectory()
        {
            var baseDirectory = AppDomain.CurrentDomain.BaseDirectory;
            return Path.Combine(baseDirectory, "MailDump");
        }

        private string GenerateFileName(string requestId)
        {
            var timestamp = DateTime.UtcNow.ToString("yyyyMMdd_HHmmss");
            return $"Mail_{timestamp}_{requestId}.html";
        }

        private string BuildFullHtmlDocument(string subject, string toEmail, string toName, string body)
        {
            var sb = new StringBuilder();
            sb.AppendLine("<!DOCTYPE html>");
            sb.AppendLine("<html lang=\"en\">");
            sb.AppendLine("<head>");
            sb.AppendLine("    <meta charset=\"UTF-8\">");
            sb.AppendLine("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">");
            sb.AppendLine($"    <title>{EscapeHtml(subject)}</title>");
            sb.AppendLine("    <style>");
            sb.AppendLine("        body { font-family: Arial, Helvetica, sans-serif; background-color: #f4f4f4; margin: 0; padding: 20px; }");
            sb.AppendLine("        .email-container { max-width: 600px; margin: 0 auto; background-color: #ffffff; border: 1px solid #dddddd; border-radius: 5px; overflow: hidden; }");
            sb.AppendLine("        .email-header { background-color: #4CAF50; color: white; padding: 15px 20px; }");
            sb.AppendLine("        .email-header h2 { margin: 0; font-size: 18px; }");
            sb.AppendLine("        .email-meta { padding: 10px 20px; background-color: #f9f9f9; border-bottom: 1px solid #eeeeee; font-size: 12px; color: #666666; }");
            sb.AppendLine("        .email-body { padding: 20px; }");
            sb.AppendLine("        .email-body table { border-collapse: collapse; }");
            sb.AppendLine("        .dump-notice { padding: 10px; background-color: #fff3cd; border-bottom: 1px solid #ffc107; font-size: 12px; color: #856404; text-align: center; }");
            sb.AppendLine("    </style>");
            sb.AppendLine("</head>");
            sb.AppendLine("<body>");
            sb.AppendLine("    <div class=\"email-container\">");
            sb.AppendLine("        <div class=\"dump-notice\">");
            sb.AppendLine("            <strong>DUMP MODE:</strong> This email was saved to disk instead of being sent (SendMail = 0).");
            sb.AppendLine("        </div>");
            sb.AppendLine("        <div class=\"email-meta\">");
            sb.AppendLine($"            <div><strong>To:</strong> {EscapeHtml(toName)} &lt;{EscapeHtml(toEmail)}&gt;</div>");
            sb.AppendLine("            <div><strong>From:</strong> Internal Portal</div>");
            sb.AppendLine($"            <div><strong>Subject:</strong> {EscapeHtml(subject)}</div>");
            sb.AppendLine($"            <div><strong>Generated:</strong> {DateTime.UtcNow:yyyy-MM-dd HH:mm:ss UTC}</div>");
            sb.AppendLine($"            <div><strong>Request ID:</strong> {EscapeHtml(subject)}</div>");
            sb.AppendLine("        </div>");
            sb.AppendLine("        <div class=\"email-header\">");
            sb.AppendLine($"            <h2>{EscapeHtml(subject)}</h2>");
            sb.AppendLine("        </div>");
            sb.AppendLine("        <div class=\"email-body\">");
            sb.AppendLine("            " + body);
            sb.AppendLine("        </div>");
            sb.AppendLine("    </div>");
            sb.AppendLine("</body>");
            sb.AppendLine("</html>");

            return sb.ToString();
        }

        private static string EscapeHtml(string value)
        {
            return System.Net.WebUtility.HtmlEncode(value ?? string.Empty);
        }
    }
}
