using InternalPortal.Application.Interfaces;
using InternalPortal.Application.Options;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MimeKit;

namespace InternalPortal.Infrastructure.Services
{
    public class SmtpEmailService : IEmailService
    {
        private readonly SmtpSettings _settings;
        private readonly ILogger<SmtpEmailService> _logger;
        private readonly IMailDumpService _mailDumpService;

        public SmtpEmailService(
            IOptions<SmtpSettings> settings,
            ILogger<SmtpEmailService> logger,
            IMailDumpService mailDumpService)
        {
            _settings = settings.Value;
            _logger = logger;
            _mailDumpService = mailDumpService;
        }

        public async Task SendAsync(
            string toEmail,
            string toName,
            string subject,
            string htmlBody)
        {
            if (string.IsNullOrWhiteSpace(toEmail))
            {
                _logger.LogWarning(
                    "Email skipped: recipient address is empty. Subject: '{Subject}'.",
                    subject);
                return;
            }

            if (_settings.SendMail == 0)
            {
                var requestIdentifier = Guid.NewGuid().ToString("N")[..8];

                _logger.LogWarning(
                    "Email sending skipped due to SendMail=0 configuration. To: {Email}, Subject: '{Subject}'. Dumping to MailDump folder.",
                    toEmail,
                    subject);

                try
                {
                    var filePath = await _mailDumpService.DumpEmailAsync(
                        toEmail,
                        toName,
                        subject,
                        htmlBody,
                        requestIdentifier);

                    _logger.LogInformation(
                        "Email dump completed successfully. Recipient: {Email}, File saved at: {FilePath}",
                        toEmail,
                        filePath);
                }
                catch (Exception ex)
                {
                    _logger.LogError(
                        ex,
                        "Failed to dump email to MailDump folder. To: {Email}, Subject: '{Subject}'. Business flow continues.",
                        toEmail,
                        subject);
                }

                return;
            }

            if (!_settings.Enabled)
            {
                _logger.LogInformation(
                    "SMTP is disabled. Skipping email to {Email} with subject '{Subject}'.",
                    toEmail,
                    subject);
                return;
            }

            if (string.IsNullOrWhiteSpace(_settings.Host))
                throw new InvalidOperationException("SMTP Host is not configured.");

            if (string.IsNullOrWhiteSpace(_settings.FromEmail))
                throw new InvalidOperationException("SMTP FromEmail is not configured.");

            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(_settings.FromName, _settings.FromEmail));
            message.To.Add(new MailboxAddress(toName ?? toEmail, toEmail));
            message.Subject = subject;
            message.Body = new TextPart("html") { Text = htmlBody };

            var socketOptions = GetSecureSocketOptions(_settings.Port, _settings.EnableSsl);
            var timeoutMs = Math.Max(5, _settings.TimeoutSeconds) * 1000;

            _logger.LogInformation(
                "Connecting to SMTP {Host}:{Port} ({SocketOptions}) to send '{Subject}' to {Email} from {FromEmail}.",
                _settings.Host,
                _settings.Port,
                socketOptions,
                subject,
                toEmail,
                _settings.FromEmail);

            using var client = new SmtpClient
            {
                Timeout = timeoutMs
            };

            try
            {
                await client.ConnectAsync(_settings.Host, _settings.Port, socketOptions);

                if (!string.IsNullOrWhiteSpace(_settings.Username))
                {
                    await client.AuthenticateAsync(_settings.Username, _settings.Password);
                }

                await client.SendAsync(message);
                await client.DisconnectAsync(true);

                _logger.LogInformation(
                    "SMTP send succeeded for '{Subject}' to {Email}.",
                    subject,
                    toEmail);
            }
            catch (OperationCanceledException ex)
            {
                _logger.LogError(
                    ex,
                    "SMTP timed out connecting to {Host}:{Port}. Check outbound firewall, VPN, and that SES SMTP credentials/region are correct.",
                    _settings.Host,
                    _settings.Port);
                throw new InvalidOperationException(
                    $"SMTP connection to {_settings.Host}:{_settings.Port} timed out. " +
                    "Verify the server can reach AWS SES on the configured port and that Smtp settings are correct.",
                    ex);
            }
            catch (AuthenticationException ex)
            {
                _logger.LogError(ex, "SMTP authentication failed for user {Username}.", _settings.Username);
                throw new InvalidOperationException("SMTP authentication failed. Check Smtp:Username and Smtp:Password.", ex);
            }
            catch (SmtpCommandException ex)
            {
                _logger.LogError(
                    ex,
                    "SMTP command failed for {Email}. StatusCode={StatusCode}, Response={Response}",
                    toEmail,
                    ex.StatusCode,
                    ex.Message);
                throw new InvalidOperationException($"SMTP rejected the message: {ex.Message}", ex);
            }
            catch (SmtpProtocolException ex)
            {
                _logger.LogError(ex, "SMTP protocol error while sending to {Email}.", toEmail);
                throw new InvalidOperationException($"SMTP protocol error: {ex.Message}", ex);
            }
        }

        private static SecureSocketOptions GetSecureSocketOptions(int port, bool enableSsl)
        {
            if (!enableSsl)
                return SecureSocketOptions.None;

            // AWS SES: 587 = STARTTLS, 465 = SSL
            return port == 465
                ? SecureSocketOptions.SslOnConnect
                : SecureSocketOptions.StartTls;
        }
    }
}
