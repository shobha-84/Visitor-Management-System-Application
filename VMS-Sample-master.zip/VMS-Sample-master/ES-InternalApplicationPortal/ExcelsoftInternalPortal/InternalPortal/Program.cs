﻿using InternalPortal.Application.Interfaces;
using InternalPortal.Application.Options;
using InternalPortal.Application.Services;
using InternalPortal.Infrastructure.Persistence;
using InternalPortal.Infrastructure.Repositories;
using InternalPortal.Infrastructure.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.FileProviders;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using InternalPortal.Infrastructure.Services;
using Microsoft.Extensions.Logging;


var builder = WebApplication.CreateBuilder(args);
var enforceAuth = builder.Configuration.GetValue<bool>("Auth:Enforce");

// ---------------- CORS ----------------
var corsSection = builder.Configuration.GetSection("Cors");
var allowedOrigins = corsSection.GetSection("AllowedOrigins").Get<string[]>();

if (allowedOrigins == null || allowedOrigins.Length == 0)
{
    throw new InvalidOperationException("CORS configuration missing: 'Cors:AllowedOrigins' must be defined in appsettings.json");
}

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowFrontend", policy =>
    {
        policy
            .WithOrigins(allowedOrigins)
            .AllowAnyMethod()
            .AllowAnyHeader()
            .AllowCredentials();
    });
});


// ---------------- DB ----------------
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection"))
);

// ---------------- SERVICES ----------------
builder.Services.Configure<SmtpSettings>(builder.Configuration.GetSection(SmtpSettings.SectionName));
builder.Services.Configure<SendGridSettings>(builder.Configuration.GetSection(SendGridSettings.SectionName));
builder.Services.AddScoped<IMailDumpService, MailDumpService>();

var emailProvider = builder.Configuration["EmailProvider"] ?? "Smtp";

if (string.Equals(emailProvider, "SendGrid", StringComparison.OrdinalIgnoreCase))
{
    builder.Services.AddScoped<IEmailService, SendGridEmailService>();
}
else
{
    builder.Services.AddScoped<IEmailService, SmtpEmailService>();
}

builder.Services.AddScoped<IVisitorInvitationEmailNotifier, VisitorInvitationEmailNotifier>();
builder.Services.AddScoped<VisitorService>();
builder.Services.AddScoped<IVisitorPhotoStorage, VisitorPhotoStorageService>();
builder.Services.AddScoped<IVisitorRepository, VisitorRepository>();


// Clear default providers
builder.Logging.ClearProviders();

// Add log4net
builder.Logging.AddLog4Net("log4net.config");

var logsDir = Path.Combine(builder.Environment.ContentRootPath, "Logs");
Directory.CreateDirectory(logsDir);

builder.Services.AddControllers();

// ---------------- AUTH ----------------
// ✅ REGISTER REPOSITORIES (next step)
builder.Services.AddScoped<IVisitorRepository, VisitorRepository>();
//builder.Services.AddControllers();
builder.Services.AddScoped<IRecurringRepository, RecurringRepository>();
builder.Services.AddScoped<RecurringService>();

builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.ReferenceHandler =
            System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles;
    });

// ---------------- VOSK SERVICE CLIENT ----------------
builder.Services.AddHttpClient("VoskService", client =>
{
    var voskUrl = builder.Configuration["VoskService:Url"] ?? "http://localhost:5000";
    client.BaseAddress = new Uri(voskUrl);
    client.Timeout = TimeSpan.FromMinutes(3);
    client.DefaultRequestHeaders.Add("Accept", "application/json");
});

// ---------------- AUTH ----------------
if (enforceAuth)
{
    var jwtIssuer = builder.Configuration["Jwt:Issuer"] ?? string.Empty;
    var jwtAudience = builder.Configuration["Jwt:Audience"] ?? string.Empty;
    var jwtKey = builder.Configuration["Jwt:Key"] ?? string.Empty;

    if (string.IsNullOrWhiteSpace(jwtKey))
    {
        throw new InvalidOperationException("Jwt:Key must be configured when Auth:Enforce is true.");
    }

    builder.Services
        .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        .AddJwtBearer(options =>
        {
            options.RequireHttpsMetadata = true;
            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = !string.IsNullOrWhiteSpace(jwtIssuer),
                ValidateAudience = !string.IsNullOrWhiteSpace(jwtAudience),
                ValidateIssuerSigningKey = true,
                ValidateLifetime = true,
                ValidIssuer = jwtIssuer,
                ValidAudience = jwtAudience,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtKey)),
                NameClaimType = "name",
                RoleClaimType = "role",
                ClockSkew = TimeSpan.FromMinutes(2)
            };
        });
}

builder.Services.AddAuthorization(options =>
{
    if (enforceAuth)
    {
        options.AddPolicy("EmployeePolicy", policy => policy.RequireRole("Employee", "Approver", "Security"));
        options.AddPolicy("ApproverPolicy", policy => policy.RequireRole("Approver"));
        options.AddPolicy("SecurityPolicy", policy => policy.RequireRole("Security"));
        options.AddPolicy("ApproverOrSecurityPolicy", policy => policy.RequireRole("Approver", "Security"));
    }
    else
    {
        options.AddPolicy("EmployeePolicy", policy => policy.RequireAssertion(_ => true));
        options.AddPolicy("ApproverPolicy", policy => policy.RequireAssertion(_ => true));
        options.AddPolicy("SecurityPolicy", policy => policy.RequireAssertion(_ => true));
        options.AddPolicy("ApproverOrSecurityPolicy", policy => policy.RequireAssertion(_ => true));
    }
});
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

//builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
//    .AddJwtBearer(options =>
//    {
//        options.TokenValidationParameters = new TokenValidationParameters
//        {
//            ValidateIssuer = true,
//            ValidateAudience = true,
//            ValidateLifetime = true,
//            ValidateIssuerSigningKey = true,
//            ValidIssuer = builder.Configuration["Jwt:Issuer"],
//            ValidAudience = builder.Configuration["Jwt:Audience"],
//            IssuerSigningKey = new SymmetricSecurityKey(
//                Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"])
//            )
//        };
//    });

//builder.Services.AddAuthorization();
builder.Services.AddScoped<IAuthService, AuthService>();

// ✅ BUILD APP
var app = builder.Build();

//app.UsePathBase("/internalProjectApp");

var visitorPhotosPath = Path.Combine(
    AppContext.BaseDirectory,
    "AppData",
    "VisitorPhotos"
);

// ✅ CRITICAL: ensure directory exists BEFORE using PhysicalFileProvider
Directory.CreateDirectory(visitorPhotosPath);

app.UseStaticFiles(new StaticFileOptions
{
    FileProvider = new PhysicalFileProvider(visitorPhotosPath),
    RequestPath = "/VisitorPhotos"
});

// Optional wwwroot
app.UseStaticFiles();


app.UseSwagger();
app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("../swagger/v1/swagger.json", "InternalPortal API V1");
});



app.UseCors("AllowFrontend");

if (enforceAuth)
    app.UseAuthentication();

app.UseAuthorization();
app.MapControllers();

// Ensure purpose_others column exists (run once on startup)
using (var scope = app.Services.CreateScope())
{
    var context = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    try
    {
        logger.LogInformation("Checking/creating purpose_others column...");
        await context.Database.ExecuteSqlRawAsync(@"
            ALTER TABLE internalapplicationportaldb.visitor_invitations 
            ADD COLUMN IF NOT EXISTS purpose_others TEXT;
            ALTER TABLE internalapplicationportaldb.visitor_invitations 
            ADD CONSTRAINT chk_purpose_others_length 
            CHECK (purpose_others IS NULL OR char_length(purpose_others) <= 500);
        ");
        logger.LogInformation("purpose_others column ensured successfully");
        
        // Verify column exists
        var colExists = await context.Database.SqlQueryRaw<int>(@"
            SELECT COUNT(*) FROM information_schema.columns 
            WHERE table_schema = 'internalapplicationportaldb' 
            AND table_name = 'visitor_invitations' 
            AND column_name = 'purpose_others'
        ").ToListAsync();
        logger.LogInformation("Column purpose_others exists: {Count}", colExists.FirstOrDefault());
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "Error ensuring purpose_others column");
    }
}

app.Run();