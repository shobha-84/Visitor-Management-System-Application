﻿using InternalPortal.Application.DTOs;
using InternalPortal.Application.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace InternalPortal.API.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly ILogger<AuthController> _logger;

        public AuthController(
                  IAuthService authService,
                  ILogger<AuthController> logger)
        {
            _authService = authService;
            _logger = logger;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login(LoginDto dto)
        {
            _logger.LogInformation("Login attempt started for Email: {Email}", dto.Email);

            try
            {
                var result = await _authService.LoginAsync(dto);

                _logger.LogInformation("Login successful for Email: {Email}", dto.Email);

                return Ok(result);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Login failed for Email: {Email}", dto.Email);

                return StatusCode(500, "An error occurred");
            }
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(RegisterDto dto)
        {
            _logger.LogInformation("User registration started for Email: {Email}", dto.Email);

            try
            {
                await _authService.RegisterAsync(dto);

                _logger.LogInformation("User registered successfully: {Email}", dto.Email);

                return Ok();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "User registration failed: {Email}", dto.Email);

                return StatusCode(500, "An error occurred");
            }
        }
    }
}
