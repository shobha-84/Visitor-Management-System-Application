﻿using Microsoft.AspNetCore.Mvc;
//using ProcurementAPI.Data;
using ProcurementAPI.Models;
//using ProcurementAPI.DTOs;
using InternalPortal.Application.DTOs;
using InternalPortal.Infrastructure.Persistence;


namespace ProcurementAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class StoreRequestsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public StoreRequestsController(AppDbContext context)
        {
            _context = context;
        }

        private string GetInitialStatus(string category, bool isItRelated)
        {
            if (category == "people" && isItRelated)
                return "pending_coo";

            return "pending_ops_manager";
        }

        private string GetInitialApprover(string category, bool isItRelated)
        {
            if (category == "people" && isItRelated)
                return "coo";

            return "manager_non_technical";
        }


        //
        //

        [HttpGet]
        public IActionResult GetAll()
        {
            return Ok(_context.StoreRequests.ToList());
        }




        [HttpGet("user/{userId}")]
        public IActionResult GetByUser(string userId)
        {
            return Ok(_context.StoreRequests
                .Where(x => x.CreatedBy == userId)
                .OrderByDescending(x => x.CreatedAt)
                .ToList());
        }



        //[HttpPut("{id}")]
        //public async Task<IActionResult> Update(Guid id, [FromBody] StoreRequest updated)
        //{
        //    var existing = await _context.StoreRequests.FindAsync(id);
        //    if (existing == null) return NotFound();

        //    _context.Entry(existing).CurrentValues.SetValues(updated);
        //    await _context.SaveChangesAsync();

        //    return Ok(existing);
        //}


        //
        //



        [HttpPost]
        public async Task<IActionResult> Create([FromBody] CreateStoreRequestDto dto)
        {
            try
            {
                var request = new StoreRequest
                {
                    Id = Guid.NewGuid(),
                    CreatedBy = dto.CreatedBy,

                    Title = dto.Title,
                    Description = dto.Description,

                    Category = dto.Category,
                    IsItRelated = dto.IsItRelated,

                    EstimatedCost = dto.EstimatedCost,
                    Quantity = dto.Quantity,

                    Urgency = dto.Urgency,
                    Department = dto.Department,

                    VendorDetails = dto.VendorDetails,
                    Notes = dto.Notes,

                    Status = GetInitialStatus(dto.Category, dto.IsItRelated),
                    CurrentApproverRole = GetInitialApprover(dto.Category, dto.IsItRelated),

                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow
                };

                _context.StoreRequests.Add(request);
                await _context.SaveChangesAsync();

                return Ok(request);
            }
            catch (Exception ex)
            {
                // ✅ THIS IS STEP 4 DEBUG
                return BadRequest(ex.ToString());
            }
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> Update(Guid id, [FromBody] Dictionary<string, object> updates)
        {
            var existing = await _context.StoreRequests.FindAsync(id);
            if (existing == null) return NotFound();

            foreach (var key in updates.Keys)
            {
                var prop = existing.GetType().GetProperty(key, System.Reflection.BindingFlags.IgnoreCase | System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance);

                if (prop != null && updates[key] != null)
                {
                    var value = Convert.ChangeType(updates[key], prop.PropertyType);
                    prop.SetValue(existing, value);
                }
            }

            existing.UpdatedAt = DateTime.UtcNow;

            await _context.SaveChangesAsync();

            return Ok(existing);

        }


    }
}