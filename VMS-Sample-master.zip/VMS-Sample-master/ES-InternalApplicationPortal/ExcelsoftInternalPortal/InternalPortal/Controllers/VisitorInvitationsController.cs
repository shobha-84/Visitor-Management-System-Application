﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Hosting;
using InternalPortal.Application.Services;
using InternalPortal.Application.DTOs;
using System.IO;
using System.Linq;

namespace InternalPortal.Controllers
{
    [ApiController]
    [Route("api/visitor-invitations")]
    public class VisitorInvitationsController : ControllerBase
    {
        private readonly VisitorService _service;
        private readonly IWebHostEnvironment _environment;

        public VisitorInvitationsController(
            VisitorService service,
            IWebHostEnvironment environment)
        {
            _service = service;
            _environment = environment;
        }

        // ---------------- CREATE ----------------

        [HttpPost]
        [Authorize(Policy = "EmployeePolicy")]
        [Consumes("application/json")]
        public async Task<IActionResult> Create([FromBody] CreateVisitorInvitationDto dto)
        {
            var result = await _service.CreateAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
        }

        // ---------------- GET ----------------

        [HttpGet]
        [Authorize(Policy = "EmployeePolicy")]
        public async Task<IActionResult> GetAll(
    [FromQuery] bool mine = false,
    [FromQuery] string? status = null,
    [FromQuery] string? createdBy = null,
    [FromQuery] string? visitorType = null,   // ✅ NEW
    [FromQuery] string? phone = null          // ✅ NEW
)
        {
            try
            {
                var result = await _service.GetFilteredAsync(
                    mine,
                    createdBy,
                    status,
                    visitorType,
                    phone
                );

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message, stack = ex.StackTrace });
            }
        }

        [HttpGet("{id:guid}")]
        [Authorize(Policy = "EmployeePolicy")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var result = await _service.GetByIdAsync(id);
            if (result == null)
                return NotFound($"Visitor invitation not found for id: {id}");

            return Ok(result);
        }

        [HttpGet("acted-by-me")]
        [Authorize(Policy = "ApproverPolicy")]
        public async Task<IActionResult> GetActedByMe()
        {
            var result = await _service.GetActedAsync();
            return Ok(result);
        }
        // ---------------- ADD OR DELETE ---------------

        [HttpPost("{id}/additional-visitors")]
        public async Task<IActionResult> AddVisitor(Guid id, [FromBody] AdditionalVisitorDto dto)
        {
            await _service.AddAdditionalVisitor(id, dto);
            return Ok();
        }

        [HttpDelete("additional-visitors/{id}")]
        public async Task<IActionResult> RemoveVisitor(int id)
        {
            await _service.RemoveAdditionalVisitor(id);
            return Ok(new { message = "Deleted successfully" });
        }

        // ---------------- UPDATE ----------------

        [HttpPut("{id:guid}")]
        [Authorize(Policy = "EmployeePolicy")]
        [Consumes("application/json")]
        public async Task<IActionResult> Update(
             Guid id,
             [FromBody] UpdateVisitorInvitationDto dto)
        {
            var result = await _service.UpdateAsync(id, dto);
            if (result == null)
                return NotFound($"Visitor invitation not found for id: {id}");

            return Ok(result);
        }

        //------------ReSchedule-----------

        [HttpPost("{id:guid}/reschedule")]
        [Authorize(Policy = "EmployeePolicy")]
        public async Task<IActionResult> Reschedule(
        Guid id,
        [FromBody] UpdateVisitorInvitationDto dto)
        {
            var updated = await _service.UpdateAsync(id, dto);

            if (updated == null)
                return NotFound($"Visitor invitation not found for id: {id}");

            return Ok(updated);
        }

        // ---------------- APPROVE ---------------- ✅ FIXED

        [HttpPost("{id:guid}/approve")]
        [Authorize(Policy = "ApproverPolicy")]
        public async Task<IActionResult> Approve(Guid id)
        {
        try
        {
        var result = await _service.ApproveAsync(id);
        if (result == null)
            return NotFound($"Visitor invitation not found for id: {id}");

        return Ok(result);
        }
    catch (Exception ex)
    {
        return StatusCode(500, new
        {
            error = ex.Message,
            stack = ex.StackTrace
        });
            }
        }

        // ---------------- REJECT ---------------- ✅ FIXED

        [HttpPost("{id:guid}/reject")]
        [Authorize(Policy = "ApproverPolicy")]
        [Consumes("application/json")]
        public async Task<IActionResult> Reject(
            Guid id,
            [FromBody] RejectVisitorInvitationDto? dto)
        {
            // ✅ CRITICAL: NULL CHECK
            if (dto == null || string.IsNullOrWhiteSpace(dto.Reason))
            {
                return BadRequest("Rejection reason is required.");
            }

            var result = await _service.RejectAsync(id, dto.Reason);
            if (result == null)
                return NotFound($"Visitor invitation not found for id: {id}");

            return Ok(result);
        }


        [HttpGet("count")]
        public async Task<IActionResult> GetCount(
        [FromQuery] bool mine = false,
        [FromQuery] string? status = null)
        {
            try
            {
                var items = await _service.GetFilteredAsync(
                    mine,
                    null,
                    status,
                    null,
                    null
                );

                return Ok(new { count = items.Count });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message, stack = ex.StackTrace });
            }
        }

        // ---------------- CHECK-IN / CHECK-OUT ----------------

        [HttpPost("{id:guid}/check-in")]
        [Authorize(Policy = "SecurityPolicy")]
        [Consumes("application/json")]
        public async Task<IActionResult> CheckIn(
            Guid id,
            [FromBody] CheckInVisitorDto dto)
        {
            try
            {
                var result = await _service.CheckInAsync(id, dto);

                if (result == null)
                    return NotFound(new { message = "Visitor invitation not found" });

                return Ok(new
                {
                    id = result.Id,
                    status = result.Status,
                    checkedInAt = result.CheckedInAt
                });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }


        [HttpPost("{id:guid}/check-out")]
        [Authorize(Policy = "SecurityPolicy")]
        public async Task<IActionResult> CheckOut(Guid id)
        {
            try
            {
                var result = await _service.CheckOutAsync(id);
                if (result == null)
                    return NotFound($"Visitor invitation not found for id: {id}");

                return Ok(result);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(ex.Message); // ✅ Correct status code
            }
        }
        // ---------------- PHOTO UPLOAD ----------------

        [HttpPost("{id:guid}/photo")]
        [Authorize(Policy = "SecurityPolicy")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadPhoto(Guid id, IFormFile photo)
        {
            if (photo == null || photo.Length == 0)
                return BadRequest("Photo is required.");

            const long maxBytes = 5 * 1024 * 1024;
            if (photo.Length > maxBytes)
                return BadRequest("Photo size cannot exceed 5 MB.");

            var allowedTypes = new[] { "image/jpeg", "image/png", "image/webp" };
            if (!allowedTypes.Contains(photo.ContentType?.ToLowerInvariant()))
                return BadRequest("Only JPG, PNG or WEBP images are allowed.");

            byte[] content;
            using (var ms = new MemoryStream())
            {
                await photo.CopyToAsync(ms);
                content = ms.ToArray();
            }

            var result = await _service.UploadPhotoAsync(
                id,
                photo.FileName,
                content);

            if (result == null)
                return NotFound($"Visitor invitation not found for id: {id}");

            return Ok(result);
        }

        // ---------------- DELETE ----------------

        [HttpDelete("{id:guid}")]
        [Authorize(Policy = "EmployeePolicy")]

        public async Task<IActionResult> Delete(Guid id)
        {
            var deleted = await _service.DeleteAsync(id);
            if (!deleted)
                return NotFound($"Visitor invitation not found for id: {id}");

            return Ok(new { message = "Deleted successfully" });
        }

        // ---------------- SAVE FACILITATOR NOTES ---------------- ✅ NEW

        [HttpPost("{id:guid}/facilitator-notes")]
        [Authorize(Policy = "ApproverPolicy")]
        [Consumes("application/json")]
        public async Task<IActionResult> SaveFacilitatorNotes(
            Guid id,
            [FromBody] SaveFacilitatorNotesDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Notes))
                return BadRequest("Notes cannot be empty.");

            var result = await _service.UpdateFacilitatorNotesAsync(
                id,
                dto.Notes,
                dto.Facilities
            );

            if (result == null)
                return NotFound($"Visitor invitation not found for id: {id}");

            return Ok(result);
        }
        [HttpPost("{id:guid}/close")]
        [Authorize]
        public async Task<IActionResult> Close(Guid id)
        {
            var userEmail = User.FindFirst("email")?.Value;
            var userRole = User.FindFirst("role")?.Value;

            if (string.IsNullOrWhiteSpace(userEmail))
                return Unauthorized("User email not found");

            try
            {
                await _service.CloseMeetingAsync(id, userEmail.ToLower(), userRole ?? "");

                return Ok(new { message = "Meeting closed successfully" });
            }
            catch (UnauthorizedAccessException ex)
            {
                return Forbid(ex.Message);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("today-checkedin-badges")]
        [Authorize(Policy = "SecurityPolicy")]
        public async Task<IActionResult> GetTodayCheckedInBadges()
        {
            var result = await _service.GetTodayCheckedInBadgesAsync();
            return Ok(result);
        }

        [HttpPost("{id:guid}/send-notification")]
        [Authorize(Policy = "EmployeePolicy")]
        public async Task<IActionResult> SendNotification(Guid id)
        {
            var sent = await _service.SendCreationNotificationEmailsAsync(id);
            if (!sent)
                return NotFound($"Visitor invitation not found for id: {id}");

            return Ok(new { message = "Notification emails sent to visitor and host." });
        }

        [HttpPost("{id:guid}/complete")]
        [Authorize(Policy = "EmployeePolicy")]
        public async Task<IActionResult> CompleteMeeting(
     Guid id,
     [FromBody] CompleteMeetingDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Remarks))
                return BadRequest("Remarks are required");

            var result = await _service.CompleteMeetingAsync(
                id,
                dto.Remarks,
                dto.VisitorAttended   // ✅ pass it
            );

            if (result == null)
                return NotFound($"Visitor invitation not found for id: {id}");

            return Ok(result);
        }

        // ---------------- CANCEL ----------------

        [HttpPost("{id:guid}/cancel")]
        [Authorize(Policy = "SecurityPolicy")]
        [Consumes("application/json")]
        public async Task<IActionResult> Cancel(
            Guid id,
            [FromBody] CancelVisitorInvitationDto dto)
        {
            if (string.IsNullOrWhiteSpace(dto.Reason))
                return BadRequest("Cancellation reason is required.");

            try
            {
                var result = await _service.CancelAsync(id, dto);
                if (result == null)
                    return NotFound($"Visitor invitation not found for id: {id}");

                return Ok(result);
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }



    }
}