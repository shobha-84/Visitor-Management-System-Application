﻿using InternalPortal.Application.DTOs;
using InternalPortal.Application.Services;
using Microsoft.AspNetCore.Mvc;

namespace InternalPortal.API.Controllers
{
    [ApiController]
    [Route("api/recurring")]
    public class RecurringController : ControllerBase
    {
        private readonly RecurringService _service;

        public RecurringController(RecurringService service)
        {
            _service = service;
        }

        // ✅ ✅ PHOTO (FIXED ROUTE)
        [HttpPost("{id}/photo")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UploadPhoto(
     Guid id,
     [FromForm] RecurringPhotoRequest request
 )
        {
            try
            {
                var result = await _service.UploadPhotoAsync(id, request.Photo);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }
        // ✅ ✅ CHECK-IN (FIXED ROUTE)
        [HttpPost("{id}/check-in")]
        public async Task<IActionResult> CheckIn(Guid id, [FromBody] RecurringCheckInRequest? req)
        {
            try
            {
                req ??= new RecurringCheckInRequest();

                var result = await _service.CheckInAsync(id, req);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }

        // ✅ ✅ CHECK-OUT
        [HttpPost("{id}/check-out")]
        public async Task<IActionResult> CheckOut(Guid id)
        {
            try
            {
                await _service.CheckOutAsync(id);
                return Ok(new { message = "Checked out successfully" });
            }
            catch (Exception ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }

        // ✅ ✅ HISTORY
        [HttpGet("history")]
        public async Task<IActionResult> GetHistory([FromQuery] string phone)
        {
            var result = await _service.GetHistoryAsync(phone);
            return Ok(result);
        }
    }
}
