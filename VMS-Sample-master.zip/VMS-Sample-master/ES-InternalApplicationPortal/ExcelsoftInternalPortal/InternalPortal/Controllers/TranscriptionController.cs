using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace InternalPortal.API.Controllers;

[ApiController]
[Route("api/transcription")]
public class TranscriptionController : ControllerBase
{
    private readonly HttpClient _voskHttpClient;
    private readonly ILogger<TranscriptionController> _logger;

    public TranscriptionController(
        IHttpClientFactory httpClientFactory,
        IConfiguration configuration,
        ILogger<TranscriptionController> logger)
    {
        _logger = logger;
        _voskHttpClient = httpClientFactory.CreateClient("VoskService");
    }

    [HttpPost("vosk")]
    [Consumes("multipart/form-data")]
    [DisableRequestSizeLimit]
    public async Task<IActionResult> Transcribe([FromForm] IFormFile audio)
    {
        if (audio == null || audio.Length == 0)
        {
            return BadRequest(new { error = "No audio file provided." });
        }

        const int maxRetries = 3;
        var delay = TimeSpan.FromSeconds(1);

        for (int attempt = 1; attempt <= maxRetries; attempt++)
        {
            try
            {
                using var content = new MultipartFormDataContent();
                using var streamContent = new StreamContent(audio.OpenReadStream());
                content.Add(streamContent, "audio", audio.FileName);

                var response = await _voskHttpClient.PostAsync("/api/transcribe/vosk", content);

                if (!response.IsSuccessStatusCode)
                {
                    var errorContent = await response.Content.ReadAsStringAsync();
                    _logger.LogWarning("Vosk service returned error (attempt {Attempt}/{MaxRetries}): {StatusCode} - {Content}",
                        attempt, maxRetries, response.StatusCode, errorContent);

                    if (attempt == maxRetries)
                    {
                        return StatusCode(502, new { error = "Vosk service error", detail = errorContent });
                    }
                    await Task.Delay(delay);
                    delay = TimeSpan.FromSeconds(delay.TotalSeconds * 2);
                    continue;
                }

                var resultContent = await response.Content.ReadAsStringAsync();
                return Ok(JsonSerializer.Deserialize<JsonElement>(resultContent));
            }
            catch (HttpRequestException ex) when (attempt < maxRetries)
            {
                _logger.LogWarning(ex, "Vosk service request failed (attempt {Attempt}/{MaxRetries}). Retrying...", attempt, maxRetries);
                await Task.Delay(delay);
                delay = TimeSpan.FromSeconds(delay.TotalSeconds * 2);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Transcription request failed.");
                return StatusCode(502, new { error = "Vosk service unavailable. Please try again later." });
            }
        }

        return StatusCode(502, new { error = "Vosk service unavailable after retries." });
    }

    [HttpGet("health")]
    public async Task<IActionResult> HealthCheck()
    {
        try
        {
            var response = await _voskHttpClient.GetAsync("/health");
            if (!response.IsSuccessStatusCode)
            {
                return Ok(new { status = "unavailable", vosk_loaded = false });
            }
            var content = await response.Content.ReadAsStringAsync();
            return Ok(JsonSerializer.Deserialize<JsonElement>(content));
        }
        catch
        {
            return Ok(new { status = "unavailable", vosk_loaded = false });
        }
    }
}
