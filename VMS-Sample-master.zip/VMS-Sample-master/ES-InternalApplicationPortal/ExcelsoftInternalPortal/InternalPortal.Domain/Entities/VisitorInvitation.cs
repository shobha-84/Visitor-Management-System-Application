﻿namespace InternalPortal.Domain.Entities
{
    public class VisitorInvitation
    {
        public Guid Id { get; set; }

        public string VisitorName { get; set; }
        public string VisitorCompany { get; set; }
        public string? VisitorEmail { get; set; }
        public string VisitorPhone { get; set; }

        public int NumberOfVisitors { get; set; } = 1;
        public string? Remarks { get; set; }

        public DateOnly VisitStartDate { get; set; }
        public DateOnly VisitEndDate { get; set; }

        public TimeSpan VisitStartTime { get; set; }
        public TimeSpan VisitEndTime { get; set; }

        public string Purpose { get; set; }
        public string? PurposeOthers { get; set; }
        public string Department { get; set; }
        public string AdditionalRequirements { get; set; }

        public string? FacilitatorNotes { get; set; }
        public string? RejectionReason { get; set; }
        public string? VisitorPhotoUrl { get; set; }

        public string Status { get; set; } = "Pending";

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? CheckedInAt { get; set; }
        public DateTime? CheckedOutAt { get; set; }

        public string HostName { get; set; } = string.Empty;
        public string HostEmail { get; set; } = string.Empty;

        public string? ClosedBy { get; set; }
        public DateTime? ClosedAt { get; set; }

        public string? BadgeNumber { get; set; }
        public string? LaptopName { get; set; }
        public string? MacAddress { get; set; }

        public string CreatedBy { get; set; } = string.Empty;

        public string VisitorType { get; set; } = "Non-Recurring";

        public bool VisitorAttended { get; set; }
        public ICollection<VisitorAdditional> AdditionalVisitors { get; set; } = new List<VisitorAdditional>();



        public string? HostRemarks { get; set; }

        public bool MeetingCompleted { get; set; }

        public string? IdentityProofType { get; set; }

        public bool IsDocumentVerified { get; set; }

        public string? VerifiedBy { get; set; }

        public DateTime? VerifiedOn { get; set; }

        public string? CancelledBy { get; set; }

        public DateTime? CancelledAt { get; set; }

        public string? CancellationReason { get; set; }

    }
}