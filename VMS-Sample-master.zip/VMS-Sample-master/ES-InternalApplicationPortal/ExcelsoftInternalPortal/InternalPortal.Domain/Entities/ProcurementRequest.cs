﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcurementAPI.Models
{
    [Table("store_requests")]
    public class StoreRequest
    {
        [Column("id")]
        public Guid Id { get; set; }

        [Column("created_by")]
        public string CreatedBy { get; set; }

        [Column("title")]
        public string Title { get; set; }

        [Column("description")]
        public string? Description { get; set; }

        [Column("category")]
        public string Category { get; set; }

        [Column("is_it_related")]
        public bool IsItRelated { get; set; }

        [Column("estimated_cost")]
        public decimal? EstimatedCost { get; set; }

        [Column("quantity")]
        public int Quantity { get; set; }

        [Column("urgency")]
        public string Urgency { get; set; }

        [Column("department")]
        public string? Department { get; set; }

        [Column("vendor_details")]
        public string? VendorDetails { get; set; }

        [Column("notes")]
        public string? Notes { get; set; }

        [Column("status")]
        public string Status { get; set; }

        [Column("current_approver_role")]
        public string? CurrentApproverRole { get; set; }

        // Approval fields
        [Column("ops_manager_approved_at")]
        public DateTime? OpsManagerApprovedAt { get; set; }

        [Column("it_manager_approved_at")]
        public DateTime? ItManagerApprovedAt { get; set; }

        [Column("coo_approved_at")]
        public DateTime? CooApprovedAt { get; set; }

        [Column("finance_authorized_at")]
        public DateTime? FinanceAuthorizedAt { get; set; }

        [Column("hr_approved_at")]
        public DateTime? HrApprovedAt { get; set; }

        [Column("po_released_at")]
        public DateTime? PoReleasedAt { get; set; }

        [Column("rejection_reason")]
        public string? RejectionReason { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; }

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; }
    }
}
