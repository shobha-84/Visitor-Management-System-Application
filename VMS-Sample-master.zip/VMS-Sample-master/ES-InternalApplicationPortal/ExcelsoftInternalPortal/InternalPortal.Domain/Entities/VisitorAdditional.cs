﻿using InternalPortal.Domain.Entities;
using System.Text.Json.Serialization; // ✅ ADD THIS

public class VisitorAdditional
{
    public int Id { get; set; }

    public Guid InvitationId { get; set; }

    public string Name { get; set; }
    public string Email { get; set; }
    public string Phone { get; set; }
    public string Company { get; set; }

    [JsonIgnore] // ✅ THIS IS THE MOST IMPORTANT FIX
    public VisitorInvitation VisitorInvitation { get; set; }
}