﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternalPortal.Domain.Entities
{
    [Table("users", Schema = "internalapplicationportaldb")]
    public class User
    {
        [Column("id")]
        public Guid Id { get; set; }

        [Column("username")]
        public string Username { get; set; }

        [Column("email")]
        public string Email { get; set; }

        [Column("password_hash")]
        public string PasswordHash { get; set; }

        [Column("role_id")]
        public int RoleId { get; set; }

        public Role Role { get; set; }
    }

}
