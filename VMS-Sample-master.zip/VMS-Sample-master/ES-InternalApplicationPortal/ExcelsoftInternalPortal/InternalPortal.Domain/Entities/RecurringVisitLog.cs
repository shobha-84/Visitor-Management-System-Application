﻿namespace InternalPortal.Domain.Entities
{
    public class RecurringVisitLog
    {
        public Guid id { get; set; }

        public Guid invitation_id { get; set; }

        public string ?visitor_phone { get; set; }

        public DateTime? check_in_time { get; set; }

        public DateTime? check_out_time { get; set; }

        public string ?status { get; set; }

        public string ?badge_number { get; set; }

        public bool has_laptop { get; set; }

        public string ?laptop_name { get; set; }

        public string ?mac_address { get; set; }

        public string ?photo_url { get; set; }

        public string? identity_proof_type { get; set; }

        public bool is_document_verified { get; set; }

        public string? verified_by { get; set; }

        public DateTime? verified_on { get; set; }

        public DateTime created_at { get; set; } = DateTime.UtcNow;
    }
}