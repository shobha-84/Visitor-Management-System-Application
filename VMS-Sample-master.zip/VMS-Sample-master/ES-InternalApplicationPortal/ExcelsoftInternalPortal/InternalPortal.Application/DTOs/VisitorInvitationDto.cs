﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace InternalPortal.Application.DTOs
{
    public class VisitorInvitationDto
    {

        public Guid Id { get; set; }

        public string VisitorName { get; set; }
        public string VisitorEmail { get; set; }
        public string VisitorPhone { get; set; }
        public string VisitorCompany { get; set; }

        public string HostName { get; set; }
        public string HostEmail { get; set; }

        public string Status { get; set; }

        public DateTime? CheckedInAt { get; set; }
        public DateTime? CheckedOutAt { get; set; }

        public string BadgeNumber { get; set; }
        public string LaptopName { get; set; }
        public string MacAddress { get; set; }

        public string? VisitorPhotoUrl { get; set; }

        public DateOnly VisitStartDate { get; set; }
        public DateOnly VisitEndDate { get; set; }
        public TimeSpan VisitStartTime { get; set; }
        public TimeSpan VisitEndTime { get; set; }

        public string Purpose { get; set; }
        [JsonPropertyName("purpose_others")]
        public string? PurposeOthers { get; set; }
        public string Department { get; set; }

        public string AdditionalRequirements { get; set; }
        public string FacilitatorNotes { get; set; }

        public string VisitorType { get; set; }

        public bool MeetingCompleted { get; set; }
        public string HostRemarks { get; set; }
        public bool VisitorAttended { get; set; }

        public string? Remarks { get; set; }
        public List<AdditionalVisitorDto> AdditionalVisitors { get; set; }

        public string CreatedBy { get; set; }

        public string? CancelledBy { get; set; }

        public DateTime? CancelledAt { get; set; }

        public string? CancellationReason { get; set; }

    }
}
