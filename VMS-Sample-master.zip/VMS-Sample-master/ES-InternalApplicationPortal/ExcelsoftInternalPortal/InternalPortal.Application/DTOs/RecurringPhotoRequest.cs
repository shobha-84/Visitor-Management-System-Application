﻿using Microsoft.AspNetCore.Http;

namespace InternalPortal.Application.DTOs
{
    public class RecurringPhotoRequest
    {
        public IFormFile Photo { get; set; }  // ✅ FIXED
    }
}
