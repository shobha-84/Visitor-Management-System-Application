﻿using System.Text.Json.Serialization;

namespace InternalPortal.Application.DTOs
{
    public class CreateStoreRequestDto
    {
        [JsonPropertyName("created_by")]
        public string CreatedBy { get; set; }

        [JsonPropertyName("title")]
        public string Title { get; set; }

        [JsonPropertyName("description")]
        public string? Description { get; set; }

        [JsonPropertyName("category")]
        public string Category { get; set; }

        [JsonPropertyName("is_it_related")]
        public bool IsItRelated { get; set; }

        [JsonPropertyName("estimated_cost")]
        public decimal? EstimatedCost { get; set; }

        [JsonPropertyName("quantity")]
        public int Quantity { get; set; }

        [JsonPropertyName("urgency")]
        public string Urgency { get; set; }

        [JsonPropertyName("department")]
        public string? Department { get; set; }

        [JsonPropertyName("vendor_details")]
        public string? VendorDetails { get; set; }

        [JsonPropertyName("notes")]
        public string? Notes { get; set; }
    }
}
