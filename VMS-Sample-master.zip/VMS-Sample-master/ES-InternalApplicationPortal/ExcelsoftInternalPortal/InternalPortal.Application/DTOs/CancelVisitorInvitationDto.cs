using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternalPortal.Application.DTOs
{
    public class CancelVisitorInvitationDto
    {
        [Required]
        public string Reason { get; set; } = string.Empty;

        [Required]
        public string CancelledBy { get; set; } = string.Empty;
    }
}
