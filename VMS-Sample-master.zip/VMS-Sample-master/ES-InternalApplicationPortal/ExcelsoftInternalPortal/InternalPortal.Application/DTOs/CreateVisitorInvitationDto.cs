﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.Json.Serialization;

namespace InternalPortal.Application.DTOs
{
    public class CreateVisitorInvitationDto
    {
        [Required]
        [MaxLength(200)]
        public string VisitorName { get; set; } = string.Empty;

        public List<AdditionalVisitorDto> AdditionalVisitors { get; set; }

        [MaxLength(200)]
        public string VisitorCompany { get; set; } = string.Empty;

        [MaxLength(200)]
        public string VisitorEmail { get; set; } = string.Empty;

        [MaxLength(50)]
        public string VisitorPhone { get; set; } = string.Empty;

        [Range(1, 99)]
        public int NumberOfVisitors { get; set; } = 1;

        [MaxLength(500)]
        [RegularExpression(@"^[a-zA-Z0-9\s.,\-_/&():;''%#@+=!?]{0,500}$", ErrorMessage = "Only letters, numbers, spaces, and standard business special characters (.,-_/&():;'\"%#@+=!?) are allowed.")]
        public string Remarks { get; set; } = string.Empty;

        [Required]
        public DateTime VisitStartDate { get; set; }

        [Required]
        public DateTime VisitEndDate { get; set; }

        [Required]
        public TimeSpan VisitStartTime { get; set; }

        [Required]
        public TimeSpan VisitEndTime { get; set; }

        [Required]
        [MaxLength(200)]
        public string Purpose { get; set; } = string.Empty;

        [MaxLength(500)]
        [RegularExpression(@"^[a-zA-Z0-9\s.,\-_/&():;''%#@+=!?]{0,500}$", ErrorMessage = "Only letters, numbers, spaces, and standard business special characters (.,-_/&():;'\"%#@+=!?) are allowed.")]
        [JsonPropertyName("purpose_others")]
        public string? PurposeOthers { get; set; }

        [Required]
        [MaxLength(100)]
        public string Department { get; set; } = string.Empty;

        [MaxLength(5000)]
        public string AdditionalRequirements { get; set; } = string.Empty;

        [RegularExpression("^(draft|pending|approved|rejected|checked_in|checked_out)$", ErrorMessage = "Invalid status")]
        public string Status { get; set; } = string.Empty;

        [Required]
        [MaxLength(200)]
        public string HostName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [MaxLength(200)]
        public string HostEmail { get; set; } = string.Empty;

        [Required]
        [RegularExpression("^(Recurring|Non-Recurring)$", ErrorMessage = "Invalid visitor type")]
        public string VisitorType { get; set; } = "Non-Recurring";

        [MaxLength(100)]
        [EmailAddress]
        public string? CreatedBy { get; set; }

    }
}
