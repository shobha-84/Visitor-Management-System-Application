﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternalPortal.Application.DTOs
{

    public class SaveFacilitatorNotesDto
    {

        public string Notes { get; set; } = string.Empty;

        // ✅ Facility keys e.g. ["wifi", "parking", "food"]
        public List<string> Facilities { get; set; } = new();

    }

}
