﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternalPortal.Application.DTOs
{
    internal class VisitorBadgeDto
    {
        public string? BadgeNumber { get; set; }
    }
}
