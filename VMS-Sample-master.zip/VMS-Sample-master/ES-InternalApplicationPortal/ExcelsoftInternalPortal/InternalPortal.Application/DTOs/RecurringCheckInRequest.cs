﻿namespace InternalPortal.Application.DTOs
{
    public class RecurringCheckInRequest
    {
        public string BadgeNumber { get; set; }

        public bool HasLaptop { get; set; }

        public string? LaptopName { get; set; }

        public string? MacAddress { get; set; }

        public string? IdentityProofType { get; set; }

        public bool IsDocumentVerified { get; set; }

        public string? VerifiedBy { get; set; }
    }
}