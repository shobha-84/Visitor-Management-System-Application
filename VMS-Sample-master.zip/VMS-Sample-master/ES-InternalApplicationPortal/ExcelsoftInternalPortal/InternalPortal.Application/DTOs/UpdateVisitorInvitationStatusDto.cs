namespace InternalPortal.Application.DTOs
{
    public class UpdateVisitorInvitationStatusDto
    {
        public string Status { get; set; } = string.Empty;
    }
}
