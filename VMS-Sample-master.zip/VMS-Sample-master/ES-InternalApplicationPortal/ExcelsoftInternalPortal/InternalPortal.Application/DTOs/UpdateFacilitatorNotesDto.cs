namespace InternalPortal.Application.DTOs
{
    public class UpdateFacilitatorNotesDto
    {
        public string Notes { get; set; } = string.Empty;
    }
}
