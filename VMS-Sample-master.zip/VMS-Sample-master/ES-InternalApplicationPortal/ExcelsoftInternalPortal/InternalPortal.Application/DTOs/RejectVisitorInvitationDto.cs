namespace InternalPortal.Application.DTOs
{
    public class RejectVisitorInvitationDto
    {
        public string Reason { get; set; } = string.Empty;

    }
}
