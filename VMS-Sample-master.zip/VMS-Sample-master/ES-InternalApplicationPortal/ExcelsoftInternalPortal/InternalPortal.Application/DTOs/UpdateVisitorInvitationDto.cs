﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;


namespace InternalPortal.Application.DTOs
{
    public class UpdateVisitorInvitationDto
    {
        public string? VisitorName { get; set; }

        public string? VisitorCompany { get; set; }

        public string? VisitorEmail { get; set; }

        public string? VisitorPhone { get; set; }

        public int? NumberOfVisitors { get; set; }

        [MaxLength(500)]
        [RegularExpression(@"^[a-zA-Z0-9\s.,\-_/&():;''%#@+=!?]{0,500}$", ErrorMessage = "Only letters, numbers, spaces, and standard business special characters (.,-_/&():;'\"%#@+=!?) are allowed.")]
        public string? Remarks { get; set; }

        public DateTime? VisitStartDate { get; set; }

        public DateTime? VisitEndDate { get; set; }

        public TimeSpan? VisitStartTime { get; set; }

        public TimeSpan? VisitEndTime { get; set; }

        public string? Purpose { get; set; }

        [MaxLength(500)]
        [RegularExpression(@"^[a-zA-Z0-9\s.,\-_/&():;''%#@+=!?]{0,500}$", ErrorMessage = "Only letters, numbers, spaces, and standard business special characters (.,-_/&():;'\"%#@+=!?) are allowed.")]
        [JsonPropertyName("purpose_others")]
        public string? PurposeOthers { get; set; }

        public string? Department { get; set; }

        public string? AdditionalRequirements { get; set; }

        public string? Status { get; set; }

        public string? HostName { get; set; }

        public string? HostEmail { get; set; }
        public string? VisitorType { get; set; }

        public List<AdditionalVisitorDto> AdditionalVisitors { get; set; } = new();
    }
}
