﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InternalPortal.Application.DTOs
{
    public class CompleteMeetingDto
    {
        public string Remarks { get; set; } = string.Empty;
        public bool VisitorAttended { get; set; }
    }
}
