﻿namespace InternalPortal.Application.DTOs
{
    public class CheckInVisitorDto
    {
        public string BadgeNumber { get; set; } = string.Empty;
        public bool HasLaptop { get; set; }

        public string? LaptopName { get; set; }
        public string? MacAddress { get; set; }

        public string? TimezoneId { get; set; }

        public string? IdentityProofType { get; set; }

        public bool IsDocumentVerified { get; set; }

        public string? VerifiedBy { get; set; }
    }
}
