namespace InternalPortal.Application.DTOs
{
    public class SendArrivalNotificationDto
    {
        public Guid VisitorRequestId { get; set; }
    }
}
