namespace InternalPortal.Application.Options
{
    public class SmtpSettings
    {
        public const string SectionName = "Smtp";

        public string Host { get; set; } = string.Empty;
        public int Port { get; set; } = 587;
        public bool EnableSsl { get; set; } = true;
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
        public string FromEmail { get; set; } = string.Empty;
        public string FromName { get; set; } = "Internal Portal";
        public bool Enabled { get; set; } = true;
        /// <summary>SMTP connect/send timeout in seconds.</summary>
        public int TimeoutSeconds { get; set; } = 60;
        public int SendMail { get; set; } = 1;
    }
}
