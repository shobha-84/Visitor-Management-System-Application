namespace InternalPortal.Application.Options
{
    public class SendGridSettings
    {
        public const string SectionName = "SendGridSettings";

        public string ApiKey { get; set; } = string.Empty;
        public string SenderEmail { get; set; } = string.Empty;
        public string SenderName { get; set; } = "Visitor Management System";
        /// <summary>Set to 1 to enable live email sending, 0 to dump emails as HTML files to MailDump folder.</summary>
        public int SendMail { get; set; } = 1;
    }
}
