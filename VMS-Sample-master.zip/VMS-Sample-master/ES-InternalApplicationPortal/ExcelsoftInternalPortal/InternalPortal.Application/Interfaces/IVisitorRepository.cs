﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InternalPortal.Domain.Entities;

namespace InternalPortal.Application.Interfaces
{
    public interface IVisitorRepository
    {
        Task AddAsync(VisitorInvitation entity);
        Task<VisitorInvitation?> GetByIdAsync(Guid id);
        Task<List<VisitorInvitation>> GetAllAsync();

        Task AddAdditionalAsync(VisitorAdditional visitor);

        Task AddAdditionalRangeAsync(List<VisitorAdditional> visitors);

        Task RemoveAdditionalAsync(int id);
        Task<List<VisitorAdditional>> GetAdditionalsByInvitation(Guid id);

        void Update(VisitorInvitation entity);
        void Delete(VisitorInvitation entity);

        Task SaveChangesAsync();

        Task<List<string>> GetTodayCheckedInBadgesAsync();
    }
}

