namespace InternalPortal.Application.Interfaces
{
    public interface IMailDumpService
    {
        Task<string> DumpEmailAsync(
            string toEmail,
            string toName,
            string subject,
            string htmlBody,
            string requestId);
    }
}
