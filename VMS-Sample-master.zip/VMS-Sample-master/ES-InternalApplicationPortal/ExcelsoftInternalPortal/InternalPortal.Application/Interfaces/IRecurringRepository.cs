﻿using InternalPortal.Domain.Entities;

namespace InternalPortal.Application.Interfaces
{
    public interface IRecurringRepository
    {
        Task<VisitorInvitation?> GetInvitationByIdAsync(Guid id);

        Task<List<RecurringVisitLog>> GetHistoryAsync(string phone);

        Task AddLogAsync(RecurringVisitLog log);
        Task<List<RecurringVisitLog>> GetActiveLogsAsync();

        Task<RecurringVisitLog?> GetLatestRecurringVisitorAsync(string phone);

        Task<RecurringVisitLog?> GetActiveLogAsync(string phone);

        Task SaveChangesAsync();
    }
}