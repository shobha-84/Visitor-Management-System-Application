﻿using System;
using System.Threading.Tasks;

namespace InternalPortal.Application.Interfaces
{
    public interface IVisitorPhotoStorage
    {
        Task<string> SaveAsync(
            Guid invitationId,
            string originalFileName,
            byte[] content);
    }
}
