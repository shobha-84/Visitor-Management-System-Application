using InternalPortal.Domain.Entities;

namespace InternalPortal.Application.Interfaces
{
    public interface IVisitorInvitationEmailNotifier
    {
        Task SendCreationNotificationsAsync(VisitorInvitation invitation);
        Task SendUpdateNotificationsAsync(VisitorInvitation invitation);
        Task SendArrivalNotificationAsync(VisitorInvitation invitation, string? timeZoneId = null);
    }
}
