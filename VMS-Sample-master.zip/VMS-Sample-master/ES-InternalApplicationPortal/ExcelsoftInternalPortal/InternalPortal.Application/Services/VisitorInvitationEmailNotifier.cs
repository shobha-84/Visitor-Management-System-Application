using InternalPortal.Application.Interfaces;
using InternalPortal.Domain.Entities;
using Microsoft.Extensions.Logging;

namespace InternalPortal.Application.Services
{
    public class VisitorInvitationEmailNotifier : IVisitorInvitationEmailNotifier
    {
        private readonly IEmailService _emailService;
        private readonly ILogger<VisitorInvitationEmailNotifier> _logger;

        public VisitorInvitationEmailNotifier(
            IEmailService emailService,
            ILogger<VisitorInvitationEmailNotifier> logger)
        {
            _emailService = emailService;
            _logger = logger;
        }

        public async Task SendCreationNotificationsAsync(VisitorInvitation invitation)
        {
            var visitDate = FormatVisitDate(invitation);
            var visitTime = FormatVisitTime(invitation);

            await TrySendAsync(
                invitation.HostEmail,
                invitation.HostName,
                $"Visitor invitation created for {invitation.VisitorName}",
                BuildHostEmailBody(invitation, visitDate, visitTime));
        }

        public async Task SendUpdateNotificationsAsync(VisitorInvitation invitation)
        {
            var visitDate = FormatVisitDate(invitation);
            var visitTime = FormatVisitTime(invitation);

            await TrySendAsync(
                invitation.HostEmail,
                invitation.HostName,
                $"Visitor invitation updated for {invitation.VisitorName}",
                BuildHostUpdateEmailBody(invitation, visitDate, visitTime));
        }

        private async Task TrySendAsync(
            string toEmail,
            string toName,
            string subject,
            string htmlBody)
        {
            if (string.IsNullOrWhiteSpace(toEmail))
            {
                _logger.LogWarning("Skipping email '{Subject}' because recipient address is empty.", subject);
                return;
            }

            try
            {
                await _emailService.SendAsync(toEmail.Trim(), toName, subject, htmlBody);
                _logger.LogInformation("Sent email '{Subject}' to {Email}.", subject, toEmail);
            }
            catch (OperationCanceledException ex)
            {
                _logger.LogError(
                    ex,
                    "Email send timed out for '{Subject}' to {Email}. SMTP host may be unreachable (firewall/port 587).",
                    subject,
                    toEmail);
            }
            catch (InvalidOperationException ex)
            {
                _logger.LogError(ex, "Email send failed for '{Subject}' to {Email}. {Message}", subject, toEmail, ex.Message);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Failed to send email '{Subject}' to {Email}.", subject, toEmail);
            }
        }

        private static string FormatVisitDate(VisitorInvitation invitation)
        {
            if (invitation.VisitStartDate == invitation.VisitEndDate)
                return invitation.VisitStartDate.ToString("dddd, dd MMM yyyy");

            return $"{invitation.VisitStartDate:dd MMM yyyy} – {invitation.VisitEndDate:dd MMM yyyy}";
        }

        private static string FormatVisitTime(VisitorInvitation invitation)
        {
            return $"{invitation.VisitStartTime:hh\\:mm} – {invitation.VisitEndTime:hh\\:mm}";
        }

        private static string BuildVisitorEmailBody(
            VisitorInvitation invitation,
            string visitDate,
            string visitTime)
        {
            return $"""
                <p>Dear {Escape(invitation.VisitorName)},</p>
                <p>Your visit invitation has been created successfully.</p>
                <table style="border-collapse:collapse;">
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Host</strong></td><td>{Escape(invitation.HostName)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Date</strong></td><td>{Escape(visitDate)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Time</strong></td><td>{Escape(visitTime)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Purpose</strong></td><td>{Escape(invitation.Purpose)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Department</strong></td><td>{Escape(invitation.Department)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Status</strong></td><td>{Escape(invitation.Status)}</td></tr>
                </table>
                <p>Please carry a valid ID when you arrive.</p>
                <p>Regards,<br/>Team Administration</p>
                """;
        }

        private static string BuildHostEmailBody(
            VisitorInvitation invitation,
            string visitDate,
            string visitTime)
        {
            return $"""
                <p>Dear {Escape(invitation.HostName)},</p>
                <p>A visitor invitation has been created for you.</p>
                <table style="border-collapse:collapse;">
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Visitor</strong></td><td>{Escape(invitation.VisitorName)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Email</strong></td><td>{Escape(invitation.VisitorEmail)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Phone</strong></td><td>{Escape(invitation.VisitorPhone)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Company</strong></td><td>{Escape(invitation.VisitorCompany)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Date</strong></td><td>{Escape(visitDate)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Time</strong></td><td>{Escape(visitTime)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Purpose</strong></td><td>{Escape(invitation.Purpose)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Status</strong></td><td>{Escape(invitation.Status)}</td></tr>
                </table>
                <p>Regards,<br/>Team Administration</p>
                """;
        }

        private static string BuildHostUpdateEmailBody(
            VisitorInvitation invitation,
            string visitDate,
            string visitTime)
        {
            return $"""
                <p>Dear {Escape(invitation.HostName)},</p>
                <p>Your visitor invitation has been updated.</p>
                <table style="border-collapse:collapse;">
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Visitor</strong></td><td>{Escape(invitation.VisitorName)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Email</strong></td><td>{Escape(invitation.VisitorEmail)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Phone</strong></td><td>{Escape(invitation.VisitorPhone)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Company</strong></td><td>{Escape(invitation.VisitorCompany)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Date</strong></td><td>{Escape(visitDate)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Time</strong></td><td>{Escape(visitTime)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Purpose</strong></td><td>{Escape(invitation.Purpose)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Status</strong></td><td>{Escape(invitation.Status)}</td></tr>
                </table>
                <p>Regards,<br/>Team Administration</p>
                """;
        }

        private static string Escape(string? value) =>
            System.Net.WebUtility.HtmlEncode(value ?? string.Empty);

        public async Task SendArrivalNotificationAsync(VisitorInvitation invitation, string? timeZoneId = null)
        {
            await TrySendAsync(
                invitation.HostEmail,
                invitation.HostName,
                "Visitor Arrival Notification",
                BuildArrivalEmailBody(invitation, timeZoneId));
        }

        private static string BuildArrivalEmailBody(VisitorInvitation invitation, string? timeZoneId)
        {
            var checkInTime = invitation.CheckedInAt is not null &&
                              !string.IsNullOrWhiteSpace(timeZoneId)
                ? ConvertFromUtc(invitation.CheckedInAt.Value, timeZoneId)
                : invitation.CheckedInAt?.ToString("dddd, dd MMM yyyy hh:mm tt")
                    ?? "N/A";

            return $"""
                <p>Dear {Escape(invitation.HostName)},</p>
                <p>This is to inform you that your visitor has arrived at the reception.</p>
                <table style="border-collapse:collapse;">
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Visitor Name:</strong></td><td>{Escape(invitation.VisitorName)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Phone:</strong></td><td>{Escape(invitation.VisitorPhone)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Purpose:</strong></td><td>{Escape(invitation.Purpose)}</td></tr>
                    <tr><td style="padding:4px 12px 4px 0;"><strong>Check-In Time:</strong></td><td>{Escape(checkInTime)}</td></tr>
                </table>
                <p>Kindly proceed to the reception and escort the visitor.</p>
                <p>Regards,<br/>Team Administration.</p>
                """;
        }

        /// <summary>
        /// Converts a UTC DateTime to the target timezone using IANA timezone IDs.
        /// Falls back to UTC conversion if the timezone is invalid.
        /// </summary>
        private static string ConvertFromUtc(DateTime utcDateTime, string timeZoneId)
        {
            try
            {
                var targetZone = TimeZoneInfo.FindSystemTimeZoneById(timeZoneId);
                var convertedTime = TimeZoneInfo.ConvertTimeFromUtc(utcDateTime, targetZone);
                return convertedTime.ToString("dddd, dd MMM yyyy hh:mm tt");
            }
            catch (TimeZoneNotFoundException)
            {
                return utcDateTime.ToString("dddd, dd MMM yyyy hh:mm tt") + " (UTC)";
            }
            catch (InvalidTimeZoneException)
            {
                return utcDateTime.ToString("dddd, dd MMM yyyy hh:mm tt") + " (UTC)";
            }
        }
    }
}
