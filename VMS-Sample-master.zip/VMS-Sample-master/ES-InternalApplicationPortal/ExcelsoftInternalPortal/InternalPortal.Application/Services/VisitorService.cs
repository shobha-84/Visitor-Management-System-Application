﻿using InternalPortal.Application.Common;
using InternalPortal.Application.DTOs;
using InternalPortal.Application.Interfaces;
using InternalPortal.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Threading.Tasks;

namespace InternalPortal.Application.Services
{
    public class VisitorService
    {

        private static readonly HashSet<string> AllowedStatuses =
            new(StringComparer.OrdinalIgnoreCase)
            {
                "draft",
                InvitationStatuses.Pending,
                InvitationStatuses.Approved,
                InvitationStatuses.Rejected,
                InvitationStatuses.CheckedIn,
                InvitationStatuses.CheckedOut,
                InvitationStatuses.Cancelled,
                "closed"
            };

        private readonly IVisitorRepository _repository;
        private readonly IVisitorPhotoStorage _photoStorage;
        private readonly IVisitorInvitationEmailNotifier _emailNotifier;

        public VisitorService(
            IVisitorRepository repository,
            IVisitorPhotoStorage photoStorage,
            IVisitorInvitationEmailNotifier emailNotifier)
        {
            _repository = repository;
            _photoStorage = photoStorage;
            _emailNotifier = emailNotifier;
        }

        // ---------------- CREATE ----------------
        public async Task<VisitorInvitation> CreateAsync(CreateVisitorInvitationDto dto)
        {

            var status = string.IsNullOrWhiteSpace(dto.Status)
                 ? InvitationStatuses.Approved   // ✅ default if nothing sent
                 : dto.Status.ToLower();

            if (!AllowedStatuses.Contains(status))
            {
                status = InvitationStatuses.Approved;
            }

            var entity = new VisitorInvitation
            {
                VisitorName = dto.VisitorName,
                VisitorCompany = dto.VisitorCompany,
                VisitorEmail = dto.VisitorEmail,
                VisitorPhone = dto.VisitorPhone,
                NumberOfVisitors = dto.NumberOfVisitors,
                Remarks = dto.Remarks,
                VisitStartDate = DateOnly.FromDateTime(dto.VisitStartDate),
                VisitEndDate = DateOnly.FromDateTime(dto.VisitEndDate),
                VisitStartTime = dto.VisitStartTime,
                VisitEndTime = dto.VisitEndTime,
                Purpose = dto.Purpose,
                PurposeOthers = dto.PurposeOthers?.Trim(),
                Department = dto.Department,
                AdditionalRequirements = dto.AdditionalRequirements,
                Status = status,
                CreatedAt = EnsureUtc(DateTime.UtcNow),
                CreatedBy = string.IsNullOrWhiteSpace(dto.CreatedBy)
                    ? string.Empty
                    : dto.CreatedBy.Trim().ToLowerInvariant(),
                HostName = dto.HostName.Trim(),
                HostEmail = dto.HostEmail.Trim().ToLower(),
                VisitorType = dto.VisitorType
            };

            await _repository.AddAsync(entity);
            await _repository.SaveChangesAsync();

            if (dto.AdditionalVisitors != null && dto.AdditionalVisitors.Any())
            {
                System.Diagnostics.Debug.WriteLine($"[Create] AdditionalVisitors from DTO: {dto.AdditionalVisitors.Count}");
                foreach (var av in dto.AdditionalVisitors)
                {
                    System.Diagnostics.Debug.WriteLine($"  DTO: Name={av.Name}, Email={av.Email}, Phone={av.Phone}, Company={av.Company}");
                }
            }

            if (dto.AdditionalVisitors != null && dto.AdditionalVisitors.Any())
            {
                var additionalList = dto.AdditionalVisitors.Select(av => new VisitorAdditional
                {
                    InvitationId = entity.Id,
                    Name = av.Name,
                    Email = av.Email,
                    Phone = av.Phone,
                    Company = av.Company ?? string.Empty,
                }).ToList();

                System.Diagnostics.Debug.WriteLine($"[Create] Saving {additionalList.Count} additional visitors");
                foreach (var v in additionalList)
                {
                    System.Diagnostics.Debug.WriteLine($"  Save: Name={v.Name}, Email={v.Email}, Phone={v.Phone}, Company={v.Company}");
                }

                await _repository.AddAdditionalRangeAsync(additionalList);
                await _repository.SaveChangesAsync();
            }

            var created = await _repository.GetByIdAsync(entity.Id);
            await _emailNotifier.SendCreationNotificationsAsync(created);

            return created;
        }

        public async Task<bool> SendCreationNotificationEmailsAsync(Guid id)
        {
            var invitation = await _repository.GetByIdAsync(id);
            if (invitation == null)
                return false;

            await _emailNotifier.SendCreationNotificationsAsync(invitation);
            return true;
        }


        // ---------------- GET ----------------
        public async Task<List<VisitorInvitationDto>> GetFilteredAsync(
            bool mine,
            string? createdBy,
            string? StatusesCsv,
            string? VisitorType,
            string? Phone)
        {
            var items = await _repository.GetAllAsync();

            if (mine && !string.IsNullOrWhiteSpace(createdBy))
               items = items.Where(x => x.CreatedBy.ToLower() == createdBy?.ToLower()).ToList();

            if (!string.IsNullOrWhiteSpace(StatusesCsv))
            {
                var Statuses = StatusesCsv
                    .Split(',', StringSplitOptions.RemoveEmptyEntries)
                    .Select(s => s.Trim().ToLowerInvariant())
                    .ToHashSet();

                items = items.Where(x =>
                    Statuses.Contains((x.Status ?? "").ToLowerInvariant()))
                    .ToList();
            }
            // ✅ NEW: visitor type filter
            if (!string.IsNullOrWhiteSpace(VisitorType))
            {
                items = items.Where(x =>
                    x.VisitorType != null &&
                    x.VisitorType.Equals(VisitorType, StringComparison.OrdinalIgnoreCase)
                ).ToList();
            }

            // ✅ NEW: phone filter
            if (!string.IsNullOrWhiteSpace(Phone))
            {
                items = items.Where(x =>
                    (x.VisitorPhone ?? "").Contains(Phone)
                ).ToList();
            }

            // ✅ optional sorting
            items = items.OrderBy(x => x.VisitorPhone).ToList();

            return items.Select(x => new VisitorInvitationDto
            {
                Id = x.Id,

                VisitorName = x.VisitorName,
                VisitorEmail = x.VisitorEmail?? string.Empty,
                VisitorPhone = x.VisitorPhone,
                VisitorCompany = x.VisitorCompany,

                HostName = x.HostName,
                HostEmail = x.HostEmail,
                CreatedBy = x.CreatedBy ?? string.Empty,

                Status = x.Status,

                CheckedInAt = x.CheckedInAt,
                CheckedOutAt = x.CheckedOutAt,

                BadgeNumber = x.BadgeNumber ?? string.Empty,
                LaptopName = x.LaptopName ?? string.Empty,
                MacAddress = x.MacAddress ?? string.Empty,
                VisitorPhotoUrl = x.VisitorPhotoUrl,

                VisitStartDate = x.VisitStartDate,
                VisitEndDate = x.VisitEndDate,
                VisitStartTime = x.VisitStartTime,
                VisitEndTime = x.VisitEndTime,

                Purpose = x.Purpose,
                PurposeOthers = x.PurposeOthers,
                Department = x.Department,

                AdditionalRequirements = x.AdditionalRequirements,
                FacilitatorNotes = x.FacilitatorNotes ?? string.Empty,

                VisitorType = x.VisitorType,

                MeetingCompleted = x.MeetingCompleted,
                HostRemarks = x.HostRemarks ?? string.Empty,
                VisitorAttended = x.VisitorAttended,
                Remarks=x.Remarks ?? string.Empty,

                AdditionalVisitors = x.AdditionalVisitors?.Select(v => new AdditionalVisitorDto
                {
                    Id = v.Id,
                    Name = v.Name,
                    Email = v.Email,
                    Phone = v.Phone,
                    Company = v.Company
                }).ToList() ?? new List<AdditionalVisitorDto>(),

                CancelledBy = x.CancelledBy,
                CancelledAt = x.CancelledAt,
                CancellationReason = x.CancellationReason

            }).ToList();

        }

        public async Task<List<VisitorInvitation>> GetActedAsync()
        {
            var items = await _repository.GetAllAsync();
            return items.Where(x =>
                x.Status == InvitationStatuses.Approved ||
                x.Status == InvitationStatuses.Rejected ||
                x.Status == InvitationStatuses.CheckedIn ||
                x.Status == InvitationStatuses.CheckedOut).ToList();
        }

        public async Task<VisitorInvitation?> GetByIdAsync(Guid id)
            => await _repository.GetByIdAsync(id);

        // ----------------ADD-------------------

        public async Task AddAdditionalVisitor(Guid invitationId, AdditionalVisitorDto dto)
        {
            var entity = new VisitorAdditional
            {
                InvitationId = invitationId,
                Name = dto.Name,
                Email = dto.Email,
                Phone = dto.Phone,
                Company = dto.Company,
                //CreatedAt = EnsureUtc(DateTime.UtcNow)
            };

            await _repository.AddAdditionalAsync(entity);
            await _repository.SaveChangesAsync();
        }

        // ---------------- REMOVE ----------------

        public async Task RemoveAdditionalVisitor(int id)
        {
            await _repository.RemoveAdditionalAsync(id);
            await _repository.SaveChangesAsync();
        }


        // ---------------- UPDATE ----------------
        public async Task<VisitorInvitation?> UpdateAsync(Guid id, UpdateVisitorInvitationDto dto)
        {
            var invitation = await _repository.GetByIdAsync(id);
            if (invitation == null) return null;

            if (dto.VisitorName != null) invitation.VisitorName = dto.VisitorName;
            if (dto.VisitorCompany != null) invitation.VisitorCompany = dto.VisitorCompany;
            if (dto.VisitorEmail != null) invitation.VisitorEmail = dto.VisitorEmail;
            if (dto.VisitorPhone != null) invitation.VisitorPhone = dto.VisitorPhone;
            if (dto.NumberOfVisitors.HasValue)
                invitation.NumberOfVisitors = dto.NumberOfVisitors.Value;

            if (dto.Remarks != null)
                invitation.Remarks = dto.Remarks;

            if (dto.Purpose != null)
                invitation.Purpose = dto.Purpose;

            if (dto.PurposeOthers != null)
                invitation.PurposeOthers = dto.PurposeOthers.Trim();

            if (dto.Department != null)
                invitation.Department = dto.Department;

            if (dto.HostName != null)
                invitation.HostName = dto.HostName.Trim();

            if (dto.HostEmail != null)
                invitation.HostEmail = dto.HostEmail.Trim().ToLower();

            if (dto.VisitorType != null &&
               (dto.VisitorType == "Recurring" || dto.VisitorType == "Non-Recurring"))
            {
                invitation.VisitorType = dto.VisitorType;
            }

            if (dto.VisitStartDate.HasValue)
                invitation.VisitStartDate = DateOnly.FromDateTime(dto.VisitStartDate.Value);

            if (dto.VisitEndDate.HasValue)
                invitation.VisitEndDate = DateOnly.FromDateTime(dto.VisitEndDate.Value);

            if (dto.VisitStartTime.HasValue)
                invitation.VisitStartTime = dto.VisitStartTime.Value;

            if (dto.VisitEndTime.HasValue)
                invitation.VisitEndTime = dto.VisitEndTime.Value;

            // ✅ current ids from frontend
            var additionalVisitors = dto.AdditionalVisitors ?? new List<AdditionalVisitorDto>();
            var incomingIds = additionalVisitors
                .Where(v => v.Id > 0)
                .Select(v => v.Id)
                .ToList();

            // ✅ existing DB visitors
            var existingVisitors = await _repository.GetAdditionalsByInvitation(id);

            // ✅ remove deleted visitors
            foreach (var existing in existingVisitors)
            {
                if (!incomingIds.Contains(existing.Id))
                {
                    await _repository.RemoveAdditionalAsync(existing.Id);
                }
            }

            // ✅ add ONLY NEW visitors
            foreach (var visitor in additionalVisitors.Where(v => v.Id == 0))
            {
                await _repository.AddAdditionalAsync(new VisitorAdditional
                {
                    InvitationId = invitation.Id,
                    Name = visitor.Name,
                    Email = visitor.Email,
                    Phone = visitor.Phone,
                    Company = visitor.Company
                });
            }

            invitation.UpdatedAt = EnsureUtc(DateTime.UtcNow);

            await _repository.SaveChangesAsync();

            var updated = await _repository.GetByIdAsync(id);
            if (updated != null)
            {
                await _emailNotifier.SendUpdateNotificationsAsync(updated);
            }

            return invitation;
        }

        // ---------------- Status ----------------
        public async Task<VisitorInvitation?> ApproveAsync(Guid id) => await UpdateStatus(id, InvitationStatuses.Approved);
        public async Task<VisitorInvitation?> RejectAsync(Guid id, string reason)
        {
            var inv = await UpdateStatus(id, InvitationStatuses.Rejected);
            if (inv != null) inv.RejectionReason = reason;
            await _repository.SaveChangesAsync();
            return inv;
        }


        public async Task<VisitorInvitation?> CheckInAsync(
            Guid id,
            CheckInVisitorDto dto)
        {
            var invitation = await _repository.GetByIdAsync(id);
            if (invitation == null)
                return null;

            if (invitation.CheckedInAt != null)
                throw new InvalidOperationException("Visitor already checked in");

            if (string.IsNullOrWhiteSpace(dto.BadgeNumber))
                throw new InvalidOperationException("Badge number is required");

            if (dto.HasLaptop &&
                (string.IsNullOrWhiteSpace(dto.LaptopName) ||
                 string.IsNullOrWhiteSpace(dto.MacAddress)))
                throw new InvalidOperationException("Laptop details are required");

            if (string.IsNullOrWhiteSpace(dto.IdentityProofType))
                throw new InvalidOperationException("Identity proof type is required");

            if (!dto.IsDocumentVerified)
                throw new InvalidOperationException("Document must be verified by security before check-in");

            if (string.IsNullOrWhiteSpace(dto.VerifiedBy))
                throw new InvalidOperationException("Verifier identity is required");

            invitation.BadgeNumber = dto.BadgeNumber;
            invitation.LaptopName = dto.HasLaptop ? dto.LaptopName : null;
            invitation.MacAddress = dto.HasLaptop ? dto.MacAddress : null;

            invitation.IdentityProofType = dto.IdentityProofType;
            invitation.IsDocumentVerified = dto.IsDocumentVerified;
            invitation.VerifiedBy = dto.VerifiedBy;
            invitation.VerifiedOn = EnsureUtc(DateTime.UtcNow);

            invitation.Status = InvitationStatuses.CheckedIn;
            invitation.CheckedInAt = EnsureUtc(DateTime.UtcNow);
            invitation.UpdatedAt = EnsureUtc(DateTime.UtcNow);

            await _repository.SaveChangesAsync();

            var checkedIn = await _repository.GetByIdAsync(id);
            if (checkedIn != null)
            {
                await _emailNotifier.SendArrivalNotificationAsync(checkedIn, dto.TimezoneId);
            }

            return invitation;
        }

        public async Task<VisitorInvitation?> CheckOutAsync(Guid id)
        {
            var invitation = await _repository.GetByIdAsync(id);
            if (invitation == null)
                return null;

            // ✅ Cannot check‑out before check‑in
            if (invitation.CheckedInAt == null)
                throw new InvalidOperationException("Visitor has not checked in");

            // ✅ Prevent double check‑out
            if (invitation.CheckedOutAt != null)
                throw new InvalidOperationException("Visitor already checked out");

            invitation.Status = InvitationStatuses.CheckedOut;
            invitation.CheckedOutAt = EnsureUtc(DateTime.UtcNow);
            invitation.UpdatedAt = EnsureUtc(DateTime.UtcNow);

            await _repository.SaveChangesAsync();
            return invitation;
        }
        private async Task<VisitorInvitation?> UpdateStatus(Guid id, string Status)
        {
            var invitation = await _repository.GetByIdAsync(id);
            if (invitation == null) return null;

            invitation.Status = Status;
            invitation.UpdatedAt = EnsureUtc(DateTime.UtcNow);
            await _repository.SaveChangesAsync();
            return invitation;
        }

        // ---------------- PHOTO ----------------
        public async Task<VisitorInvitation?> UploadPhotoAsync(Guid id, string fileName, byte[] content)
        {
            var invitation = await _repository.GetByIdAsync(id);
            if (invitation == null) return null;

            var path = await _photoStorage.SaveAsync(id, fileName, content);
            invitation.VisitorPhotoUrl = path;
            invitation.UpdatedAt = EnsureUtc(DateTime.UtcNow);
            await _repository.SaveChangesAsync();
            return invitation;
        }



        // ---------------- DELETE ----------------
        public async Task<bool> DeleteAsync(Guid id)
        {
            var invitation = await _repository.GetByIdAsync(id);
            if (invitation == null) return false;

            var additionals = await _repository.GetAdditionalsByInvitation(id);
            foreach (var additional in additionals)
            {
                await _repository.RemoveAdditionalAsync(additional.Id);
            }

            _repository.Delete(invitation);
            await _repository.SaveChangesAsync();
            return true;
        }

        // ---------------- CANCEL ----------------
        public async Task<VisitorInvitation?> CancelAsync(Guid id, CancelVisitorInvitationDto dto)
        {
            var invitation = await _repository.GetByIdAsync(id);
            if (invitation == null)
                return null;

            if (invitation.VisitorType != "Non-Recurring")
                throw new InvalidOperationException("Only Cold Call (Non-Recurring) invitations can be cancelled.");

            if (!string.Equals(invitation.Status, InvitationStatuses.Approved, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException("Only approved invitations can be cancelled.");

            if (string.IsNullOrWhiteSpace(dto.Reason))
                throw new InvalidOperationException("Cancellation reason is required.");

            invitation.Status = InvitationStatuses.Cancelled;
            invitation.CancelledBy = dto.CancelledBy;
            invitation.CancelledAt = EnsureUtc(DateTime.UtcNow);
            invitation.CancellationReason = dto.Reason.Trim();
            invitation.UpdatedAt = EnsureUtc(DateTime.UtcNow);

            await _repository.SaveChangesAsync();

            return invitation;
        }

        // ---------------- NOTES ----------------

        // ---------------- NOTES ----------------
        public async Task<VisitorInvitation?> UpdateFacilitatorNotesAsync(
            Guid id,
            string notes,
            List<string> facilities)
        {
            var invitation = await _repository.GetByIdAsync(id);

            if (invitation == null)
                return null;

            invitation.FacilitatorNotes = notes;

            // ✅ Save normalized facility keys (wifi, parking, food, etc.)
            invitation.AdditionalRequirements = string.Join(", ", facilities);

            invitation.UpdatedAt = EnsureUtc(DateTime.UtcNow);

            await _repository.SaveChangesAsync();

            return invitation;
        }


        private static DateTime EnsureUtc(DateTime value)
        {
            if (value.Kind == DateTimeKind.Utc) return value;
            return DateTime.SpecifyKind(value.ToUniversalTime(), DateTimeKind.Utc);
        }


        public async Task CloseMeetingAsync(Guid id, string userEmail, string userRole)
        {
            var invite = await _repository.GetByIdAsync(id);
            if (invite == null)
                throw new Exception("Invitation not found");

            userEmail = userEmail.ToLower();

            bool isHost = invite.HostEmail == userEmail;
            bool isSecurity = userRole?.Equals("Security", StringComparison.OrdinalIgnoreCase) == true;

            if (!isHost && !isSecurity)
                throw new UnauthorizedAccessException("Not allowed");

            if (invite.Status != InvitationStatuses.CheckedIn)
                throw new Exception("Must check-in first");

            invite.Status = "closed";
            invite.ClosedBy = userEmail;
            invite.ClosedAt = DateTime.UtcNow;
            invite.UpdatedAt = EnsureUtc(DateTime.UtcNow);

            await _repository.SaveChangesAsync();
        }

        public async Task<List<string>> GetTodayCheckedInBadgesAsync()
        {
            return await _repository.GetTodayCheckedInBadgesAsync();
        }


        public async Task<VisitorInvitation?> CompleteMeetingAsync(
      Guid id,
      string remarks,
      bool visitorAttended   // ✅ NEW PARAM
  )
        {
            var entity = await _repository.GetByIdAsync(id);

            if (entity == null) return null;

            entity.HostRemarks = remarks;
            entity.MeetingCompleted = true;
            entity.VisitorAttended = visitorAttended;   // ✅ SAVE VALUE
            entity.ClosedAt = DateTime.UtcNow;

            await _repository.SaveChangesAsync();

            return entity;
        }

    }
}
