﻿using InternalPortal.Application.DTOs;
using InternalPortal.Application.Interfaces;
using InternalPortal.Domain.Entities;
using Microsoft.AspNetCore.Http;

namespace InternalPortal.Application.Services
{
    public class RecurringService
    {
        private readonly IRecurringRepository _repository;
        private readonly IVisitorPhotoStorage _photoStorage;

        public RecurringService(
            IRecurringRepository repository,
            IVisitorPhotoStorage photoStorage)
        {
            _repository = repository;
            _photoStorage = photoStorage;
        }

        // ✅ PHOTO (ONLY SAVE — NO LOG CREATION)
        public async Task<object> UploadPhotoAsync(Guid id, IFormFile photo)
        {
            var invitation = await _repository.GetInvitationByIdAsync(id);

            if (invitation == null)
                throw new Exception("Visitor not found");

            string path = "";

            if (photo != null && photo.Length > 0)
            {
                using var ms = new MemoryStream();
                await photo.CopyToAsync(ms);

                path = await _photoStorage.SaveAsync(
                    Guid.NewGuid(),
                    photo.FileName,
                    ms.ToArray()
                );

                if (string.IsNullOrEmpty(path))
                    throw new Exception("Photo save failed");
            }

            // ✅ ONLY update main table
            if (!string.IsNullOrEmpty(path))
            {
                invitation.VisitorPhotoUrl = path;
            }

            await _repository.SaveChangesAsync();

            return new
            {
                photoUrl = path,
                message = string.IsNullOrEmpty(path)
                    ? "Photo skipped"
                    : "Photo uploaded"
            };
        }

        // ✅ ✅ CHECK-IN (FINAL CORRECT LOGIC)
        public async Task<object> CheckInAsync(Guid id, RecurringCheckInRequest req)
        {
            var invitation = await _repository.GetInvitationByIdAsync(id);

            if (invitation == null)
                throw new Exception("Visitor not found");

            if (string.IsNullOrWhiteSpace(req.IdentityProofType))
                throw new Exception("Identity proof type is required");

            if (!req.IsDocumentVerified)
                throw new Exception("Document must be verified by security before check-in");

            if (string.IsNullOrWhiteSpace(req.VerifiedBy))
                throw new Exception("Verifier identity is required");

            var phone = invitation.VisitorPhone;

            var logs = await _repository.GetHistoryAsync(phone);

            var activeLog = logs
                .Where(x => x.check_out_time == null)
                .OrderByDescending(x => x.check_in_time)
                .FirstOrDefault();

            // ✅ AUTO-CHECKOUT previous visit
            if (activeLog != null)
            {
                activeLog.check_out_time = DateTime.UtcNow;
                activeLog.status = "auto_checked_out";
            }

            // ✅ Allocate badge
            var badge = await GetNextBadgeNumber();

            // ✅ ALWAYS create new log
            var newLog = new RecurringVisitLog
            {
                invitation_id = invitation.Id,
                visitor_phone = phone,
                check_in_time = DateTime.UtcNow,
                status = "checked_in",
                badge_number = badge,
                has_laptop = req.HasLaptop,
                laptop_name = req.HasLaptop ? req.LaptopName :"",
                mac_address = req.HasLaptop ? req.MacAddress : "",
                photo_url = invitation.VisitorPhotoUrl,
                identity_proof_type = req.IdentityProofType,
                is_document_verified = req.IsDocumentVerified,
                verified_by = req.VerifiedBy,
                verified_on = DateTime.UtcNow
            };

            await _repository.AddLogAsync(newLog);

            // ✅ FIRST VISIT: update main table ONCE
            if (string.IsNullOrEmpty(invitation.BadgeNumber))
            {
                invitation.BadgeNumber = badge;
            }

            // ✅ Update main invitation with identity verification info
            invitation.IdentityProofType = req.IdentityProofType;
            invitation.IsDocumentVerified = req.IsDocumentVerified;
            invitation.VerifiedBy = req.VerifiedBy;
            invitation.VerifiedOn = DateTime.UtcNow;

            await _repository.SaveChangesAsync();

            return new
            {
                message = "Checked in successfully",
                badgeNumber = badge,
                log = newLog
            };
        }

        // ✅ CHECK-OUT
        public async Task CheckOutAsync(Guid id)
        {
            var invitation = await _repository.GetInvitationByIdAsync(id);

            if (invitation == null)
                throw new Exception("Visitor not found");

            var phone = invitation.VisitorPhone;

            var logs = await _repository.GetHistoryAsync(phone);

            var activeLog = logs
                .Where(l => l.check_out_time == null)
                .FirstOrDefault();

            if (activeLog == null)
                return;

            activeLog.check_out_time = DateTime.UtcNow;
            activeLog.status = "checked_out";

            await _repository.SaveChangesAsync();
        }

        // ✅ BADGE LOGIC
        private async Task<string> GetNextBadgeNumber()
        {
            var activeLogs = await _repository.GetActiveLogsAsync();

            var usedBadges = activeLogs
                .Where(x => !string.IsNullOrEmpty(x.badge_number))
                .Select(x => int.Parse(x.badge_number))
                .OrderBy(x => x)
                .ToList();

            int next = 1;

            foreach (var badge in usedBadges)
            {
                if (badge == next)
                    next++;
                else
                    break;
            }

            return next.ToString();
        }

        // ✅ HISTORY
        public async Task<List<RecurringVisitLog>> GetHistoryAsync(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone))
                return new List<RecurringVisitLog>();

            return await _repository.GetHistoryAsync(phone);
        }
    }
}
