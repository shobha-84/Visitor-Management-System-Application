﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace InternalPortal.Application.Common
{
    public static class InvitationStatuses
    {
        public const string Pending = "Pending";
        public const string Approved = "Approved";
        public const string Rejected = "Rejected";
        public const string CheckedIn = "checked_in";
        public const string CheckedOut = "checked_out";
        public const string Cancelled = "cancelled";
    }
}
