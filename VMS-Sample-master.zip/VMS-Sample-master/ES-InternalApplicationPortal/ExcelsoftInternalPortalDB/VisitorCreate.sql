-- Table: internalapplicationportaldb.visitor_invitations

DROP TABLE IF EXISTS internalapplicationportaldb.visitor_invitations;

CREATE TABLE IF NOT EXISTS internalapplicationportaldb.visitor_invitations
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    visitor_name character varying(200) COLLATE pg_catalog."default" NOT NULL,
    visitor_company character varying(200) COLLATE pg_catalog."default",
    visitor_email character varying(200) COLLATE pg_catalog."default",
    visitor_phone character varying(50) COLLATE pg_catalog."default",
    visit_start_date date NOT NULL,
    visit_end_date date NOT NULL,
    visit_start_time time without time zone NOT NULL,
    visit_end_time time without time zone NOT NULL,
    purpose text COLLATE pg_catalog."default" NOT NULL,
    department character varying(100) COLLATE pg_catalog."default" NOT NULL,
    additional_requirements text COLLATE pg_catalog."default",
    status character varying(20) COLLATE pg_catalog."default" NOT NULL,
    created_by character varying(100) COLLATE pg_catalog."default" NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    number_of_visitors integer NOT NULL DEFAULT 1,
    remarks text COLLATE pg_catalog."default",
    facilitator_notes text COLLATE pg_catalog."default" DEFAULT ''::text,
    rejection_reason text COLLATE pg_catalog."default" DEFAULT ''::text,
    visitor_photo_url text COLLATE pg_catalog."default" DEFAULT ''::text,
    CONSTRAINT visitor_invitations_pkey PRIMARY KEY (id),
    CONSTRAINT chk_number_of_visitors_positive CHECK (number_of_visitors > 0)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS internalapplicationportaldb.visitor_invitations
    OWNER to postgres;
-- Index: idx_vi_created_at

-- DROP INDEX IF EXISTS internalapplicationportaldb.idx_vi_created_at;

CREATE INDEX IF NOT EXISTS idx_vi_created_at
    ON internalapplicationportaldb.visitor_invitations USING btree
    (created_at DESC NULLS FIRST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_vi_created_by

-- DROP INDEX IF EXISTS internalapplicationportaldb.idx_vi_created_by;

CREATE INDEX IF NOT EXISTS idx_vi_created_by
    ON internalapplicationportaldb.visitor_invitations USING btree
    (created_by COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_vi_created_by_status_created_at

-- DROP INDEX IF EXISTS internalapplicationportaldb.idx_vi_created_by_status_created_at;

CREATE INDEX IF NOT EXISTS idx_vi_created_by_status_created_at
    ON internalapplicationportaldb.visitor_invitations USING btree
    (created_by COLLATE pg_catalog."default" ASC NULLS LAST, status COLLATE pg_catalog."default" ASC NULLS LAST, created_at DESC NULLS FIRST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_vi_status

-- DROP INDEX IF EXISTS internalapplicationportaldb.idx_vi_status;

CREATE INDEX IF NOT EXISTS idx_vi_status
    ON internalapplicationportaldb.visitor_invitations USING btree
    (status COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_visitor_invitations_created_at

-- DROP INDEX IF EXISTS internalapplicationportaldb.idx_visitor_invitations_created_at;

CREATE INDEX IF NOT EXISTS idx_visitor_invitations_created_at
    ON internalapplicationportaldb.visitor_invitations USING btree
    (created_at DESC NULLS FIRST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_visitor_invitations_created_by

-- DROP INDEX IF EXISTS internalapplicationportaldb.idx_visitor_invitations_created_by;

CREATE INDEX IF NOT EXISTS idx_visitor_invitations_created_by
    ON internalapplicationportaldb.visitor_invitations USING btree
    (created_by COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_visitor_invitations_status

-- DROP INDEX IF EXISTS internalapplicationportaldb.idx_visitor_invitations_status;

CREATE INDEX IF NOT EXISTS idx_visitor_invitations_status
    ON internalapplicationportaldb.visitor_invitations USING btree
    (status COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;

ALTER TABLE internalapplicationportaldb.visitor_invitations
ALTER COLUMN "department" TYPE VARCHAR(200);


ALTER TABLE internalapplicationportaldb.visitor_invitations
ADD COLUMN checked_in_at TIMESTAMPTZ NULL,
ADD COLUMN checked_out_at TIMESTAMPTZ NULL;

ALTER TABLE internalapplicationportaldb.visitor_invitations
ADD COLUMN host_name VARCHAR(200) NOT NULL DEFAULT '',
ADD COLUMN host_email VARCHAR(200) NOT NULL DEFAULT '',
ADD COLUMN closed_by VARCHAR(200),
ADD COLUMN closed_at TIMESTAMP;

ALTER TABLE internalapplicationportaldb.visitor_invitations
ADD COLUMN laptop_name VARCHAR(50),
ADD COLUMN mac_address VARCHAR(50),
ADD COLUMN badge_number VARCHAR(50);

ALTER TABLE internalapplicationportaldb.visitor_invitations
ADD COLUMN visitor_type VARCHAR(50) NOT NULL DEFAULT 'Non-Recurring';

ALTER TABLE internalapplicationportaldb.visitor_invitations
ADD CONSTRAINT chk_visitor_type
CHECK (visitor_type IN ('Recurring', 'Non-Recurring'));
 
CREATE INDEX idx_vi_visitor_type
ON internalapplicationportaldb.visitor_invitations (visitor_type);

CREATE INDEX IF NOT EXISTS idx_vi_host_email
ON internalapplicationportaldb.visitor_invitations (host_email);


ALTER TABLE internalapplicationportaldb.visitor_invitations
ADD COLUMN host_remarks TEXT,
ADD COLUMN meeting_completed BOOLEAN DEFAULT FALSE;


ALTER TABLE internalapplicationportaldb.visitor_invitations
ADD COLUMN VisitorAttended BOOLEAN NOT NULL DEFAULT FALSE;


ALTER TABLE internalapplicationportaldb.visitor_invitations
RENAME COLUMN visitorattended TO "VisitorAttended";


-- Cancellation audit fields for Security Cancel functionality

ALTER TABLE internalapplicationportaldb.visitor_invitations
ADD COLUMN cancelled_by VARCHAR(200),
ADD COLUMN cancelled_at TIMESTAMPTZ,
ADD COLUMN cancellation_reason TEXT;

-- Identity Verification fields for check-in

ALTER TABLE internalapplicationportaldb.visitor_invitations
ADD COLUMN identity_proof_type VARCHAR(100),
ADD COLUMN is_document_verified BOOLEAN DEFAULT FALSE,
ADD COLUMN verified_by VARCHAR(200),
ADD COLUMN verified_on TIMESTAMPTZ;

-- Identity Verification fields for recurring visit logs

ALTER TABLE internalapplicationportaldb.recurring_visit_logs
ADD COLUMN identity_proof_type VARCHAR(100),
ADD COLUMN is_document_verified BOOLEAN DEFAULT FALSE,
ADD COLUMN verified_by VARCHAR(200),
ADD COLUMN verified_on TIMESTAMPTZ;


-- Purpose Others field for "Others" option in Purpose of Visit
ALTER TABLE internalapplicationportaldb.visitor_invitations
ADD COLUMN purpose_others TEXT,
ADD CONSTRAINT chk_purpose_others_length 
CHECK (purpose_others IS NULL OR char_length(purpose_others) <= 500);

-- Recurring visitor table

DROP TABLE IF EXISTS  internalapplicationportaldb.recurring_visit_logs;
CREATE TABLE internalapplicationportaldb.recurring_visit_logs
(
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 
    -- ✅ link to invitation
    invitation_id UUID NOT NULL,
 
    -- ✅ main identifier for recurring visitor
    visitor_phone VARCHAR(50) NOT NULL,
 
    -- ✅ visit lifecycle
    check_in_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    check_out_time TIMESTAMPTZ,
 
    status VARCHAR(20) NOT NULL,
 
    -- ✅ badge (critical for your flow)
    badge_number VARCHAR(50) NOT NULL,
 
    -- ✅ laptop details
    has_laptop BOOLEAN DEFAULT FALSE,
    laptop_name VARCHAR(100),
    mac_address VARCHAR(100),
 
    -- ✅ photo per visit
    photo_url TEXT,
 
    created_at TIMESTAMPTZ DEFAULT NOW(),
 
    -- ✅ FK constraint
    CONSTRAINT fk_recurring_invitation
        FOREIGN KEY (invitation_id)
        REFERENCES internalapplicationportaldb.visitor_invitations(id)
        ON DELETE CASCADE
);
 
CREATE UNIQUE INDEX uq_active_recurring_phone
ON internalapplicationportaldb.recurring_visit_logs (visitor_phone)
WHERE check_out_time IS NULL;
 
CREATE INDEX idx_recurring_badge_active
ON internalapplicationportaldb.recurring_visit_logs (badge_number)
WHERE check_out_time IS NULL;

-- additional visitors table

CREATE TABLE internalapplicationportaldb.visitor_additional (
    id SERIAL PRIMARY KEY,
    invitation_id UUID NOT NULL,
    name VARCHAR(100),
    email VARCHAR(150),
    phone VARCHAR(20),
    company VARCHAR(100),

    CONSTRAINT fk_invitation
        FOREIGN KEY (invitation_id)
        REFERENCES internalapplicationportaldb.visitor_invitations(id)
        ON DELETE CASCADE
);


SET search_path TO internalapplicationportaldb;
