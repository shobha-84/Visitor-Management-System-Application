
DROP TABLE IF EXISTS internalapplicationportaldb.store_requests;


CREATE TABLE internalapplicationportaldb.store_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),

    created_by TEXT NOT NULL,

    title TEXT NOT NULL,
    description TEXT,

    category TEXT NOT NULL, -- product / software_service / people
    is_it_related BOOLEAN,

    estimated_cost NUMERIC,
    quantity INTEGER,

    urgency TEXT,
    department TEXT,

    vendor_details TEXT,
    notes TEXT,

    -- ✅ NEW FIELDS
    license_type TEXT,
    employment_type TEXT,

    status TEXT,
    current_approver_role TEXT,

    -- Approval timestamps
    ops_manager_approved_at TIMESTAMP,
    it_manager_approved_at TIMESTAMP,
    coo_approved_at TIMESTAMP,
    finance_authorized_at TIMESTAMP,
    hr_approved_at TIMESTAMP,
    po_released_at TIMESTAMP,

    rejection_reason TEXT,

    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

 ALTER TABLE internalapplicationportaldb.store_requests
ADD COLUMN IF NOT EXISTS license_type TEXT;

ALTER TABLE internalapplicationportaldb.store_requests
ADD COLUMN IF NOT EXISTS employment_type TEXT;
