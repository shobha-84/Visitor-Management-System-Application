
-- ✅ 1. Drop tables (users first because of FK)
DROP TABLE IF EXISTS internalapplicationportaldb.users CASCADE;
DROP TABLE IF EXISTS internalapplicationportaldb.roles CASCADE;

-- ✅ 2. Create ROLES table
CREATE TABLE internalapplicationportaldb.roles (
    id SERIAL PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
);

-- ✅ 3. Create USERS table (IMPORTANT: schema-qualified FK)
CREATE TABLE internalapplicationportaldb.users (
    id UUID PRIMARY KEY,
    username VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role_id INT NOT NULL,

    CONSTRAINT fk_user_role
        FOREIGN KEY (role_id)
        REFERENCES internalapplicationportaldb.roles(id)
        ON DELETE CASCADE
);

-- ✅ 4. Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ✅ 5. Insert Roles FIRST
INSERT INTO internalapplicationportaldb.roles (id, name)
VALUES 
(1, 'Admin'),
(2, 'Security'),
(3, 'Employee');

-- ✅ 6. Insert Users
INSERT INTO internalapplicationportaldb.users 
(id, username, email, password_hash, role_id)
VALUES
(gen_random_uuid(), 'admin', 'admin@test.com', 'admin@123', 1),
(gen_random_uuid(), 'security', 'security@test.com', 'security@123', 2),
(gen_random_uuid(), 'Employee', 'shankarprasad@gmail.com', 'password', 3),
(gen_random_uuid(), 'Employee', 'shobha@gmail.com', 'password', 3);
